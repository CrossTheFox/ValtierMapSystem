---
name: valtia-ecologia
description: >-
  Fauna, Nightmares y ecosistema de Valtia-01: mutaciones post-Diluvio, caza,
  zonas de actividad. Usar al preparar combates, viajes o horror.
disable-model-invocation: true
---

# Valtia-01 — Ecología y Nightmares

## Fauna

- **Todas** mutaciones **post-Diluvio**; historias particulares opcionales.
- **Comestible** en general («para el paladar que lo aguante»); pocos tabúes — diferencias culturales.
- **Híbridos**: mismo estatus legal en todas las ciudades.

## Nightmares

### Qué son

- Criaturas **míticas** con resquicios del Diluvio Rojo.
- Depredadores **extremadamente peligrosos y sanguinarios**.
- Conducta baja y depredativa; algunos **actos obscenos por placer** antes de matar (no devoran siempre).

### Dónde

- Varias regiones; **no comunes**; **zonas de mayor actividad**.
- No solo por magia desequilibrada — también territorio histórico.

### Interacción

| Acción | Viabilidad |
|--------|------------|
| Matar | Sí |
| Contener | Sí |
| Negociar | **Extremadamente difícil** — sin sentimientos; destrucción, autopreservación, «diversión» |

### Uso por civilizaciones

- **Germa**: caza Nightmares.
- **Lorven**: los usó como **arma de guerra** (guerras iniciales).

### Sin vínculo

- **No** son cobradores del Intercambio Ciego.

## Geografía con nombre

- Cordilleras/mares/desiertos **nombrados**; rol económico **por ciudad** (ej. Germa caza marina vs cría).
