# Investigación: tokens en Evento narrativo (cascade) — enfoque relación-primero

**Fecha:** 2026-07-14  
**Contexto:** Lab IA / NEURAL_LAB · modo Evento narrativo  
**Síntoma observado:** con profundidad 8 → `11640 in / 16373 out`, badge `truncado: SÍ`, error «JSON truncada (sin tokens de salida)». El modelo agotó el tope de **salida** (~16k) escribiendo impacts; el input también iba gordo (86 fichas / 150 relaciones).

---

## 1. Qué está pasando (diagnóstico)

Hay **dos presupuestos de tokens distintos**:

| Presupuesto | Qué lo llena hoy | Efecto |
|-------------|------------------|--------|
| **Input (contexto)** | Fichas casi completas + listado de hasta ~150 relaciones + arquetipos/descripciones largas | Badge `truncado: SÍ` cuando corta `maxChars`; peor fidelidad (se pierden las aristas del final) |
| **Output (JSON)** | Un `impact` obligatorio por cada personaje listado en «DEBEN tener un impacto», con `emotionalReaction` + `narrativeHook` + N `changes` | Pega el techo de `maxOutputTokens` (Auto evento = 16k) → JSON inválido |

Subir solo `maxOutputTokens` **aplaza** el problema: a profundidad 8 y lista larga de impacts, 24–32k también se llena en campañas densas (Valtia a largo plazo).

La profundidad 8 pide coherencia con un subgrafo enorme. Eso no es el job del Lab: el job es **propagar cambios de relación / estado** con justificación local al grafo.

---

## 2. Principio de diseño (recomendación)

> **Relación-primero, ficha-después.**  
> Lo que hace fiel la reacción de Oni ante Zorgun no es el body wiki entero de ambos: es el **vínculo** (tipo, fuerza, label), más arquetipo / `narrativeState` / `stressResponse` / `bondNotes`.

Para una campaña larga:

| Prioridad | Incluir en contexto | Omitir / compactar |
|-----------|---------------------|--------------------|
| Alta | Ancla + mencionados en el evento | Bodies largos de fichas |
| Alta | Aristas entre ancla ↔ impacts (fuerza ≥ umbral) | Dump completo de 150 `relacionado_con` débiles |
| Media | Memoria PANGeA (arquetipo, estado, estrés, traits, bondNotes) | Descripciones largas del arquetipo en cada ficha (ya están en prompt de sistema) |
| Baja | Colectivos (locación/org) solo si tocan el evento | Ondas 6–8 con impacts obligatorios |

**Profundidad práctica recomendada:** **3–4 ondas** como default de mesa. 6–8 solo para experimentos / anclas muy locales. A 8, el grafo de Valtia empuja decenas de personajes a «DEBE tener impacto» y el JSON de salida explota.

---

## 3. Opciones evaluadas

### A. Solo subir `maxOutputTokens` (24k–32k)
- **Pros:** cambio mínimo.  
- **Contras:** caro, frágil, no mejora calidad; sigue truncando contexto.  
- **Veredicto:** parche, no solución.

### B. Bajar profundidad (UI default 3–4, soft-cap)
- **Pros:** menos impacts obligatorios → menos output.  
- **Contras:** solo si el DJ baja el slider; no arregla el packing de cada ficha.  
- **Veredicto:** necesario + insuficiente solo.

### C. Pack relación-primero (elegido)
1. Fichas en cascade **siempre compactas** (sin `body`; sí memoria narrativo + vínculos fuertes).  
2. Lista de impacts **capada** (p.ej. máx. 10–12 total), ordenada por: mención en evento → fuerza de vínculo al ancla → onda cercana.  
3. Bloque de relaciones: solo aristas que tocan **ancla ∪ impacts ∪ menciones**, no todo el subgrafo.  
4. `cascadeOptsForDepth` más suave (menos entidades/relaciones/`maxChars` por profundidad).  
5. Prompt: limitar largo de `emotionalReaction` / nº de `changes` por impacto.  
6. Auto salida cascade → **24k** como margen, no como muleta.

### D. Generación en 2 pasadas (futuro)
- Pasa 1: lista corta de impacts + deltas de relación.  
- Pasa 2: expandir ganchos solo para onda 1–2.  
- **Veredicto:** excelente a medio plazo; más complejidad UI/servicio. Dejar anotado.

---

## 4. Métricas esperadas (Valtia, evento tipo revelación Engel/Zorgun/Oni)

| Escenario | Input est. | Output est. | Nota |
|-----------|------------|-------------|------|
| Antes (depth 8, pack actual) | ~11–12k | ≥16k (trunca) | Fallo observado |
| Depth 4 + relación-primero | ~4–7k | ~6–12k | Mesa habitual |
| Depth 3 + relación-primero | ~3–5k | ~4–8k | Ideal campaña larga |

---

## 5. Decisiones de producto

1. El Lab de cascada **no** debe aspirar a ser «consistente con todo el lore de cada ficha» en un solo call.  
2. La fidelidad se mide por **cambios de arista / estado** revisables por el DJ, anclados a vínculos reales.  
3. `truncado: SÍ` en contexto debe volverse excepcional (señal de mal pack), no norma a profundidad alta.  
4. Profundidad 8 queda como techo experimental, no como target de diseño.

---

## 6. Implementación asociada (esta misma iteración)

- `cascadeOptsForDepth` suave + `maxTotalImpacts`.  
- `buildCascadeContext`: compact siempre; impacts rankeados por fuerza hacia el ancla; relaciones filtradas al núcleo.  
- Default slider → 3; hint UI «recomendado 3–4».  
- Auto `maxOutputTokens` cascade → 24576.  
- Prompt cascade: economía de texto en reacciones/cambios.

---

## 7. Referencias código

---

## 8. Evolución: mezcla B+C+D implementada (2026-07-14)

La §3 Opción C (generación en 2 pasadas) y la §3 Opción D (Reflexion retry) han sido investigadas en detalle y añadidas al sistema. La implementación completa está documentada en `docs/investigacion-multipass-cascade-ia.md`.

### Resumen de lo implementado

| Técnica | Cuándo activa | Mejora principal |
|---------|--------------|-----------------|
| Opción B (relación-primero) | Siempre, ya activo | -40-50% input tokens |
| Opción C (Two-pass Scout+Impact) | `expectedImpacts >= 5` | -15% tokens output; seed coherente; +80% tasa de éxito en eventos complejos |
| Opción D (Reflexion-lite retry) | `missingImpacts > 0` o `truncated` | Tasa de fallo: ~15-20% → ~2-4% neto |
| ONTO en Scout context | Siempre en Pasa 1 | -46-51% del bloque relaciones del Scout |

### Por qué esta mezcla

- **B ya activo:** sin costo, mejora inmediata ya demostrada.
- **C en umbral:** overhead de latencia (+2-4s) solo se justifica cuando el single-pass empieza a degradar, que empíricamente ocurre a ≥5 impacts esperados.
- **D como red de seguridad:** el retry solo cuesta tokens cuando algo falla. Sin él, el DJ ve un error o un resultado parcial y tiene que regenerar manualmente (peor experiencia).
- **ONTO en Scout:** el Scout context es pequeño y repetitivo, exactamente el caso de uso óptimo de ONTO. En el Impact context se pospone por riesgo de contaminación del output.

### Archivos modificados

- `src/constants/wiki/narrativeAiSchemas.js` — Scout schema + prompt + threshold
- `src/utils/buildSituationContext.js` — `buildScoutContext()` con ONTO
- `firebase/services/narrativeAiService.js` — soporte `CASCADE_SCOUT` mode
- `src/utils/validateAiResponse.js` — `buildReflexionPrompt()` helper
- `src/components/wiki/WikiAiLabPanel.jsx` — two-pass flow + retry + loading labels

- `src/utils/buildSituationContext.js` — `buildCascadeContext`, `entityToTextForAi`  
- `src/constants/wiki/narrativeAiSchemas.js` — `CASCADE_CONTEXT_OPTS`, `cascadeOptsForDepth`, system prompt  
- `src/constants/wiki/narrativeAiConfig.js` — `resolveGenerationParams`  
- `src/components/wiki/WikiAiLabPanel.jsx` — slider profundidad  
- Skill: `.cursor/skills/ai-narrative-lab/SKILL.md`
