---
name: icon-ttrpg-index
description: >-
  Hub for ICON TTRPG rules used in this repo: points to specialized skills for
  Jobs/progression, tactical combat, glossary, narrative play, Bonds, Relics, and
  the four class archetypes (Stalwart, Vagabond, Mendicant, Wright). Use when
  the user mentions ICON, Jobs, abilities, Bonds, combat keywords, relics, or
  designing homebrew that must stay compatible with ICON.
disable-model-invocation: false
---

# ICON TTRPG — Skill index (Valt6 / pixi-map)

## Legal / scope

- Skills here are **condensed play aids** for private campaign and tooling work.
- They **do not** replace the commercial rulebooks. Full text lives in your
  local `docs/` (gitignored). Never paste full copyrighted ability blocks into
  public repos or generated exports.

## When to load which skill

| Need | Skill |
|------|--------|
| Job pick, AP, masteries, expeditions, refocus, relic timing (Jobs booklet) | `icon-jobs-progression` |
| Grid combat, HP/wounds/vigor, turns, actions overview | `icon-book-of-battle` |
| Keyword definitions (Armor, Rush, Combo, statuses…) | `icon-combat-glossary` |
| Action rolls, 12 actions, risk/effect, chapter limits | `icon-narrative-system` |
| Bond sheets, ideals, gear, bond powers pattern | `icon-bonds-overview` |
| Relic tiers, invokes, dust, example relic names | `icon-relics-overview` |
| **Red** — Stalwart jobs (Bastion, Demon Slayer, Colossus, Knave) | `icon-class-stalwarts` |
| **Yellow** — Vagabond jobs (Fool, Freelancer, Shade, Warden) | `icon-class-vagabonds` |
| **Green** — Mendicant jobs (Chanter, Harvester, Seer) | `icon-class-mendicants` |
| **Blue** — Wright jobs (Enochian, Geomancer, Spellblade, Stormbender) | `icon-class-wrights` |

**Color convention (tactical):** Stalwart = red, Vagabond = yellow, Mendicant =
green, Wright = blue — used for ability **class** matching (e.g. ≥ half
expedition abilities must match primary job’s class).

## Macro routing (four big job families)

Use the **class** skill when:

- Writing or vetting **job traits**, **limit breaks**, or **abilities** for a job
  in that class.
- Checking **status** focus and **gambit** rules for cross-class dips.
- Explaining how a new homebrew ability should **feel** like that class.

Use **`icon-jobs-progression`** for anything about **levels**, **AP**, **second
job**, **primary job**, **refocus**, or **relic unlock levels**.

## VTT bridge (this project)

For **Firestore / Redux / UI** data shapes, Firestore collections, and cyber UI
patterns, use **`pixi-map-ttrpg`** — it is the technical source of truth. ICON
skills inform **content and mechanics language**, not wire formats.

## Campaign setting — Valtia-01 (`docs/Valtia - 01/`, not in git)

Lore y dirección de campaña Valt6. Hub: **`valtia-index`**. Cuando el usuario
`@`-referencie un skill o PDF de setting, leer y aplicar guardrails.

| Necesidad | Skill (en `docs/Valtia - 01/`) |
|-----------|--------------------------------|
| Hub / routing | `valtia-index` |
| **Estado vivo de trama** | `valtia-estado-actual` |
| Línea temporal y evento primordial | `valtia-setting` |
| Seis ciudades (Galathia, Techia…) | `valtia-ciudades` |
| Facciones, Mártires, Pecados | `valtia-facciones` |
| Magia (Equivalente, Ciego, Nightmares) | `valtia-magia` |
| Especie Zarken | `valtia-zarkens` |
| Diluvio Rojo y castigo cósmico | `valtia-diluvio-rojo` |
| Wernegar exterior | `valtia-wernegar` |
| Región y domo Valtia | `valtia-region-valtia` |
| Historia / Felicia / Motor | `valtia-historia` |
| Nightmares / fauna | `valtia-ecologia` |
| ICONs y gancho de caravana | `valtia-icons-campana` |
| Validar lore nuevo | `valtia-lore-guardrails` |

Fuentes: `Valtia_Resumen_General.md` (trama actual) + `Valt6-01, Setting y Mundo.pdf` (cosmología).

## Campaign PCs (Valt6 playbooks)

Homebrew **per-character** playbooks (narrative-first table, tone, ZARC-style
axes, Firestore id prefixes). Add a row here when a new PC skill exists.

| PC | Skill |
|----|--------|
| Judeth Kalain (Anchor / Anathema, ZARC) | `pc-judeth-kalain` |

## Local PDF map (`docs/icon/`, not in git)

| File | Topic skill |
|------|-------------|
| `ICON Jobs.pdf` | `icon-jobs-progression` |
| `ICON Book Of Battle.pdf` | `icon-book-of-battle` |
| `ICON Combat Glossary and Advanced Combat.pdf` | `icon-combat-glossary` |
| `ICON Narrative Play.pdf` + `ICON Make Narrative Character.pdf` | `icon-narrative-system` |
| `ICON Bonds.pdf` | `icon-bonds-overview` |
| `ICON Relics.pdf` | `icon-relics-overview` |
| `ICON Book Stalwarts.pdf` | `icon-class-stalwarts` |
| `ICON Book Vagabonds.pdf` | `icon-class-vagabonds` |
| `ICON Book Mendicants.pdf` | `icon-class-mendicants` |
| `ICON Book Wrights.pdf` | `icon-class-wrights` |

When the user `@`-references a PDF in `docs/`, prefer **reading that file** and
then applying the matching skill’s conventions.

## Homebrew ability checklist (all classes)

When proposing a new **combat ability**, ensure the write-up includes:

1. **Costs:** actions (0–2), resolve if any, tags (Attack, range, blast, etc.).
2. **Effect lines** vs **attack lines** vs **triggers** (Collide, Heroic, Charge…).
3. **Talents I / II** and **Mastery** as forked upgrades (not both talents).
4. **Chapter** gate if power jumps tiers.
5. **Class color** compatibility if it is meant for a specific job line.

Do **not** invent precise numbers that contradict table standards without
labeling them as homebrew.
