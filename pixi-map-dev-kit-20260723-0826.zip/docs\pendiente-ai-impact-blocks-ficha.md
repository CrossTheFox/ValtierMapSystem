# Implementado — Bloques de impacto IA en fichas

Al **aplicar** un impacto de evento narrativo (cascade), la entidad afectada recibe un bloque corto en su ficha (debajo del `body` humano). Editable y borrable por el DM.

## Alcance

- **Todas las entidades** con impacto aplicado: personajes (`impacts`) y locaciones/organizaciones (`collectiveImpacts`).
- Campo top-level: `entity.aiImpactBlocks[]` (no va en `customFields`).
- No modifica `summary` ni `body`.

## Forma del bloque

```js
{
  id: string,
  createdAt: number,
  updatedAt: number | null,
  source: "cascade",
  eventTitle: string,
  wave: number | null,
  body: string,            // 3–4 líneas máx.
  createdByAi: true,
  editedByHuman: boolean,
}
```

Orden: más reciente primero.

## Archivos

| Rol | Path |
|-----|------|
| Helpers | `src/utils/aiImpactBlocks.js` |
| Persist al aplicar | `src/utils/applyProposedImpact.js` |
| UI cascade (+ apply colectivo) | `src/components/wiki/WikiCascadeResult.jsx` |
| Lista editar/borrar | `src/components/wiki/WikiAiImpactBlocks.jsx` |
| Vista ficha | `src/components/wiki/WikiEntityDetail.jsx` |
| Editor | `src/components/wiki/WikiEntityEditor.jsx` |

## Texto del bloque

- Personaje: `emotionalReaction` + `narrativeHook` + línea breve de relaciones.
- Colectivo: `collectiveReaction` + `narrativeHook` + misma línea de relaciones.

## UX

- Archive: sección «GENERACIONES DE IA» bajo el cuerpo narrativo (solo si hay bloques).
- DM con permiso de editar ficha: editar inline / eliminar.
- Cada «Aplicar impacto completo» appendea un bloque nuevo (duplicados se borran a mano si hace falta).
