---
name: valtia-index
description: >-
  Hub campaña Valtia-01: skills por tema, fuentes canon, pendientes cuestionario.
  Usar con Valtia, Galathia, magia, conceptos, Margalous, Diluvio.
disable-model-invocation: false
---

# Valtia-01 — Índice de campaña

## Fuentes

| Archivo | Contenido |
|---------|-----------|
| `valtia-worldbuilding-respuestas.json` | Respuestas DM archivadas |
| `valtia-worldbuilding-cuestionario.html` | 10 preguntas esenciales pendientes |
| `Valtia_Resumen_General.md` | Snapshot narrativo |
| PDF Setting | Cosmología ICON / entrada domo |

## Skills

| Tema | Skill |
|------|--------|
| Hub | `valtia-index` |
| Trama viva | `valtia-estado-actual` |
| Timeline / Felicia / Motor | `valtia-historia` |
| Magia completa | `valtia-magia` |
| **Muerte / Reaktis / Reakta** | **`valtia-muerte-reaktis`** |
| Ciudades ×6 | `valtia-ciudades` |
| Facciones | `valtia-facciones` |
| Zarken / sangre | `valtia-zarkens` |
| Nightmares / fauna | `valtia-ecologia` |
| Diluvio | `valtia-diluvio-rojo` |
| Región domo | `valtia-region-valtia` |
| Wernegar exterior | `valtia-wernegar` |
| Guardrails | `valtia-lore-guardrails` |
| Setting primordial | `valtia-setting` |
| ICON entrada | `valtia-icons-campana` |
| **IA situaciones (pixi-map)** | `src/constants/wiki/plan-ia-situaciones.md` |

## Pendiente cuestionario (~9 preguntas)

Sociedad cotidiana, economía, NPCs, mesa, misterios. **Muerte/religión cerrado** en `valtia-muerte-reaktis`.

## Meta mesa

Tono sin censura · narrativa sólida · no sobrecargar reglas (ver meta.notes JSON).
