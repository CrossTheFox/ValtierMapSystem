﻿# pixi-map — kit de desarrollo (docs + mockups HTML + agents + skills)

Paquete para continuar desarrollo/diseño fuera de la máquina principal.
Extrae este zip y abre la carpeta en Cursor (o copia `.cursor/` y `.agents/` dentro de tu clone del repo).

## Contenido

| Ruta | Qué es |
|------|--------|
| `docs/worldanvil-ia.md` / `docs/vtt.md` | Fuentes de verdad del sistema |
| `docs/*.html` | Mockups de diseño (árbol, timeline, personajes, arquitectura, roadmap) |
| `docs/mockups/` | Propuestas UI (location characters, etc.) |
| `docs/memoria/propuestas-ui-*` | Mockups Archive + VTT HUD |
| `docs/memoria/` | Investigación IA, casos, bibliografía |
| `docs/Valtia - 01/` | Lore/skills de campaña |
| `.cursor/rules/` + `.cursor/skills/` | Reglas y skills del proyecto |
| `.agents/skills/` | Skills Firebase / Genkit JS |
| `LEEME.md` | Este archivo |

## Mockups HTML clave (abrir en el navegador)

- `docs/propuesta-arbol-habilidades.html` — árbol CP2077 / progresión
- `docs/propuesta-mis-personajes.html` — dossier Identidad + Kit
- `docs/propuesta-timeline.html` — Spine + Arcos
- `docs/arquitectura-vtt-wiki.html` — mapa arquitectura
- `docs/wiki-roadmap.html` — roadmap wiki
- `docs/memoria/propuestas-ui-vtt/` — HUD VTT
- `docs/memoria/propuestas-ui-narrative-archive/` — Archive UI
- `docs/mockups/location-characters-proposals/` — tab personajes en locación

## Cómo usarlo en el PC del trabajo

1. Extrae el zip.
2. Copia `.cursor/` y `.agents/` a la raíz del repo `pixi-map`.
3. Diseña abriendo los `.html` en el navegador; implementa con Cursor leyendo `docs/worldanvil-ia.md` y `docs/vtt.md`.
4. **No** subas secretos (`.env`, API keys, credenciales) a chats de trabajo.

## Excluido

- Credenciales / `.env`
- Skills Genkit Dart/Go/Python y Xcode
- `node_modules`, builds
