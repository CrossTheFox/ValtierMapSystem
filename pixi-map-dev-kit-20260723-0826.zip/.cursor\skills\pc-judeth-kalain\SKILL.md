---
name: pc-judeth-kalain
description: >-
  Playbook for the ICON homebrew PC Judeth Kalain (Wright / Anchor–Anathema,
  ZARC-GEMS, volatile core, dual revolvers). Covers narrative-first Valt6 table
  rules, the power–control–cost axis, and how to write new traits, abilities,
  or secondary jobs in her voice. Use when the user names Judeth, Kalain,
  Anchor, Anathema, ZARC, or edits her Firestore bundle or abilities.
disable-model-invocation: true
---

# Judeth Kalain — Playbook (Valt6 / ICON homebrew)

## Mesa: ICON homebrew Valt6 (marco obligatorio)

En esta campaña el **juego narrativo es mandatorio**: escenas, tensiones y
resoluciones narrativas mandan el ritmo. El combate de **rejilla / táctico** es
una capa que **cuelga** del relato, no al revés.

- Las **habilidades no son** “declaro el efecto y cierro”: son **un enfoque**,
  una postura o un modo de jugar la escena (riesgo, alcance, quién queda
  expuesto, qué queda estable).
- Al redactar **traits**, **ataques**, **jobs secundarios** o **LB** para Judeth
  (o inspirados en ella), primero preguntá: *¿qué pregunta narrativa abre esto?*
  y recién después *¿qué dado o etiqueta lo ancla en ICON?*

Para reglas base ICON (acciones, bonds, reliquias, Wright genérico), seguí el
hub **`icon-ttrpg-index`**; esta skill es **solo** tono mecánico-narrativo de
esta PJ y su homebrew.

---

## Paneo rápido del personaje

| Aspecto | Contenido |
|--------|-----------|
| **Nombre** | Judeth Kalain |
| **Kin** | Xixo |
| **Clase táctica (macro)** | Wright (azul) |
| **Job display** | Anchor / Anathema (homebrew sobre Wright) |
| **Núcleo** | Magia **caótica y volátil** en el cuerpo; no la “domina”, la **encauza** para no autodestruirse |
| **Dispositivo** | Dos revólveres arcanotécnicos (**Anchor**, **Anathema**) disparan **gemas Z-Arcana (ZARC-GEMS)**; además el rifle **Meridiano** (propuesta v2: Strain + reloj Sobrecalentamiento, modos **Cenit** / **Nadir**) |
| **Eje central** | **Menos fuerza → más control** vs **más fuerza → menos control / coste en vida o estabilidad** |
| **Bond** | The Outsider (+1d a preparar a otros; second wind por escenas sin usar lo “único”) |
| **Poder narrativo incompleto** | Open Up — completar texto desde Roll20 cuando haya captura |

Datos técnicos del repo: `scripts/character-bundles/judeth-kalain.bundle.json` y
docs en `abilities` con prefijo `judeth-`.

---

## Eje mágico: potencia · control · coste

1. **Core volátil**  
   La reserva interna es inestable. “Apagar” el caos no es gratis: implica
   **fragmentar** el flujo en gemas, **ritmo** de gasto obligatorio, y
   consecuencias si el canal queda a medias (gemas sobrantes, backfire de
   Anathema, daño por relanzar con Alternate Ending).

2. **Anchor (revólver de control)**  
   Modo de juego: **bajar potencia / alcance máximo** para **subir** boons,
   True Strike, Divine solo al máximo de inversión, daño predecible. Narrativo:
   cada gema **aumenta estabilidad** pero **reduce efectividad o alcance**.

3. **Anathema (revólver de potencia)**  
   Modo de juego: **subir daño y alcance** a cambio de **pérdida de control**:
   tiradas de riesgo por gema, posible daño a aliados o efectos adversos a
   discreción del GM. Narrativo: más gemas = **más alcance y violencia mágica**,
   **menos** agarre del caos.

4. **Regla de carga ZARC**  
   El modo (**ANCHOR** vs **ANATHEMA**) se declara **al cargar** las gemas, no
   al disparar: la decisión de “¿cómo voy a jugar esta escena?” va **antes** del
   tiro táctico.

---

## Cómo usar esta skill para **crear** contenido nuevo

Cuando propongas un **trait**, **ability**, **upgrade**, **segundo job** o
**reescritura** para Judeth, el borrador debe explicitar:

1. **Pregunta narrativa** — ¿Qué dilema de escena introduce? (proteger vs
   destrozar, retirarse vs quemar recursos, confiar en aliados vs arriesgarlos.)
2. **Lugar en el eje** — ¿Empuja hacia Anchor (control), hacia Anathema
   (voluntad bruta), o cruza ambos en la misma acción?
3. **Coste honesto** — Esfuerzo, strain, gemas sobrantes, daño Divine a sí o a
   cercanos, teleports arriesgados, etc.
4. **Compatibilidad ICON** — Etiquetas, acciones, fray/boons donde aplique;
   números marcados como homebrew si no calzan con tablas oficiales.

**IDs Firestore** sugeridos: prefijo `judeth-` + slug (`judeth-trait-…`,
`judeth-ability-…`) y actualizar `unlockedAbilities` / `allAbilities` en el
personaje más el doc en `abilities`.

---

## Referencias cruzadas

| Necesidad | Skill |
|-----------|--------|
| Wright genérico / tono de clase azul | `icon-class-wrights` |
| Acciones narrativas, riesgo/efecto | `icon-narrative-system` |
| Jobs, AP, multiclass | `icon-jobs-progression` |
| Modelo de datos VTT, bundles, import | `pixi-map-ttrpg` |

---

## Recordatorio legal

No pegar texto completo con copyright de libros ICON en el repo. Resúmenes y
mecánicas de mesa propia sí.

---

## Matriz de habilidades propuesta (completa, homebrew Valt6)

Árbol lógico del VTT: `ultimate` = Limit Break; `ability` = concepto activo;
`upgrade` / `mastery` enlazan con **`parentId` = `key` del padre**. Payload
actualizado en **`judeth-kalain-matrix-proposal.json` (proposalVersion 3)**.

### Limit Break — **CONSUMO PARALELO** (`judeth-lb-consumo-paralelo`)

Redacción en **pasos numerados** (mesa; homebrew Valt6).

| Paso | Regla |
|------|--------|
| **Coste** | **1× combate.** Pagás **Resolve** del LB (tabla mesa). **+2 Strain** al activar (upgrade **Precio leve** → +1). |
| **Defiance** | Mientras dure el **estado**, si un **daño** te dejaría en **0 HP o menos**, quedás en **1 HP** (no bajás de 1 por ese golpe). No cubre otros finales (veneno, narrativa, etc.) salvo que la mesa diga lo contrario. |
| **Estado** | **Consumo paralelo.** **Duración base:** hasta el **final de tu próximo turno**. Upgrade **Ventana larga:** hasta el **fin de la ronda en curso**. |
| **Efecto principal** | En **cada turno tuyo** dentro de la duración: hasta **2 Attacks** con revólver (**Anchor** y/o **Anathema**), con costes normales de cada habilidad (gemas, acciones, tiradas). **Una composición por turno:** Anchor×2 **o** Anathema×2 **o** Anchor×1 + Anathema×1; orden libre en el turno. |
| **Fin** | Al vencer la duración, deja de aplicar el **Defiance** de este LB (salvo otra fuente). |

| Tipo | Nombre (key) | Efecto |
|------|----------------|--------|
| `upgrade` | **Ventana larga** (`judeth-lb-up-doble-turno`) | El estado termina al **fin de la ronda en curso** en lugar del final de tu próximo turno. |
| `upgrade` | **Precio leve** (`judeth-lb-up-precio-leve`) | El Strain al activar es **+1** en lugar de **+2**. |
| `mastery` | **Circuito cerrado** (`judeth-lb-ma-circuito-cerrado`) | **Cuando** termina *Consumo paralelo* en esa activación: hasta **fin de combate**, **no** recibís **daño** por **descontrol** de tus mecánicas ZARC (riesgo Anathema que te pegue, Alternate Ending si aplica a vos, etc. — lista con GM). **Restricción:** no **sobrecargás**: sin modo **ANATHEMA**, sin resolver **Anathema**; **solo** **ANCHOR** y líneas de **control** que valide la mesa. |

### Revólver **ANCHOR** (concepto ya existente)

| Tipo | Nombre (key) | Idea |
|------|--------------|------|
| `upgrade` | **Trazo corto** (`judeth-anchor-up-trazo`) | **Cover** leve ignorado en ese **ranged Attack** si la mesa valida línea de tiro clara. |
| `upgrade` | **Segundo cerrojo** (`judeth-anchor-up-cerrojo`) | Con **1** gema: +1 **boon** extra si no usás **Into the Abyss** en el mismo turno. |
| `mastery` | **Retorno en cerrojo** (`judeth-anchor-ma-retorno`) | 1× combate: tras **miss** con Anchor, hasta inicio de tu próximo turno +1 **boon** al primer **Dodge** **o** al primer **ranged attack roll** (elige cuál consume el bonus). **Sin terreno.** |

### Revólver **ANATHEMA** (concepto ya existente)

| Tipo | Nombre (key) | Idea |
|------|--------------|------|
| `upgrade` | **Ruido de fondo** (`judeth-anathema-up-ruidofondo`) | Antes de tirada de riesgo por gemas: número 1–6; si coincide con un dado de la piscina, **reroll** de ese dado (mesa elige cuál). |
| `upgrade` | **Canal compartido** (`judeth-anathema-up-canal`) | **Divine** por resultado ≤4: aplica primero a Judeth; **excedente** puede afectar aliado más cercano. |
| `mastery` | **Umbral rojo** (`judeth-anathema-ma-umbral`) | 1× combate: **Strain** para tratar **≤4** como **≤3** en **esa** resolución de riesgo **solo para ti**. |

### Rifle **MERIDIANO** — segundo sistema de armas (no ZARC)

Judeth **fabrica o recupera** un **rifle de precisión Meridiano**: recurso
**Strain** + **reloj Sobrecalentamiento** (ticks **solo en la ficha de Judeth**),
sin gemas ZARC. Filosofía distinta a los revólveres:

| Sistema | Revólveres Anchor/Anathema | Rifle Meridiano |
|---------|---------------------------|-----------------|
| Recurso | ZARC-gems, carga **dual mode** al preparar | **Strain** + **reloj** personal |
| Ritmo | Picos por disparo, riesgo **explícito** en Anathema | **Sostenido** (Cenit) vs **bifurcado** (Nadir) |
| Rol de mesa | Spike / control binario | **DPS monobjetivo** (stack +fray cap) **o** **fork** multiobjeto con **tax** de **boon** |

| Tipo | Nombre (key) | Efecto (resumen técnico) |
|------|--------------|--------------------------|
| `ability` | **MERIDIANO · CENIT** (`judeth-ability-meridiano-cenit`) | **Ranged Attack** single-target; **light/heavy/miss**; **stack +fray** mismo objetivo (cap +3, reset miss o cambio de target); **Sobrecalentamiento +1** por uso. |
| `upgrade` | **Lock-on persistente** | Stack no resetea en miss por **Dodge**. |
| `upgrade` | **Banco de gatillo** | +1 **boon** al primer Cenit del turno si no te moviste antes en ese turno. |
| `mastery` | **Saturación térmica** | 1× combate: con stack en cap, **heavy** añade **Divine = fray** o sube **tier** de daño (mesa). |
| `ability` | **MERIDIANO · NADIR** (`judeth-ability-meridiano-nadir`) | **Ranged Attack fork**: reparte **light** entre **dos** targets en **misma banda**; **–1 boon** al roll; **miss** → +1 **Strain**; mismo reloj Sobrecalentamiento. |
| `upgrade` | **Tercer carril** | +1 Strain al declarar: **tercer** objetivo en banda adyacente, **–2 boons** totales (floor mesa). |
| `upgrade` | **Freno de doble fallo** | Si ambos del fork **miss**, **1 Strain** total. |
| `mastery` | **Ráfaga contable** | 1× combate: el fork cuenta como **dos** **ranged Attacks** para reglas de **Combo** (si existen en mesa). |

### Tercera línea — **LÍNEA CAUSAL** (no es un tercer cañón: es el **entre-disparos**)

Geometría mágica: **unís** dos puntos ya cargados de tensión (impactos recientes,
Judeth y un aliado, dos runas, etc.) con un **hilo** de gemas. Quien lo cruza
abre consecuencia leve (exposición, retraso, daño fray).

| Tipo | Nombre (key) | Idea |
|------|--------------|------|
| `ability` | **LÍNEA CAUSAL** (`judeth-ability-linea-causal`) | 1–2 acciones, **1 gema**; trazás hilo entre dos **fuentes** válidas; primera travesía activa efecto leve acordado con GM. |
| `upgrade` | **Hilo tenso** (`judeth-linea-up-tenso`) | Primera travesía aplica **Exposed** (o tag equivalente) al que cruza. |
| `upgrade` | **Triángulo imposible** (`judeth-linea-up-triangulo`) | 2ª gema: tercer punto; el interior **dificulta Rush** una vez en la escena. |
| `mastery` | **Telaraña** (`judeth-linea-ma-telarana`) | 1× combate: si **dos** hilos se cortan en el mismo espacio/hostil, aplicas **doble** exposición ficticia o derribo narrativo. |

### Cuarta línea — **RESPIRO DEL NÚCLEO** (ventileo sin proyectil)

**Cámara vacía** ritual: sangrás presión del núcleo **sin** disparar por cañón;
es “me doy un latido de silencio antes de que el caos elija por mí”.

| Tipo | Nombre (key) | Idea |
|------|--------------|------|
| `ability` | **RESPIRO DEL NÚCLEO** (`judeth-ability-respiro-nucleo`) | 1 acción, 1–2 gemas **sin** ataque de Anchor/Anathema; reduces Strain propio o un reloj leve “volátil” de Judeth (GM). |
| `upgrade` | **Aliento ajeno** (`judeth-respiro-up-ajeno`) | Aliado en **Close** puede pasar **1 Strain** a una escena compartida (ficción + GM) en lugar de Judeth absorberlo todo. |
| `upgrade` | **Silencio cargado** (`judeth-respiro-up-silencio`) | Si al **siguiente** turno no disparás Anchor/Anathema, tu próximo **set-up** narrativo (Charm, preparar, etc.) gana +1d ficticio. |
| `mastery` | **Tregua de cañón** (`judeth-respiro-ma-tregua`) | 1× acampamento: cerrás un peligro tipo **Meltdown** en Judeth sin tirada si la mesa acepta que pagaste gemas + escena sin violencia mágica previa. |

### Desbloqueo sugerido (progresión)

| Tier | Contenido desbloqueado en `unlockedAbilities` |
|------|-----------------------------------------------|
| **Inicio** | Raíz de clase + 3 traits + Anchor + Anathema (como ahora). |
| **Tras arco corto** | LÍNEA CAUSAL + sus 2 upgrades (mastery al clímax del arco). |
| **Tras confianza del grupo** | RESPIRO DEL NÚCLEO + upgrades; mastery en capítulo largo. |
| **Clímax / capítulo** | CONSUMO PARALELO + upgrades; mastery **Circuito cerrado** en hito mayor. |
| **Tras obtener Meridiano** (arco ítem) | Cenit + Nadir + upgrades según progresión; masteries en capítulos largos. |
| **Por árbol** | Masteries de Anchor/Anathema cuando la mesa vea el **coste** asumido en juego. |

### Payload listo para Firestore

Ver `scripts/character-bundles/judeth-kalain-matrix-proposal.json`
(**proposalVersion 3**): LB **CONSUMO PARALELO** (2 ataques/turno, Defiance,
Strain), mastery **Circuito cerrado**, rifle Meridiano, etc.
