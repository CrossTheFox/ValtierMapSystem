---
name: valtia-facciones
description: >-
  Facciones Valtia-01: Margalous, Pecados, Mártires, Motor Zarken, conflictos.
  Usar al escribir intriga, NPCs de poder o consecuencias políticas.
disable-model-invocation: true
---

# Valtia-01 — Facciones y poder

## Linaje Margalous

- **Descendientes directos de los Zarken** — los Zarken eligieron un grupo de criaturas para tener descendencia; **Margalous** era el apellido de esas familias.
- Familia Principal ~50 % sangre; Secundaria ~25 %.
- **Incesto prohibido** (riesgo Zarken puro). Ver `valtia-historia` (Felicia, Oni).

| Personaje | Rol |
|-----------|-----|
| **Zorgun** | Rey; más poderoso de Valtia; depresión post-Felicia |
| **Oni** | Heredera; **Zarken**; sin concepto aún; clave por visión/linaje |
| **Felicia** | Reina muerta; visión: Oni destruye el planeta |

## Zarken fundadores

**Zaakhiel, Juuhndy, Elekhias, Zerynhya** — todos **muertos**.

## Los Pecados (Mirage)

- **7 Pecados** + **Zero** como 8.º («pecado original»).
- **Maldición/concepto** otorgable; creados por Zarken; **no heredables**, **transferibles**.
- **Cargo reemplazable:** habitantes de Mirage pasan pruebas extremas; pierden mitad del alma; cuando el pecado los controla, no pueden oponerse.
- Gobernan **en público**; **Zero** oculto — conciencia al servicio de deseos Zarken instaurados.
- **Eins** en Techia: **espionaje** (y atentado Morgyns — objetivo retenido).
- **Zwei** = Pecado de la **Ira**.
- Monoconcepto muy desarrollado **puede superar** a un Pecado.

## Los Mártires

**Movimiento / pseudo-religión** — no solo tres personas. Comparten diagnóstico (nueva era Zarken), **no la misma solución**. Aliados por necesidad, rivales por convicción; si hubiera que elegir entre candidatos, la alianza se rompería.

| Mártir | Filosofía | Candidato preferido | Base |
|--------|-----------|---------------------|------|
| **Naylus** | Nuevo orden Zarken; pragmático; resultado > método; manipularía Oni o Zaim | Estabilidad | Encubierto en **Galathia** |
| **Engel** | Sufrimiento = abandono de débiles; autoridad Zarken absoluta; ex-**Señora de la Guerra** (docenas de resurrecciones forzadas — ver `valtia-muerte-reaktis`) | **Zaim** (heredero por haber sufrido) | **Lorven** (+ Techia) |
| **Zero** | Restaurar voluntad original del Imperio Zarken | **Oni** (Familia Principal) | **Mirage** |

**PJs:** pueden comulgar con la ideología o ser Mártir; hay consecuencias y fricción, **no guerra automática** con los otros.

## Conflictos actuales

1. **Galathia vs Mirage** — escalada por **inacción de Zorgun** tras muerte de Felicia.
2. **Guerra ideológica Mártires** — tres futuros Zarken incompatibles.
3. **Techia**: atentado Morgyns/Leonhard — **objetivo no documentado** (retener).

## Motor Zarken

- Arma disuasoria Galathia; poder real → aniquilación casi total de ciudad.
- **Nunca disparado.**

## Pendiente (cuestionario reducido)

- Facción rival en corte Galathia.
- Roles de Garrus, Strix, Ardellis, Vraksis, Zaim.
- Caelum / Nyssara.
