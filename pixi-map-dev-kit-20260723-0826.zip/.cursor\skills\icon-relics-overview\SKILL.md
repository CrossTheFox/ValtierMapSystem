---
name: icon-relics-overview
description: >-
  ICON Relics: acquisition levels, dust infusion cadence, three ranks, Aspect
  unlock, invoke types (Attack, Gambit, Round), changing relics at job milestones,
  and design patterns for named relics. Use when writing relic cards, UI for
  relic slots, or loot progression—not for core job abilities.
disable-model-invocation: true
---

# ICON — Relics (economy & invoke patterns)

*Sources: `docs/icon/ICON Relics.pdf` + relic section in `ICON Jobs.pdf`.*

## Acquisition

- Characters choose a relic at **levels 2, 6, and 9** (see also Jobs booklet).
- **Swap** relics at **levels 4 & 8** when changing jobs — new relics start
  **un‑infused** at rank I if swapped.

## Ranks & dust

- **Rank I–III** on the track; unlock higher ranks by spending **Dust**
  (typical: **6 dust** each for II and III in the relics booklet summary).
- Small dust drip from tactical combats; rest from narrative/campaign rewards.

## Aspect (IV)

- Unlock via **12 dust** **or** a **legendary aspect quest** (GM-tuned).
- After **any** character completes a given relic’s aspect quest once, others
  aspect that relic for **4 dust** instead of 12.

## Invoke types (combat)

1. **Attack invoke:** check **raw d20** threshold (not total attack) after roll;
  auto-hit attacks still roll d20 to check.
2. **Gambit invoke:** condition; **once per combat** unless explicitly refreshed.
3. **Round invoke:** automatically on listed round onward.

## Writing / coding a relic card

Suggested fields:

- **Name / form** (weapon, armor, jewelry, etc.)
- **Rank I–III** passive lines + invoke line(s)
- **Aspect** bonus + suggested quest hook
- **Dust track** UI state + `invokeUsedThisCombat` flags

## Named examples (headlines only)

The PDF lists many relics (e.g. **Ape God**, **Crimson King**, **Erys**, …) with
ranked perks — **open the PDF** when you need exact numbers; keep generated
helpers **paraphrased** unless the user confirms private use.

## Links

- Job timing & expedition rules → `icon-jobs-progression`
- Keyword meanings (pierce, defiance, etc.) → `icon-combat-glossary`
