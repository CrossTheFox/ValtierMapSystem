---
name: valtia-magia
description: >-
  Sistema mágico completo de Valtia-01: afinidad física/etérea, magia aprendida,
  conceptos inherentes (1-3), Pecados, Intercambio Equivalente/Ciego, medición
  de coste. Usar al diseñar hechizos, PJs, NPCs, combate ICON o validar poder.
disable-model-invocation: true
---

# Valtia-01 — Sistema de magia

## Referencia rápida

| Pregunta | Respuesta canon |
|----------|-----------------|
| ¿Quién tiene magia? | **Todos** — vivos, muertos (resquicios), inteligentes o no |
| ¿Mana? | **No.** Solo **pago** por Equivalente + agotamiento físico |
| ¿Zona sin magia? | **No** existe cero absoluto; cárceles **atenuan** mucho |
| ¿Afinidades? | **Física** (interior) / **Etérea** (exterior); **se elige** y entrena |
| ¿Conceptos? | **1–3** por mortal; aparecen **con el tiempo**; Zarken puro ≈ **10** |
| ¿Pecados? | Conceptos **no heredables**, **transferibles**, poder inmenso |
| ¿ICON en mesa? | Habilidades ICON = **formas de usar el concepto**; resto narrativo |

---

## 1. Intercambio Equivalente

**Ley natural** (como gravedad): todos la viven; no todos conocen todas las implicaciones.

- **Imposible eludir el pago.** Siempre se paga; a veces no se **nota** en qué.
- Se puede **sortear hacia dónde** cae el coste (base del Ciego).
- **Descansar** mitiga coste acumulado (como recuperarse de entrenamiento), no «recarga mana».

### Medición

- Expertos e instrumentos (Techia) estiman coste — como **calorías**: útil pero no exacto al órgano/extremidad.
- No hay precisión quirúrgica del «qué quema más».

### Costes prohibidos socialmente

- **Niños en alquimia**: sumamente prohibido; existen **agujeros legales** («beneficiar» al niño).
- Ejemplo Naylus: quitar **trauma** o usar trauma como **anti-coste** para regenerar — sigue siendo quitar algo (memoria de padres, etc.).
- **Intercambio injusto**: usar a otros para pagar por ti.

---

## 2. Agotamiento (no mana)

La magia es **extensión física**. Correr maratón no «se acaba el mana de correr»: te **agotas** o **pagaste demasiado**.

---

## 3. Afinidad física vs etérea

| | Física | Etérea |
|---|--------|--------|
| Canal | Cuerpo | Entorno |
| Estigma social | **Ninguno** entre vías |
| Guerrero + hechizos | **Sí**, con techo **muy bajo** |
| Regla jarra | Comparte lógica de recurso finito con entrenamiento |

**Guerrero etéreo avanzado:** NUNCA alterará tiempo levemente **sin abandonar por completo** la afinidad física.

### Enseñanza

- Academias, escuelas privadas, hogar.
- **Tech-magia** dispara hechizos sin aprender (como pistola vs armero): funciona, pero sin profundidad si falla.

### Hechizos

- Complejos: gestos; **catalizadores no inherentes** (opcionales por comodidad).
- **Rituales**: componentes, gestos, palabras/lenguas exactas.

### Escuelas elementales

- **Combinaciones infinitas**, **techo común** estándar.
- Ej.: control de agua → sangre posible, pero oponente más fuerte **supera** el control (duele).

### Techia

- Magia etérea como **ciencia replicable**.

---

## 4. Conceptos inherentes

### Origen

- **Herencia** y/o **despertar** (entrenamiento, vivencia).
- **Descubrir e interpretar** — pueden **malinterpretarse** (¿espacial? ¿velocidad? ¿invisibilidad?) — corroborable.

### Nombre y unicidad

- Cada portador **expresa a su gusto**; estudiosos nombran.
- **Mismo concepto, distintas manifestaciones** (Zorgun vs su madre: Momentum cuerpo a cuerpo vs proyectiles).

### Registro

- **Voluntario**; a veces herramienta política/diplomática.

### Tabú

- **No hay conceptos prohibidos.** Algunos «mal vistos»; escasez hace prohibición impráctica.

### Sangre Zarken

- Más sangre → más **potencia** y más **conceptos** en tendencia.
- **Zarken puro**: ~10 conceptos; pueden destruir ciudades con esfuerzo casi nulo. Reglas finas no necesarias en mesa.

### Sacrificio de concepto

- Posible por **Equivalente de gran proporción** (ej. poder de Zorgun ≈ revivir **ciudad entera** de civiles).

### Progresión

- Entrenamiento, revelación, trauma — **depende del personaje**.

### vs Pecados

- **Monoconcepto al techo puede superar a un Pecado.** Pecado = ventaja inicial, no victoria garantizada.

---

## 5. Los Pecados (magia especial)

- **Maldición/concepto** otorgable a individuos.
- Creados por Zarkens; **no heredables**, **sí transferibles**.
- Poder inmenso; en campaña: metáfora y literal.

---

## 6. Intercambio Ciego

- **Naylus**: teoría más reciente e importante; **no único** practicante.
- «Coste negativo» no tan raro, pero **sin facciones masivas**.
- Coste desplazable en **tiempo, forma y objetivo**.
- **Deja huella**: sanidad mental del alquimista; si eres consciente, puedes **desplazar también ese coste**.
- **Recuerdos**: base del Ciego de Naylus (ver ejemplos niños).

**Nightmares ≠ cobradores** del Ciego.

---

## 8. Muerte, Reaktis, Reakta

Ver skill dedicado **`valtia-muerte-reaktis`**.

| Tema | Resumen |
|------|---------|
| Más allá | Alma → cielo / infierno; religión conoce resurrección |
| Reaktis | Restaurar vida plena; universo rechaza; ~2 % entidad incorrecta |
| Reakta (Techia) | Legal, cara, Gabinete; <1 h, catalizador vital, pago material |
| Necromancia | **Tabú extremo**; sacrificios inocentes |
| PJs | Estudian lore; no replican resurrección; posible en mesa con coste enorme |

---

## 7. ICON / mesa

- PJs **asumen conceptos**; magia mundana no necesita reglas aparte.
- **ICON**: combate narrativo; habilidades = **expresiones del concepto**.

---

## Ejemplos canon

| Personaje | Magia |
|-----------|--------|
| **Zorgun** | Momentum (techo no alcanzado por depresión) |
| **Oni** | Sin concepto; física + espadón (cortes distancia, teletransporte) |
| **Felicia** | Visiones (linaje / naturaleza Oni) |

Ver plantillas en secciones finales del skill anterior o `valtia-worldbuilding-respuestas.json`.
