# Casos de prueba IA — Referencia para evaluación y memoria

*Prompts validados manualmente que producen resultados útiles en el laboratorio de IA narrativa.*  
*Última actualización: 2026-06-12*

---

## Propósito

Repositorio de instrucciones de ejemplo para:

- Probar modos **Ondas narrativas** (`narrative_impact`) y **Onda catalizadora** (`cascade`)
- Repetir escenarios durante el protocolo de evaluación
- Documentar en la memoria casos reales de la campaña Valt6-01

---

## Caso 01 — Revelación Zorgun / Felicia / Oni

**Estado:** Validado — funciona muy bien.

**Entidades implicadas:** Zorgun (padre), Oni (hijo/hija), Felicia (madre de Oni, esposa de Zorgun)

**Tipo de escena:** Revelación con ambigüedad moral (asesinato como «salvación»)

**Modo recomendado:** `cascade` o `narrative_impact`  
**Ancla sugerida:** Oni o Felicia

### Prompt (instrucción libre)

```
Se descubre que Zorgun, el padre de Oni, asesinó a Felicia, su esposa (y madre de Oni) para salvarla, ya que esta quería asesinarla.
```

### Por qué es un buen caso de prueba

- Activa **múltiples relaciones familiares** en el subgrafo (padre–hijo, cónyuges, víctima)
- Fuerza **reacciones en cadena** en personajes vinculados (aliados, organizaciones, testigos)
- Contradicción moral clara: el crimen como acto de «protección»
- Útil para medir si la IA respeta entidades del contexto y propone cambios de relación plausibles

### Notas para la evaluación

Registrar tras cada corrida (UI o CLI):

| Métrica | Valor |
|---------|-------|
| `validación ok` | sí / no |
| `missingImpacts` | lista o «ninguno» |
| Relaciones aplicadas | N propuestas / M aceptadas |
| Evento creado | sí / no (botón TIMELINE) |
| Regeneraciones | número |
| `confidence` predominante | alta / media / baja |

**Comandos de regresión:**

```bash
npm run test:memoria
npm run test:caso01:context
# Con IA (requiere GEMINI_API_KEY en .env):
node scripts/testSituationPrompt.mjs --anchor=oni --mode=cascade --local \
  --instruction="Se descubre que Zorgun asesinó a Felicia..." --generate
```

- Comparar reacciones de Oni vs. terceros conectados en el grafo

---

## Historial

| Fecha | Cambio |
|-------|--------|
| 2026-06-11 | Caso 01 añadido (prompt validado en sesión de prueba). |
| 2026-06-12 | Plantilla de evaluación + comandos de regresión automatizados. |
