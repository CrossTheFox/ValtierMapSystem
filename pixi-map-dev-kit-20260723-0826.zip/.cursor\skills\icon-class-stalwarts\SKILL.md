---
name: icon-class-stalwarts
description: >-
  ICON Stalwart class (red jobs): Bastion, Demon Slayer, Colossus, Knave; Armor 2,
  Fortify, Rush, Heroics class mechanic; focuses Slashed/Weakened, Rampart,
  Vigilance, Shove, Sturdy, True Strike; foil vs skirmishers/artillery. Use when
  designing or auditing red-class abilities, traits, or limit breaks.
disable-model-invocation: false
---

# ICON — Stalwart class & jobs (red)

*Source: `docs/icon/ICON Book Stalwarts.pdf` + job list in `ICON Jobs.pdf`.*

## Class fantasy

Weapon masters who **control space**, **protect allies**, **shove** enemies into
hazards, and **tank** — lower mobility vs ranged skirmishers unless using **Rush**
lines.

## Class traits (pattern)

- **Armor 2** baseline mitigation.
- **Fortify:** adjacent spaces gain **Rampart**; gain **Vigilance +1** end of turn.
- **Rush X** baked into many kits (see glossary).
- **Heroics:** class mechanic — Stalwart jobs each define *how* you trigger
  heroic lines on abilities; cross-class Stalwart dips get simplified **Stalwart
  Gambit** (one free heroic trigger / combat — confirm exact wording in PDF when
  balancing).

## Class stats template (defaults)

From class header: **VIT 10 / HP 40 / Def 6 / Speed 4 (Dash 2) / Fray 4 / D6 /
Basic attack range 3** — individual jobs may shift emphasis via abilities.

## Status & effect focus

- **Slashed** punishes movers; **Weakened** shrinks enemy damage; many **Stun**
  lines.
- **Rampart / Vigilance / Shove / Sturdy / True Strike** — see
  `icon-combat-glossary`.

## Jobs in this class

| Job | Pitch (one line each) |
|-----|-------------------------|
| **Bastion** | Greatshield knight; shove + collide control, auras, interrupts |
| **Demon Slayer** | (read PDF) anti‑blight hunter toolkit |
| **Colossus** | (read PDF) massive presence / heavy control |
| **Knave** | (read PDF) rogue‑ish red — still Stalwart color |

When writing **new** red abilities, keep **geometry** (shove vectors, collide
triggers) and **heroic** payoffs central.

## Limit break pattern

Each job defines **Limit** + **Ultimate (chapter 3)** — costs usually include
**resolve**; upgrade at chapter gate.

## Links

- Keywords → `icon-combat-glossary`
- AP / expedition color rule → `icon-jobs-progression`
- Router → `icon-ttrpg-index`
