---
name: valtia-setting
description: >-
  Línea temporal y setting completo de Valtia-01: llegada Zarken, exterminio
  humano, Imperio, Diluvio Rojo y era actual en Wernegar. Usar al escribir
  historia del mundo, flashbacks, crónicas o contexto de campaña Valt6.
disable-model-invocation: true
---

# Valtia-01 — Setting y línea temporal

## Premisa en una frase

El planeta no siempre fue humano: una invasión Zarken casi borró a la humanidad, levantó un imperio que rozó las estrellas, fue castigado por fuerzas trascendentes, y hoy Wernegar sobrevive en fragmentos bajo el misterio del domo de Valtia.

## Era 0 — Cielos humanos

La humanidad alcanzó alturas tecnológicas antes de que los reinos actuales existieran. Ciudades, redes globales, y una civilización capaz de mirar al cosmos con confianza.

## Era I — Llegada y evento primordial (Conquista Zarken)

Los **Zarkens** llegaron: humanoides de 3–4 m, cuernos, apariencia antropomórfica demoniaca/animal. Especie **longeva en extremo** y **numéricamente escasa** (pocos miles; las generaciones se conocen entre sí — un recién nacido puede conocer a tatarabuelos vivos).

Evaluaron a la humanidad como **estorbo**, pero con **inteligencia útil para esclavitud**. Su agresividad extrema los llevó a **exterminar al 99,99999 %** de la población humana.

Con la fauna local aplicaron **evolución acelerada** mediante **sangre Zarken** (propiedades nocivas para otras especies; considerada «demoníaca»). Crearon linajes serviles, bestias de guerra y mascotas.

Levantaron una civilización **organizada, eficiente y brutalmente efectiva**: no hordas salvajes, sino imperio con estructuras monumentales. Redujeron a los humanos sobrevivientes a **esclavos o mascotas**.

## Era II — Imperio Zarken

- Tecnología sumamente avanzada, fusionada con magia.
- Sociedad que **rozó lo perfecto**; casi tocaron las estrellas.
- Dominio planetario; el mundo dejó de ser «humano» en espíritu y demografía.
- Corazón del poder: **Wernegar**, bajo el **cónsul** de la dinastía Wernegar (Zartiel Wernegar entre sus figuras legendarias).

## Era III — Observación y castigo

Algo **trasciende estrellas y límites humanos** observó lo que los Zarkens habían construido. No fue guerra: fue **castigo**.

### Diluvio Rojo

Lluvia carmesí sin descanso sobre todo el mundo. Corrompió la tierra, apagó la tecnología, exterminó vida a escala planetaria. Ciudades colapsaron; lo «eterno» desapareció en días. El planeta fue dado por muerto.

## Era IV — Supervivencia y el domo

- Unos **pocos cientos** de humanos/híbridos sobrevivieron dispersos (cuevas, subsuelo).
- Un **grupo pequeño de Zarkens** huyó a una región montañosa aislada en Wernegar.
- Con vestigios de tecnología inacabada levantaron un **domo mágico casi impenetrable**.
- Dentro: **miles** de criaturas — humanos, híbridos, Zarkens. **Único bastión imperial** que sobrevivió intacto.

Los Zarkens supervivientes pasaron de conquistadores a **guardianes** de lo que quedó. No por bondad: comprendieron que **el mundo que crearon fue observado, juzgado y borrado**.

## Era V — Fundación de Valtia (interior del domo)

Tras el Diluvio, el bastión bajo el domo dejó de ser solo refugio: se convirtió en **Valtia**, región aislada donde nació una civilización propia.

- **Zarken fundadores** dieron forma a las polis: Zaakhiel → Galathia; Elekhias → Mirage; Zerynhya → Pecados.
- **Seis ciudades** compiten hoy: Galathia, Techia, Mirage, Lorven, Germa, Arvek (ver `valtia-ciudades`).
- Magia regida por **Intercambio Equivalente**; variantes peligrosas (Intercambio Ciego, sangre Zarken).
- Calendario actual: **7036 D.Z.**

## Era VI — Wernegar exterior (contexto periférico)

Fuera del domo, **Wernegar** sigue siendo tierra fragmentada: poblados aislados, fauna mutada, ICONs como élite móvil (ver `valtia-wernegar`). Desde fuera, Valtia se ve como brillo fucsia evitado; desde dentro, es el mundo político principal de la campaña.

## Presente de campaña (7036 D.Z.)

- **Conflicto Galathia vs Mirage**; guerra ideológica de **Los Mártires**.
- PJs fugados de Galathia rumbo a **Techia** (atentado, **Eins** en la ciudad).
- Ver snapshot vivo → `valtia-estado-actual`.

## Tensiones abiertas (no resolver sin mesa)

- ¿El castigo cósmico terminó o Valtia concentra el último capítulo?
- ¿Oni Margalous es salvación o detonante?
- ¿Los Pecados restantes (más allá de Zero/Eins/Zwei)?
- ¿Verdad detrás de la amnesia de Nyssara y Caelum?

## Referencia cruzada

- Detalle Zarken → `valtia-zarkens`
- Diluvio y teología del castigo → `valtia-diluvio-rojo`
- Ciudades y facciones → `valtia-ciudades`, `valtia-facciones`
- Wernegar exterior → `valtia-wernegar`
- Domo y región → `valtia-region-valtia`
- Resumen autor → `Valtia_Resumen_General.md`
