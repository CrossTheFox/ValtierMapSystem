---
name: valtia-region-valtia
description: >-
  Región Valtia bajo el domo: límites, salida a Wernegar, percepción valtiense,
  infraestructura. Usar al narrar viajes, frontera o identidad regional.
disable-model-invocation: true
---

# Valtia-01 — Región Valtia (interior del domo)

## Límites

- **Valtia = solo interior del domo.** El domo se forjó para **toda** la región.
- **Domo fucsia visible** desde dentro y fuera.
- **Tiempo**: igual que exterior.

## Las seis ciudades

Todas **bajo el domo** — metrópolis interconectadas (ver `valtia-ciudades`).

## Wernegar exterior (vista valtiense)

| Creencia popular | Realidad de mesa |
|------------------|------------------|
| «Desierto de indígenas» | Lore de fondo; **no jugable** |
| Sitio donde Zarken escaparon y Diluvio arrasó | Coherente con canon |
| Inútil e irrelevante | Salir es **posible pero difícil e inútil** |

Quienes salen **regresan en días**; no interactúan con locales — analogía: país de riquezas vs ir a un desierto vacío.

- **Sin comercio clandestino** domo ↔ exterior.

## Infraestructura

- Teletransporte urbano común; interciudad en desarrollo (Techia).
- Agricultura suficiente + aceleración magia/tech; **sin hambre** generalizada.

## Tono

Civilización **multipolar** con horror cósmico en el pasado y **Nightmares** en el presente — no wilderness ICON exterior (Wernegar periferia = lore).
