---
name: icon-bonds-overview
description: >-
  ICON Bonds: what a Bond sheet contains (ideals, gear kits, effort/strain,
  burdens, ambitions, twelve action ratings, bond powers, session XP questions).
  Use when creating or reviewing narrative characters, bond powers, or camp
  economy tied to Bonds—not for tactical job abilities.
disable-model-invocation: true
---

# ICON — Bonds (structure & play patterns)

*Source: `docs/icon/ICON Bonds.pdf`.*

## What a Bond is

A **Bond** is the narrative **archetype path** of the hero: it grants **ideals**,
**gear packages**, **special recovery rules**, **bond powers**, and a **+2**
starting concentration in one of two preferred **actions**.

## Common sheet elements (pattern)

- **Ideals:** three bullet prompts that award XP when hit in play.
- **Gear:** themed kits (Adventurer’s + path-specific kits) plus loose gear
  slots.
- **Effort / Strain / Burdens / Ambitions:** track narrative pressure and long
  arcs (exact numbers on sheet).
- **Actions:** same twelve actions as narrative play; dot ratings **0–4**
  (with creation caps from Make Narrative Character).
- **Bond powers:** chapter-gated perks; some bonds reference **Gambit of Gaia**
  style capstones.

## Session XP hooks (typical categories)

Examples from the book’s structure (wording varies by bond): ideals fulfilled,
character tested, ambitions advanced, burdens invoked — each bond’s sheet lists
its own **End of Session** questions.

## Using this skill in Cursor

- **Do** help players phrase **ideals**, pick **kits**, or design **custom gear**
  lines that match tone.
- **Do** summarize how a **bond power** might interface with a scene (without
  copying full power text verbatim into public artifacts).
- **Don’t** dump the entire PDF of powers into code or public docs.

## Bond paths (names)

The PDF enumerates multiple paths (e.g. **Pathfinder**, **Seeker**, … — each
with its own ideals, kits, and power list). When a user names a path, **read the
local PDF section** for specifics; this skill only encodes **shared anatomy**.

## Cross-links

- Action resolution → `icon-narrative-system`
- Tactical jobs → `icon-jobs-progression` + `icon-class-*`
