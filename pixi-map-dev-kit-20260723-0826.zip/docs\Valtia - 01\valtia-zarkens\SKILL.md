---
name: valtia-zarkens
description: >-
  Especie Zarken en Valtia-01: fisiología, sangre, 10 conceptos puros, Pecados,
  linaje Margalous. Usar al crear NPCs Zarken o tabúes de sangre.
disable-model-invocation: true
---

# Valtia-01 — Los Zarkens

## Fisiología

| Rasgo | Canon |
|-------|--------|
| Tamaño | 3–4 m, cuernos, apariencia demoniaca/animal |
| Población imperial | Pocos miles |
| Longevidad | Extrema; apego generacional |
| **Zarken puro** | ~**10 conceptos**; destruir ciudades con esfuerzo casi nulo |

## Sangre Zarken

- **No coagula ni se degrada.**
- Nociva para otras especies; catalizador evolutivo imperial.
- **Mínimo %** en **toda** criatura viva en Valtia → magia universal.

### Linaje Margalous (humanoides)

Los Zarken eligieron un grupo de criaturas para tener descendencia; **Margalous** era el apellido de esas familias — **descendencia directa**, no elevación simbólica.

| Rama | % sangre |
|------|----------|
| Familia Principal | ~50 % |
| Familia Secundaria | ~25 % |
| **Incesto** | Prohibido — riesgo **100 %** → nacimiento Zarken puro |

**Oni** es considerada **Zarken** (canon DM).

## Fundadores (muertos)

Zaakhiel (Galathia), Juuhndy, Elekhias (Mirage), Zerynhya (Pecados).

## Post-Diluvio / actitud ciudad

| Ciudad | Actitud |
|--------|---------|
| **Mirage** | **Veneración** |
| **Galathia** | Descendencia reconocida, no devoción |
| **Arvek** | **Desprecio** Zarken y realeza |

## Pecados

Conceptos-artefacto Zarken: no heredables, transferibles, poder inmenso. Ver `valtia-facciones`.

## En juego

- Zarken puro NPC = escala cataclismo; no statear salvo boss final.
- Sangre como recurso narrativo, no farming trivial.
