---
name: valtia-estado-actual
description: >-
  Estado vivo de campaña Valtia-01: dónde están los PJs, conflictos abiertos,
  fecha in-game y ganchos inmediatos. Usar al preparar sesión, continuidad
  entre partidas o respuestas sobre qué pasa ahora en la trama.
disable-model-invocation: true
---

# Valtia-01 — Estado actual de campaña

> **Actualizar este skill** al cierre de cada sesión relevante.

## Fecha in-game

**12 de Febrero de 7036 D.Z.**

## Premisa activa

Los jugadores están envueltos en **conflictos políticos, mágicos y filosóficos** que definirán el futuro de **Valtia** (región aislada post-Diluvio).

## Dónde están los PJs

| Hecho | Detalle |
|-------|---------|
| Salida de Galathia | Abandonaron la capital **ilegalmente** |
| Oni | Permanece en **Galathia** (capital) |
| Documentación | **Naylus** proporcionó **papeles falsos** |
| Destino | Camino a **Techia** |
| Objetivo inmediato | **Impedir un atentado** |
| Amenaza en ciudad | **Eins** (Pecado) **opera en Techia** |

## Conflictos encendidos

1. **Galathia vs Mirage** — agravado por **depresión e inacción de Zorgun** tras muerte de **Felicia**.
2. **Guerra ideológica** entre facciones de **Los Mártires** (detalle TBD).
3. **Conspiración Techia**: **Laplace Morgyns**, hijo **Leonhard** — objetivo atentado **retener**.

## Acuerdos de mesa (meta)

- Tono **sin censura**, diversión primero; sistema narrativo consistente pero **no sobrecargado** (notas DM Envy).

## Hilos personales activos

- **Nyssara**: pérdida **progresiva de recuerdos**; posible vínculo con **Caelum** y alteraciones de realidad.

## Próximas preguntas de mesa

- ¿Qué es el atentado y quién lo encarga?
- ¿Qué busca **Eins** en Techia?
- ¿Cómo reacciona Galathia a la fuga de los PJs?
- ¿**Naylus** los manipula hacia un fin propio?

## Relación con gancho PDF (caravana ICON)

El documento *Setting y Mundo* describe la **llegada** a la región (ICONs, domo evitado). La campaña **actual** asume PJs **dentro** del ecosistema político de Valtia. No contradice el pasado remoto; la fase es **intriga urbana**, no exploración wilderness.

## Snapshot para wiki

Al registrar sesión en crónicas:

- `entityType: event` con fecha 7036-02-12
- Tags: `techia`, `atentado`, `eins`, `fuga-galathia`
- Relaciones: PJs → `traveling_to` → Techia; Eins → `operating_in` → Techia
