---
name: icon-class-vagabonds
description: >-
  ICON Vagabond class (yellow jobs): Fool, Freelancer, Shade, Warden; Skirmisher,
  Dodge, Prowl, Finesse; Finishing Blow mechanic vs bloodied foes; Blinded/Dazed
  focus; stealth, evasion, summons, high damage die. Use when writing yellow-class
  abilities or auditing mobility/damage spikes.
disable-model-invocation: false
---

# ICON — Vagabond class & jobs (yellow)

*Source: `docs/icon/ICON Book Vagabonds.pdf`.*

## Class fantasy

Mobile **skirmishers** with **high burst**, **stealth/evasion**, and tools to
delete **isolated** or **ranged** threats — softer if pinned by heavies.

## Class traits (pattern)

- **Skirmisher:** diagonal movement + **full-speed dash**.
- **Dodge:** ignore damage from **missed** attacks, successful saves, **and area
  effects** (still watch non-attack damage).
- **Prowl (1 action):** gain **Stealth** — becomes **free** if no foe within **2**.
- **Finesse:** bonus damage vs **bloodied** foes.
- **Finishing Blow:** abilities gain extra riders when they **target a bloodied
  foe** (definition in glossary).
- **Vagabond Gambit:** cross-class dabblers still get **Finesse** benefits on
  Vagabond abilities.

## Class stats template

**VIT 7 / HP 28 / Def 10 / Speed 4 (Dash 4) / Fray 2 / D10 / Range 4** — glass
cannon skew.

## Status toolkit

- **Blinded** caps ranges; **Dazed** adds attack curse; synergy with **Evasion**
  + **Dodge**.

## Summons

Many jobs use **Summon** blocks (bombs, shadows, etc.) — intangible helpers
acting on controller’s turn; see glossary for **Summon** rules.

## Jobs

| Job | Pitch |
|-----|--------|
| **Fool** | Masked avenger; bombs, gambles, phasing mobility |
| **Freelancer** | (read PDF) mercenary flexibility |
| **Shade** | (read PDF) shadow / mark play |
| **Warden** | (read PDF) territorial skirmisher |

## Homebrew tips

- Reward **setup + cleanup** loops (bloodied gates, marks, power dice).
- Avoid abilities that ignore **Dodge** pain points without cost.

## Links

`icon-combat-glossary` · `icon-jobs-progression` · `icon-ttrpg-index`
