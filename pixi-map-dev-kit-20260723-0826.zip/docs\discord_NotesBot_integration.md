# Discord + NotesBot → pixi-map (diario de sesiones)

> **Estado:** backlog / implementar **después** de que el sistema diario (wiki, sesiones, Lab IA) esté estable y usable sin esta integración.  
> **Objetivo:** que NotesBot haga el trabajo pesado (grabar / transcribir / resumir en Discord) y pixi-map **persista** resumen + transcript, con el DM solo anotando fechas (real / en juego) y notas clave, para timeline y contexto de IA.

---

## 1. Contexto y decisión

### Qué hace NotesBot (hoy, producto externo)

1. El DM (u operador) ejecuta `/join` en Discord → el bot entra al voice channel.
2. Graba la sesión (modo **DnD** recomendado: sesiones largas ~hasta 5 h).
3. `/leave` → transcribe, resume y **posta resumen (+ transcript/links) en un canal de texto**.
4. El audio queda en su dashboard; la API **no** expone descarga de audio.

### Qué queremos en pixi-map

- Guardar **siempre** el resumen y (de forma controlada) el transcript en Firestore.
- Timeline con **dos fechas**:
  - **Real / fuera del juego** (`realDate` / `playedAt`) — cuándo se jugó en la vida real.
  - **En juego / diegética** (`inGameDate` / `valtiaDate`) — cuándo ocurre en el calendario de Valtia.
- El DM solo completa fechas + anotaciones puntuales (`dmNotes`); el resto viene de NotesBot.
- Usar esos datos como **contexto del Lab IA** (ya parcialmente cableado con `sessionRecaps`).

### Qué **no** hacer

- No scrapear el mensaje del canal de Discord como fuente primaria (frágil).
- No meter el transcript completo de 4 h en **cada** llamada al LLM (coste/tokens).
- No poner la API key `nb_...` en el frontend público.
- No depender de Read.ai / Otter / Fireflies para Discord voice (no entran al VC nativo).

---

## 2. Piezas ya existentes en pixi-map

| Pieza | Ubicación | Rol |
|--------|-----------|-----|
| Colección sesiones | `campaigns/{campaignId}/sessions` | Diario |
| Service CRUD | `firebase/services/sessionLogService.js` | create / list / update / delete |
| UI diario | `src/components/wiki/WikiSessionLogPanel.jsx` | Alta/edición manual |
| Lab IA + recaps | `WikiAiLabPanel.jsx` → `listSessionLogs(..., 5)` | Últimas 5 sesiones al contexto |
| Prefix contexto | `buildExtendedContextPrefix` / `mergeContextWithExtras` en `src/utils/buildSituationContext.js` | Canon + sesiones + thread |
| Rules | `firestore.rules` → `match /sessions/{sessionId}` | read auth; write DM |

### Schema actual (`sessions`)

```js
{
  title: string,
  recap: string,
  sessionDate: string,      // ISO date YYYY-MM-DD (hoy: una sola fecha)
  participants: string[],
  highlights: string[],
  createdAt, updatedAt
}
```

---

## 3. NotesBot API (fuente de verdad)

Docs: <https://api.notesbot.io/docs>  
OpenAPI: <https://api.notesbot.io/openapi.json>  
Base: `https://api.notesbot.io`  
Auth: `Authorization: Bearer nb_...` (dashboard → API keys)

### Endpoints útiles

| Método | Path | Uso |
|--------|------|-----|
| `GET` | `/v1/calls` | Listar llamadas (paginado, filtros `server_id`, `channel_id`, `from`, `to`, `q`) |
| `GET` | `/v1/calls/{id}` | Detalle: **`summary` + `transcript` + `participants`** |

### Campos relevantes del call

- `id` — guardar como `notesbotCallId` (idempotencia)
- `summary` → `recap`
- `transcript` → `transcript` (ver límites abajo)
- `created_at` → default de `realDate` / `playedAt`
- `server_id` / `channel_id` / `channel_name` / `duration`
- `participants[].display_name` / `username`

### Límites / matices

- Solo calls del **billing owner** (quien paga la suscripción de esa grabación).
- API **read-only**; sin audio.
- Rate limit: **60 req/min** por key.
- **No hay webhooks**: integración = **pull** (botón o polling).
- Opcional paralelo: export a Google Drive/Docs (bridge externo, no necesario si usamos API).

### Coste orientativo (referencia mesa)

- ~4 h × 3 veces/mes ≈ 12 h → plan NotesBot ~10–20 h/mes (**~$5–10/mes**).
- ~20 h/mes → plan **~$10/mes**.

---

## 4. Flujo objetivo (día a día)

```
Mesa Discord
    │  /join → sesión → /leave
    ▼
NotesBot (graba, transcribe, resume)
    │  postea en canal Discord (lectura humana)
    │  + datos en API NotesBot
    ▼
pixi-map importa (botón DM o job)
    │  crea/actualiza doc en campaigns/{id}/sessions
    ▼
DM completa: inGameDate (+ dmNotes / highlights)
    ▼
Diario + timeline  ·  Lab IA usa recaps recientes
```

### Ritual operativo (cuando esté listo)

1. Antes de sesión: NotesBot `/join` (modo DnD si aplica).
2. Fin: `/leave` → revisar post en Discord (opcional).
3. En wiki: **Importar de NotesBot** (o esperar al poll).
4. Abrir borrador de sesión → poner **fecha en juego** + notas clave → guardar.
5. Lab IA ya ve el recap en “Sesiones recientes”.

---

## 5. Schema propuesto (extensión)

```js
{
  title: string,
  recap: string,                 // summary NotesBot (+ ediciones DM)
  transcript: string | null,     // transcript completo o null + storage alternativo
  transcriptPreview: string,     // excerpt acotado para UI / contexto opcional
  highlights: string[],
  dmNotes: string,               // anotaciones clave del DM

  // Fechas
  realDate: string,              // YYYY-MM-DD — fuera del juego (default: created_at NotesBot)
  inGameDate: string | null,     // calendario Valtia / diegético (DM)
  // sessionDate: mantener como alias de realDate o migrar y deprecar

  participants: string[],
  status: "imported" | "annotated" | "archived",

  // Provenance NotesBot
  notesbotCallId: string,        // unique por campaña — no re-importar
  notesbotMeta: {
    serverId, channelId, channelName,
    durationSec, createdAtIso
  },

  createdAt, updatedAt
}
```

### Timeline

- Orden **mundo / lore**: `inGameDate` (cuando el DM lo rellene).
- Orden **real / “sesión del sábado”**: `realDate`.
- UI: chips o columnas separadas; no mezclar ambas en un solo campo.

### Transcript y tamaño

- Una sesión de ~4 h puede generar mucho texto → Firestore tiene límites prácticos por documento.
- Estrategias aceptables (elegir una al implementar):
  1. Guardar `recap` + `transcriptPreview` (~2–8k chars) en el doc; transcript full en Storage / subcolección chunked; o
  2. Guardar transcript en el doc si cabe; si no, truncar + link `notesbotCallId` para re-fetch bajo demanda.
- **Contexto IA por defecto:** solo `title` + fechas + `recap` (+ `dmNotes` / highlights). Transcript completo solo bajo demanda o excerpt.

---

## 6. Opciones de implementación (orden recomendado)

### Fase A — MVP (recomendado primero)

- Botón **“Importar de NotesBot”** en `WikiSessionLogPanel` (solo DM).
- Cloud Function o endpoint server-side con secret `NOTESBOT_API_KEY`.
- Lista `GET /v1/calls` filtrada por `server_id` (y opcional `channel_id` de la mesa).
- Por cada call nuevo: `GET /v1/calls/{id}` → `createSessionLog` con `status: "imported"`.
- UI edición: campos `realDate`, `inGameDate`, `dmNotes`; marcar `annotated`.
- Idempotencia: query / índice por `notesbotCallId`.

### Fase B — Automático

- Scheduled Cloud Function (p. ej. cada 15–60 min) o al abrir el panel de sesiones.
- Mismos imports; notificar al DM (snackbar / badge “N sesiones sin fecha en juego”).

### Fase C — (opcional, no prioritario)

- Listener Discord al canal donde NotesBot posta → solo como fallback si la API falla.
- Sincronizar entities/wiki desde highlights (más cercano a Kazkar; fuera de alcance inicial).

---

## 7. Cableado Lab IA

Hoy (`WikiAiLabPanel`):

```js
listSessionLogs(campaignId, 5).then((rows) => {
  setSessionRecaps(rows.map((r) => ({ title: r.title, recap: r.recap })));
});
```

Al integrar, ampliar el mapeo, p. ej.:

```js
{
  title: r.title,
  recap: r.recap,
  realDate: r.realDate ?? r.sessionDate,
  inGameDate: r.inGameDate ?? null,
  dmNotes: r.dmNotes ?? "",
}
```

Y en `buildExtendedContextPrefix`, renderizar algo como:

```md
### Sesión N — real 2026-07-12 · en juego [Era X, día Y]
{recap}
Notas DM: ...
```

Solo incluir sesiones `annotated` (o imported si el recap ya es usable). No incluir transcript full en el prefix por defecto.

---

## 8. Seguridad y ops

- API key NotesBot: **secret** (Firebase Functions / env server), nunca en Vite/`VITE_*` público.
- Billing owner = cuenta Discord del DM (o la que pague NotesBot); si graba otro usuario, esa call **no** aparece en la API del DM.
- Consentimiento de grabación en la mesa (legal + hábitos del grupo).
- Rules Firestore: escrituras de sesiones siguen siendo **DM-only**; el import server-side usa admin SDK o credencial DM.
- Rate limit NotesBot: import tipico = 1 list + N details (pocas llamadas/mes).

---

## 9. Checklist de implementación (cuando toque)

- [ ] Extender `sessionLogService` + panel UI (fechas duales, dmNotes, status).
- [ ] Migración suave: `sessionDate` → `realDate` (fallback leer ambos).
- [ ] Cloud Function / proxy `importNotesBotCalls({ campaignId, serverId, since })`.
- [ ] Secret `NOTESBOT_API_KEY` + config `notesbotServerId` / `notesbotChannelId` por campaña (admin settings).
- [ ] Dedup por `notesbotCallId`.
- [ ] Política de transcript (doc vs Storage vs preview).
- [ ] Actualizar `buildExtendedContextPrefix` + Lab IA mapeo.
- [ ] Índice Firestore si se consulta por `notesbotCallId`.
- [ ] Probar 1 sesión real (español + nombres Valtia/ICON) y ajustar prompts/recaps si hace falta.
- [ ] Documentar ritual DM en README interno / glossary (`session_log`).

---

## 10. Alternativas (si NotesBot deja de servir)

| Tool | Rol |
|------|-----|
| **Craig** + Whisper/AssemblyAI | Grabación multi-track gratis; STT aparte (~$0.15/h AssemblyAI orientativo). |
| **NoteCat** | Bot Discord record+transcript+summary (claim free tier; validar límites). |
| **Kazkar** | TTRPG-oriented (crónica + wiki); free 10 h totales; menos genérico. |
| **Kassinao** (self-host) | Pipeline completo propio; más mantenimiento. |

NotesBot se eligió por: API clara + DnD mode + precio bajo a ~12–20 h/mes + post en Discord para la mesa.

---

## 11. Referencias rápidas

- NotesBot site: <https://notesbot.io/>
- Pricing horas: <https://www.notesbot.io/pricing>
- API docs: <https://api.notesbot.io/docs>
- Código actual sesiones: `firebase/services/sessionLogService.js`, `src/components/wiki/WikiSessionLogPanel.jsx`
- Contexto IA: `src/utils/buildSituationContext.js` (`buildExtendedContextPrefix`), `src/components/wiki/WikiAiLabPanel.jsx`
- Skill Lab: `.cursor/skills/ai-narrative-lab/SKILL.md`

---

## 12. Nota de alcance

Este documento es **diseño + backlog**, no un compromiso de implementación inmediata. Activarlo cuando el flujo diario de wiki / sesiones / Lab IA ya cubra el día a día y solo falte automatizar la captura desde Discord.
