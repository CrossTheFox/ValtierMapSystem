---
name: valtia-muerte-reaktis
description: >-
  Muerte, más allá, Reaktis, necromancia y tecnología Reakta en Valtia-01.
  Usar al escribir resurrección, funerales, Engel, Techia médica o tabúes.
disable-model-invocation: true
---

# Valtia-01 — Muerte, Reaktis y Reakta

## Muerte ordinaria (sin intervención)

- El **alma va al más allá**.
- La religión organizada **sabe** que existen **cielo**, **infierno** y la posibilidad de **resurrección / reencarnación** (no es secreto teológico).

---

## Reaktis (magia / alquimia)

Rama extremadamente peligrosa que desafía la **irreversibilidad de la muerte**.

| | Necromancia | Reaktis |
|---|-------------|---------|
| Objetivo | Cadáveres, almas fragmentadas, no-muertos | **Restaurar por completo** a quien murió |
| Resultado buscado | Sirviente / reanimado | Volver **como si nunca hubiera muerto** |

El universo **rechaza activamente** este proceso. La vida consciente tiene un valor tan inmenso que **casi ningún sacrificio** la compensa del todo.

### Fallos habituales

- Regreso **incompleto** (recuerdos, emociones, fragmentos de alma).
- **Personalidad alterada**.
- Cuerpo que **degrada** o anomalías mágicas.
- Daño a **asistentes** o **entorno**.
- Peor caso: **entidad nueva** — no es la persona original; como «revivieron al ser incorrecto» (puede parecer otra persona). **~2 %** de casos; suficientemente frecuente para **cláusulas contractuales** anti-demandas.

### Éxitos

- **Sí existen**, pero **nunca sin consecuencias**.
- Dicho alquímico: *«La necromancia engaña a la muerte. Los Reaktis intentan negociar con ella. Ninguna de las dos sale barata.»*

### Legalidad y acceso

- **No prohibido** en Valtia (disciplina académica considerada irresponsable, no ilegal per se).
- **PJs:** pueden **estudiar mucho** el tema; **no replicar** resurrección real en mesa como habilidad de PJ.
- Revivir en campaña: **posible** con **coste enorme** o **mucha suerte** — evento narrativo mayor, no rutina.

---

## Necromancia

- **Sumamente tabú** — rara vez sale bien.
- Quienes la dominan suelen tener **fines ulteriores / malévolos**.
- **Extremadamente peligrosa**; conocimiento exige **sacrificios externos** tabú (infantes, inocentes, etc.).
- Un no-muerto **no pasa por vivo** ante quien conoce la disciplina; el engaño no es el modelo.

---

## Tecnología Reakta (Techia)

Permite traer de vuelta a algunos seres con requisitos **estrictos pero «justos»** (técnicos, no morales).

| Requisito | Detalle |
|-----------|---------|
| Tiempo | **< 1 hora** muerto |
| Catalizador | **Obligatorio** — brazo, corazón, etc.; cuanto **más vital** el órgano, mejor (**cabeza** y **corazón** óptimos) |
| Alma | Puede **obligarse** a volver; más **fuerza** si el alma **se opone** |
| Coste económico | **Dinero y bienes materiales** — familia, interesados u organización que vea **valor** en la resurrección |
| Regulación | **Gabinete Central de Techia** |

### Alma que se opone

- A menudo oposición **natural** del alma al regreso.
- Algunas **no quieren volver** (o no como eran).
- Otras están **casi listas** — resurrección más **rápida y fácil**.
- **Forzar** el retorno: más **costoso y peligroso para asistentes**, no necesariamente peor para el resucitado; riesgos dependen de **parámetros del ritual y cuidados**.

### En la práctica

- **Legal**, **usada**, **cara** — no clandestina.
- Fallos ~2 % generan mitos y **contratos** en clínicas Reakta.

---

## Engel — «Señora de la Guerra»

- Resucitada **docenas de veces** — parte central de su **trauma**.
- La trajeron de vuelta **a la fuerza** por eficiencia en combate.
- Casi siempre **Reakta Tech**; **última** resurrección con **necromancia** (excepcional y tabú).
- **Círculos militares/históricos** conocen su historial.
- Transformación **filosófica** profunda; **físicamente perfecta**.

Ver `valtia-facciones` (Mártir Engel).

---

## Felicia — posible pero no hecha

- **Traerla de vuelta es posible** técnicamente.
- **Nadie quiere hacerlo**, sobre todo **Zorgun**:
  - **Miedo** a lo que Felicia haría a **Oni**.
  - **Tristeza y arrepentimiento** — no podría mirarla a la cara tras lo que le hizo.
- No hay bloqueo mágico especial; es decisión **humana/emocional**.

Ver `valtia-historia`.

---

## Nyssara y Caelum

- **Independientes** de Reakta / Reaktis valtiense.
- Amnesia de Nyssara = **Intercambio Equivalente** (propio + de Caelum).
- Ambos son **de fuera de Valtia** — fuera del sistema Reakta tech.

---

## En mesa (ICON)

| Situación | Guía |
|-----------|------|
| PJ quiere aprender Reaktis | Lore sí; **no** clonar resurrección como mecánica |
| Resucitar NPC querido | Posible **una vez**; coste material + narrativo alto |
| Engel en escena | Referencia opcional a historial; no exponer salvo investigación |
| Clínica Reakta Techia | Servicio caro, regulado, contratos por fallos |
| Necromancia visible | Reacción social **extrema**; asumir malas intenciones |
