# Investigación: Multi-pass y pre-fetch para el Evento narrativo del Lab IA

**Fecha:** 2026-07-14  
**Contexto:** Lab IA / NEURAL_LAB · modo Evento narrativo (Onda catalizadora)  
**Problema raíz:** El modo cascade es single-pass: un único call al LLM debe decidir a quién afecta el evento, generar reacciones para todos, y proponer cambios de relación/estado, todo en una sola respuesta JSON. A profundidad ≥ 5 esto agota los tokens de salida antes de terminar, produciendo JSON truncado.

---

## 1. Diagnóstico extendido

### 1.1 Por qué el single-pass falla en eventos grandes

El modo cascade actual usa un único call con dos presupuestos de tokens:

| Presupuesto | Qué lo llena | Síntoma |
|-------------|--------------|---------|
| **Input** | Fichas PANGeA + relaciones + arquetipos | Contexto truncado si depth > 5 |
| **Output** | Un objeto `impact` por cada personaje con `emotionalReaction` + `narrativeHook` + N `changes` | Supera `maxOutputTokens` → JSON inválido |

Subir solo `maxOutputTokens` (parche ya aplicado a 24k) aplaza el problema: en una campaña larga con decenas de NPCs activos, incluso 32k tokens de salida se llenan. El modelo también tiende a "divagar" estructuralmente cuando tiene que inventar quién importa, qué emoción tiene y qué cambia, todo al mismo tiempo.

### 1.2 El insight clave

> El modelo hace **dos tareas cognitivamente distintas** en un solo paso:  
> (A) **Evaluar** a quién afecta el evento y cómo (exploración estructural del grafo)  
> (B) **Elaborar** reacciones y proponer cambios concretos (escritura narrativa)

Separar estas dos tareas — exactamente lo que demuestran los sistemas multi-agente en los papers — reduce la carga de cada paso y mejora la coherencia del resultado.

---

## 2. Papers aplicables

### 2.1 AutoWorldBuilder — Chen et al. (2026)

**Fuente:** Chen, Z., et al. (2026). AutoWorldBuilder: Automated, consistent world-building with LLMs. *Journal of Artificial Intelligence Research*, acceptado 2026. https://arxiv.org/html/2607.09403v1

**Qué demuestra:**
- **4-Layer Context Compression:** Essential (~20%) + Relevant (~35%) + Summary (~20%) + Collaboration (~25%). Reducción media de 89.9%; promedio de 304 tokens/llamada.
- **Auditor separado del generador:** Elimina sesgo de auto-aprobación. Pass rate de propuestas: 42% → 85.5% en primera iteración.
- **DAG scheduling:** Agrupa tareas por localidad semántica para reutilizar contexto. La separación de generación en pasos (analizar → elaborar) es exactamente un DAG de 2 nodos.
- 56–103 conceptos por mundo sin conflictos, en 18–31 min.

**Aplicación al proyecto:**
- Pasa 1 (Scout) = "evaluación de impacto" es la tarea cognitiva pequeña, separada de la elaboración narrativa.
- La separación agente-generador / agente-auditor se traduce en Scout / Impact.
- El contexto compacto del Scout (~2k tokens) replica el "essential context" de AutoWorldBuilder.

### 2.2 PANGeA — Buongiorno et al. (2024)

**Fuente:** Buongiorno, S., Klinkert, L., Zhuang, Z., Chawla, T., & Clark, C. (2024). PANGeA: Procedural artificial narrative using generative AI for turn-based, role-playing video games. *Proceedings of the AAAI Conference on Artificial Intelligence and Interactive Digital Entertainment*, *20*(1), 156–166. https://doi.org/10.1609/aiide.v20i1.31876

**Qué demuestra:**
- **Multi-step prompting sequence:** Cada paso genera contenido y lo almacena resumido como seed del siguiente. Exactamente la relación Scout → Impact.
- **Validation system:** Auto-verificación iterativa (28% → 98% precisión con Llama-3 8B).
- La topología de impactos viene del grafo real; la IA solo rellena contenido.

**Aplicación:** El output del Scout sirve de "seed" para el Impact. Las reacciones previstas (Pasa 1) actúan como ancla narrativa que reduce la carga generativa de Pasa 2.

### 2.3 ChatRPG / SENNA — Jørgensen et al. (2025)

**Fuente:** Jørgensen, N. H., Tharmabalan, S., Aslan, I., Brodersen Hansen, N., & Merritt, T. (2025). Static vs. agentic game master AI for facilitating solo role-playing experiences. *arXiv*. https://arxiv.org/abs/2502.19519

**Qué demuestra:**
- v3/SENNA: 5 agentes. **Examiner + Narrator como loop de dos pasos**: el Examiner evalúa cada acción contra el Narrative Graph antes de autorizar; el Narrator elabora dentro de esas restricciones.
- Exactamente el pre-fetch preguntado: un agente pre-evalúa el impacto en el grafo antes de que el Narrator genere texto.

**Aplicación:** Scout = Examiner (evalúa el grafo), Impact = Narrator (elabora la narrativa). La diferencia: en pixi-map el "Examiner" usa el grafo wiki (Firestore) en lugar de un Narrative Graph propio.

### 2.4 G-KMS — Rahman, Yu & Cho (2026)

**Fuente:** Rahman, A., Yu, A., & Cho, K. (2026). Game knowledge management system: Schema-governed LLM pipeline for executable narrative generation in RPGs. *Systems*, *14*(2), 175. https://doi.org/10.3390/systems14020175

**Qué demuestra:**
- Pipeline de 5 etapas: grounding → generación schema-governed → normalización → validación → admisión.
- **Smoke test + validation gate:** artefactos inválidos se descartan y se regeneran con instrucciones de corrección deterministas.
- Análogo directo: la `validateAiResponse` del proyecto es la etapa de validación; la Reflexion-lite es la etapa de "normalización con retry".

**Aplicación:** El Reflexion retry es la etapa de "normalización" de G-KMS aplicada a `missingImpacts`.

### 2.5 Reflexion — Shinn et al. (2023)

**Fuente:** Shinn, N., Cassano, F., Gopinath, A., Narasimhan, K. R., & Yao, S. (2023). Reflexion: Language agents with verbal reinforcement learning. *Advances in Neural Information Processing Systems*, *36*, 8634–8652. https://proceedings.neurips.cc/paper/2023/file/1b44b878bb782e6954cd888628510e90-Paper-Conference.pdf

**Qué demuestra:**
- El agente critica su propio output fallido → genera feedback verbal en memoria → reintenta con ese feedback.
- ReAct + Reflexion: 130/134 tareas AlfWorld completadas.
- El feedback verbal (el "Reflexion prompt") es más eficiente que simplemente repetir el mismo prompt.

**Aplicación directa:** Cuando `missingImpacts.length > 0` o `truncated: true`, construir un prompt de corrección específico que liste exactamente qué entidades faltan y pedir solo esos impacts. Esto es literalmente Reflexion aplicado al cascade.

### 2.6 ONTO — 2025

**Fuente:** ONTO: Object Notation for Token Optimization. (2025). *arXiv*. https://arxiv.org/html/2604.17512v1

**Qué demuestra:**
- Notación columnar (campo declarado una vez, valores en filas pipe-delimited).
- 46–51% menos tokens vs JSON para datos estructurados repetitivos.
- Los bloques de fichas y relaciones en el contexto cascade son exactamente datos repetitivos.

**Aplicación:** Bloque de relaciones en el Scout context usa formato `from|to|tipo|fuerza` en lugar de `- A → [tipo] → B (label) [fuerza: N]`. Aplicable también al bloque de relaciones del Impact context en el futuro.

### 2.7 GraphRAG / TERAG — 2025

**Fuente:** TERAG: Token-Efficient Retrieval-Augmented Graph Generation. (2025). *arXiv*. 80% de accuracy con 3–11% de los tokens vs GraphRAG completo.

**Aplicación:** En vez de serializar todo el BFS, recuperar solo el subgrafo semánticamente relevante al evento (ya implementado parcialmente via "relation-first packing"). El Scout context es la versión extrema de TERAG para pixi-map.

---

## 3. Opciones evaluadas

| Opción | Descripción | LLM calls extra | Latencia extra | Beneficio | Riesgo |
|--------|-------------|-----------------|----------------|-----------|--------|
| **A** | Solo subir maxOutputTokens | 0 | 0 | Parche inmediato | Sigue fallando a depth 5+ en campañas densas |
| **B** | Relación-primero (ya activo) | 0 | 0 | -40-50% input tokens | Ninguno |
| **C** | Two-pass Scout+Impact | +1 (barato) | +2-4s | Reduce output; seed coherente | Amplifica errores del Scout si falla |
| **D** | Reflexion-lite retry | +1 (solo en fallo) | +2-4s (solo en fallo) | -80-90% tasa de fallo | Costo adicional solo cuando hay problemas |
| **E** | Serialización ONTO | 0 | 0 | -46-51% bloque relaciones | Modelo debe entender el formato (header necesario) |

---

## 4. Mezcla elegida: B + C + D (+ E en Scout)

### 4.1 Qué se usa, en qué medida, por qué y para qué

| Técnica | Fuente académica | Nivel de uso | Cuándo activa | Por qué | Para qué |
|---------|-----------------|-------------|--------------|---------|---------|
| **B: Relación-primero** | TERAG, PANGeA | Total (siempre) | Toda generación cascade | Sin costo adicional, mejora coherencia local inmediatamente | -40-50% input tokens; prioriza vínculos sobre lore largo |
| **C: Two-pass Scout+Impact** | AutoWorldBuilder, SENNA, PANGeA | Umbral: `expectedImpacts >= 5` | Eventos con muchos NPCs afectados | A partir de 5 impacts el single-pass empieza a degradarse (evidencia empírica propia); por debajo de 5 el overhead no se justifica | Reduce tokens de salida del Impact; el Scout "siembra" la respuesta, el modelo no necesita inventar estructura |
| **D: Reflexion-lite retry** | Reflexion (Shinn 2023), G-KMS | Red de seguridad (solo en fallo) | `missingImpacts.length > 0` o `truncated: true` | Solo activa cuando algo falla; costo mínimo; mejora dramática la tasa de éxito | Reduce tasa de fallo del ~15-20% al ~2-4% neto |
| **E: ONTO en Scout** | ONTO (2025) | Parcial (Scout context) | Siempre en Scout context | El bloque de relaciones en el Scout es datos repetitivos; ONTO da -46-51% tokens | Mantiene Scout context bajo el umbral de 2k tokens incluso en grafos densos |

### 4.2 Qué se descartó y por qué

- **ONTO en Impact context:** Riesgo de que el modelo genere `relationType` en formato ONTO en lugar de snake_case. Necesita validación adicional antes de activar.
- **Gate entre Pasa 1 y Pasa 2:** Añade fricción al DJ sin beneficio claro. El Scout es determinista y rápido; no hay razón para interrumpir el flujo.
- **Two-pass siempre activo:** El overhead de latencia (+2-4s) no se justifica para eventos simples con 2-3 NPCs afectados.

### 4.3 Qué se deja para fases futuras

- **Serialización ONTO completa** para el Impact context (cuando tengamos evidencia de que el modelo maneja el formato correctamente).
- **Two-pass con gate de revisión** (modo "experimental" que el DJ puede activar para ver el Scout output antes del Impact).
- **Evaluador autónomo** (tercer agente post-Impact que verifica coherencia con el grafo antes de presentar al DJ).

---

## 5. Arquitectura del flujo implementado

```
DJ lanza evento narrativo
         │
         ▼
BFS + ranking determinista (Opción B, ya activo)
buildCascadeContext() → ctx
         │
         ├─── expectedImpacts < 5 ─────────────────────────────────────┐
         │                                                              │
         └─── expectedImpacts >= 5                                      │
                     │                                                  │
                     ▼                                                  │
         buildScoutContext() (ONTO relations, ~1.5k tokens)            │
                     │                                                  │
                     ▼                                                  │
         Pasa 1: Scout (gemini-2.5-flash-lite)                         │
         Output: impacts[] mínimos {entityTitle, wave,                 │
                 emotionalKeyword, topChangeType, topChangeDesc}        │
                     │                                                  │
                     ▼                                                  │
         Scout pinned al top del context Impact                         │
                     │                                                  │
                     ▼                                                  │
         Pasa 2: Impact (gemini-2.5-flash) ◄──────────────────────────┘
         Output: JSON cascade completo
                     │
                     ▼
         validateAiResponse() → validated
                     │
         ┌───────────┴───────────────┐
         │ ok? + no missing           │ missingImpacts > 0
         │                            │ o truncated?
         ▼                            ▼
    Resultado al DJ       buildReflexionPrompt(missingTitles)
                                       │
                                       ▼
                          Reflexion retry (gemini-2.5-flash)
                          Solo impacts faltantes, 1 intento máx
                                       │
                                       ▼
                          Merge: original.impacts + retry.impacts
                                       │
                                       ▼
                                Resultado al DJ
```

---

## 6. Mejoras esperadas (estimaciones)

| Escenario | Input est. | Output est. | Tasa de fallo est. | Latencia extra |
|-----------|-----------|------------|-------------------|---------------|
| Baseline (depth 3-4, single-pass) | ~4-7k tokens | ~6-12k tokens | ~15-20% | — |
| + Two-pass Scout (threshold ≥5) | Scout ~1-2k + Impact ~3-6k | Scout ~0.4k + Impact ~4-8k | ~5-8% | +2-4s (solo si ≥5 impacts) |
| + Reflexion retry | +1-3k (solo en fallo) | +2-4k (solo en fallo) | ~2-4% neto | +2-4s (solo en fallo) |
| + ONTO en Scout | -46-51% del bloque relaciones del Scout | sin cambio | sin cambio | sin cambio |

**Escenario típico Valtia (revelación pública, 7 NPCs afectados):**
- Sin mezcla: ~10k input / ~14k output / 20% de fallo
- Con B+C+D: ~4k Scout + 6k Impact / ~6k output / 4% de fallo
- Ahorro estimado: ~35-45% de tokens totales; tasa de fallo de 20% a 4%

---

## 7. Notas de implementación

### 7.1 Scout schema (mínimo)

```json
{
  "impacts": [{
    "entityTitle": "string",
    "wave": "number",
    "emotionalKeyword": "string",  // ≤ 3 palabras
    "topChangeType": "enum: relation_update|relation_add|relation_remove|entity_state_update|none",
    "topChangeDesc": "string"      // ≤ 15 palabras
  }]
}
```

El Scout schema intencional pequeño: el modelo solo necesita "identificar y clasificar", no elaborar. Esto es lo que hace posible usar `gemini-2.5-flash-lite` con buena fiabilidad.

### 7.2 ONTO columnar (Scout context)

```
from|to|tipo|fuerza
Oni|Zorgun|descendiente_de|9
Zorgun|Oni|descendiente_de|9
Oni|Engel|desconocido|3
Engel|Zorgun|enemigo_de|8
```

El header de columnas es crítico: sin él el modelo puede confundir el formato. El modelo interpreta correctamente el pipe-separated columnar con header (evidencia de ONTO 2025; TERAG usa formato similar).

### 7.3 Reflexion prompt structure

```
[CONTEXTO CASCADE ORIGINAL]

Evento catalizador: "[event]"

CORRECCIÓN REQUERIDA: Tu respuesta anterior tuvo N impacts faltantes.
Genera SOLO los impactos para estos personajes (están en el contexto): [lista].
Usa el mismo formato JSON con "impacts" como array.
NO incluyas personajes que no estén en esta lista.
```

El contexto original se mantiene para que el modelo tenga el subgrafo completo al generar los impacts faltantes. Incluir "están en el contexto" reduce la tasa de "entidad no encontrada" en el retry.

### 7.4 Merge de resultados

```javascript
// Merge del retry en el resultado original
if (retryValidated.impacts?.length > 0) {
    validated.impacts = [...validated.impacts, ...retryValidated.impacts];
    // Recalcular missingImpacts post-merge
    const reportedTitles = new Set(
        validated.impacts.map(i => i.entityTitle?.toLowerCase().trim()).filter(Boolean)
    );
    validated.missingImpacts = validated.missingImpacts.filter(
        t => !reportedTitles.has(t.toLowerCase().trim())
    );
    // Limpiar el error de "Faltan impacts" si se completaron
    validated.errors = (validated.errors ?? []).filter(
        e => !e.startsWith("Faltan impacts")
    );
}
```

---

## 8. Archivos del proyecto afectados

| Archivo | Tipo de cambio | Qué se añade/modifica |
|---------|---------------|----------------------|
| `src/constants/wiki/narrativeAiSchemas.js` | Modificado | `AI_MODES.CASCADE_SCOUT`, Scout schema, Scout prompt, `CASCADE_SCOUT_THRESHOLD`, `CASCADE_SCOUT_MODEL_ID` |
| `src/utils/buildSituationContext.js` | Modificado | `buildScoutContext()` con ONTO columnar para relaciones |
| `firebase/services/narrativeAiService.js` | Modificado | Soporte para `CASCADE_SCOUT` mode (modelo, schema, prompts) |
| `src/utils/validateAiResponse.js` | Modificado | `buildReflexionPrompt()` helper exportado |
| `src/components/wiki/WikiAiLabPanel.jsx` | Modificado | `loadingLabel` state; two-pass logic; Reflexion retry; UI states |

---

## 9. Fuentes completas (APA 7)

1. Buongiorno, S., Klinkert, L., Zhuang, Z., Chawla, T., & Clark, C. (2024). PANGeA: Procedural artificial narrative using generative AI for turn-based, role-playing video games. *Proceedings of the AAAI Conference on Artificial Intelligence and Interactive Digital Entertainment*, *20*(1), 156–166. https://doi.org/10.1609/aiide.v20i1.31876

2. Chen, Z., et al. (2026). AutoWorldBuilder: Automated, consistent world-building with LLMs. *Journal of Artificial Intelligence Research*, acceptado 2026. https://arxiv.org/html/2607.09403v1

3. Jørgensen, N. H., Tharmabalan, S., Aslan, I., Brodersen Hansen, N., & Merritt, T. (2025). Static vs. agentic game master AI for facilitating solo role-playing experiences. *arXiv*. https://arxiv.org/abs/2502.19519

4. ONTO: Object Notation for Token Optimization. (2025). *arXiv*. https://arxiv.org/html/2604.17512v1

5. Rahman, A., Yu, A., & Cho, K. (2026). Game knowledge management system: Schema-governed LLM pipeline for executable narrative generation in RPGs. *Systems*, *14*(2), 175. https://doi.org/10.3390/systems14020175

6. Shinn, N., Cassano, F., Gopinath, A., Narasimhan, K. R., & Yao, S. (2023). Reflexion: Language agents with verbal reinforcement learning. *Advances in Neural Information Processing Systems*, *36*, 8634–8652. https://proceedings.neurips.cc/paper/2023/file/1b44b878bb782e6954cd888628510e90-Paper-Conference.pdf

7. Yao, S., Zhao, J., Yu, D., Du, N., Shafran, I., Narasimhan, K. R., & Cao, Y. (2022). ReAct: Synergizing reasoning and acting in language models. *arXiv*. https://arxiv.org/abs/2210.03629

8. TERAG: Token-Efficient Retrieval-Augmented Graph Generation. (2025). *arXiv*. *(Verificar número arXiv definitivo al citar en memoria.)*

---

## 10. Decisiones de producto

1. El Lab IA de cascade **no aspira a ser un simulador completo de consecuencias** en un solo call. Aspira a ser un **generador de propuestas de relaciones y estados** revisables por el DJ.
2. La fidelidad se mide por **cambios de arista aplicables en el wiki**, no por coherencia lore-enciclopédica.
3. El umbral de 5 impacts para activar Scout es conservador: en pruebas con Valtia (revelación Engel/Zorgun/Oni), depth 3 produce 4-6 impacts → Scout se activa justamente en los eventos complejos.
4. El retry Reflexion tiene cap de 1 intento para evitar gastos descontrolados. Si tras el retry siguen faltando impacts, el DJ recibe el resultado parcial con indicación de qué faltó.
5. `gemini-2.5-flash-lite` para el Scout es apropiado: la tarea de clasificación (identificar quién se ve afectado y cómo) no requiere el modelo completo.

---

*Documento complementario: `docs/investigacion-cascade-tokens-relaciones.md` (enfoque relación-primero, implementación Fase 0)*  
*Historial: creado 2026-07-14 como parte de la iteración multi-pass (Plan: Investigación y Desarrollo Multi-pass AI Cascade)*
