---
name: valtia-wernegar
description: >-
  Wernegar exterior a Valtia: desierto arrasado, lore de fondo, sin juego activo.
  Usar solo para referencias históricas o NPCs que recuerden el exterior.
disable-model-invocation: true
---

# Valtia-01 — Wernegar (exterior)

## Alcance en campaña

**Solo lore de fondo.** La mesa activa ocurre **dentro del domo** (Valtia).

## Qué es

- Región **exterior** al domo; **desierto** post-Diluvio.
- Donde los Zarken **escaparon** antes del refugio — en memoria valtiense.
- Poblados aislados / fauna mutada (canon PDF) — **no relevante** para trama actual salvo excepción.

## Percepción desde Valtia

- Indígenas, nada interesante, **no salir** salvo locura o misión extrema.
- Sin **contacto comercial**.

## Calendario

Fuera del domo hay **discrepancias menores** en dating; ignorar salvo plot explícito.

## PDF / caravana ICON

Gancho de llegada al domo = pasado lejano o otra línea temporal; campaña 7036 D.Z. = **política interior**.
