---
name: icon-class-wrights
description: >-
  ICON Wright class (blue jobs): Enochian, Geomancer, Spellblade, Stormbender;
  Slip, Aetherwall, Chain Reaction; Aether power die + Infuse upgrades; Shattered
  and Vulnerable; Pierce, terrain, flight/teleport. Use when writing blue mage
  kits, AoE payloads, or long-fight ramp patterns.
disable-model-invocation: false
---

# ICON — Wright class & jobs (blue)

*Source: `docs/icon/ICON Book Wrights.pdf`.*

## Class fantasy

**Aether** artillery: **big AoE**, **pierce**, **terrain rewrite**, power that
**ramps** as fights lengthen — fragile if melee‑locked.

## Class traits (pattern)

- **Slip:** movement ignores **interrupts**, **vigilance**, **rampart** triggers.
- **Aetherwall:** **resistance** vs abilities originating **outside range 2**.
- **Chain Reaction:** 1/round if this ability **damages 2+ foes**, gain **+1
  Aether** after resolve.

## Aether + Infuse

- Track **Aether** on a **d6** power die (passive tick start of turn + job
  triggers).
- **Infuse X:** pay **X Aether** at **start** of action to swap in upgraded lines;
  **one infusion choice** per use; infused = same ability for talent/mastery.

## Class stats template

**VIT 8 / HP 32 / Def 7 / Speed 4 (Dash 2) / Fray 3 / D8 / Range 6**.

## Status focus

- **Shattered** denies **vigor** interaction.
- **Vulnerable** stacks chip damage across multi-hit patterns.

## Jobs

| Job | Pitch |
|-----|--------|
| **Enochian** | Firebrand calamity; sacrifice / exceed / comeback hooks |
| **Geomancer** | (read PDF) earth / lattice control |
| **Spellblade** | (read PDF) blade-channeling |
| **Stormbender** | (read PDF) storm tempo |

## Homebrew tips

- Infuse lines should **scale cost vs payoff**; watch **map rewrite** density so
  turns stay parseable.
- **Pierce** + **multi-hit** + **Vulnerable** spikes heavies — telegraph costs
  (resolve, aether, HP).

## Links

`icon-combat-glossary` · `icon-jobs-progression` · `icon-ttrpg-index`
