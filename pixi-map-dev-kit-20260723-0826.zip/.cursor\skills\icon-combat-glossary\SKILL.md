---
name: icon-combat-glossary
description: >-
  ICON combat glossary: definitions for Armor, Rush, Shove, Collide, Aura,
  Combo, Mark, Stance, Charge, Heroic, Finishing Blow, Pierce, statuses
  (Slashed, Weakened, Stunned, Sealed, Pacified, Blinded, Dazed, Shattered,
  Vulnerable), summons, terrain types, boons/curses, and triggered-effect
  cadence. Use when parsing or writing ability text, tooltips, or GM prompts.
disable-model-invocation: false
---

# ICON — Combat glossary & advanced keywords

*Source: `docs/icon/ICON Combat Glossary and Advanced Combat.pdf`.*

## How to use this skill

- Treat entries as **definitions**, not permission to paste full copyrighted
  ability stat blocks.
- When writing **homebrew**, mirror **wording patterns** (e.g. “Collide or
  Heroic:”) and **once-per-ability** trigger discipline.

## Triggers & cadence (critical)

- Each **unique** triggered label on an ability (e.g. Collide, Heroic, Charge,
  Finishing Blow, Slay, Exceed, Comeback) typically fires **once per ability use**
  **per trigger event** unless the ability explicitly repeats it.

## Movement / positioning

- **Rush X:** move X; **unstoppable** + **immune to damage** during the move.
- **Shove X:** involuntary straight-line move; **Collide** if blocked by
  character/object/higher elevation.
- **Dash:** ignores **engagement** for that movement.
- **Teleport:** to free space in range; LOS rules as written.
- **Rampart:** blocks **dash / fly / teleport** across affected edge.
- **Engagement:** +1 cost to leave orthogonal adjacency to a foe.

## Ongoing effects

- **Aura X:** continuous area from origin; ends when leaving area (unless
  stated otherwise).
- **Mark:** one per ability per target pair; new mark may replace old.
- **Stance:** one positive stance at a time; refresh rules on the stance.

## Combat resources

- **Combo:** base use grants token; next combo-tagged ability can spend token
  for upgraded line; one token max; cleared end of combat.
- **Blessing token:** spend for +1 boon on a save by default; Mendicant jobs
  add other outlets; all blessings discard end of combat.

## Damage / mitigation language

- **Armor X, Pierce, Divine, Resistance, Cover** — as in glossary.
- **Fray:** flat damage often on hit **and** miss lines of attacks.
- **[D]:** class damage die for the attacker’s current job.

## Status snapshot

| Status | One-line effect (paraphrase) |
|--------|------------------------------|
| Slashed | Damage when moving (cap/turn) |
| Weakened | Deals less damage |
| Stunned | Limits interrupts; next ability ends turn then clears |
| Sealed | Cannot inflict statuses |
| Pacified | Deals half damage; breaks on foe damage |
| Blinded | Range capped |
| Dazed | Attack curse |
| Shattered | Cannot gain/benefit vigor |
| Vulnerable | Takes +1 damage per instance |

Positive tags (Counter, Dodge, Evasion, Flying, Defiance, Regeneration, etc.) —
see PDF for full definitions.

## Class‑specific glossary hooks

- **Heroic** — Stalwart family trigger.
- **Finishing Blow** — Vagabond vs **bloodied** targets.
- **Chain Reaction / Infuse** — Wright family patterns.
- **Cure / Bless** — Mendicant support spine.

For class fantasy + job lists → the four **`icon-class-*`** skills.
