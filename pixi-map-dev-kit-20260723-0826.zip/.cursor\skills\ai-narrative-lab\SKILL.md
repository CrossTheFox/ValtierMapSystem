# Skill: AI Narrative Lab — pixi-map / Valtia-01

Use this skill when working on AI narrative generation features in the pixi-map project:
adding new modes, modifying prompts, changing validation logic, debugging AI output,
adjusting context building, or adding model providers.

---

## What the Lab Does

The AI Narrative Lab allows the **DM (Dungeon Master)** to test two types of AI requests against
the real Valtia-01 wiki data:

1. **Situation mode** — Given an anchor entity + optional intent, proposes 1-3 playable
   situations grounded in actual wiki entities and relations.

2. **Narrative impact mode** — Given a free-text instruction (e.g. "make Engel die"),
   proposes changes to binary relations between existing entities (add / remove / update),
   reviewable and applicable one by one with DM confirmation.

---

## Architecture

```
WikiAiLabPanel (UI) → buildSituationContext → generateNarrativeAi → validateAiResponse
                                                ↓
                               Gemini (Firebase AI Logic)  |  OpenRouter (REST)
                                                ↓
                          dispatch(addWikiRelation) / dispatch(removeWikiRelation)
                                                ↓
                                    Firestore entityRelations
```

---

## Key Files

| File | Role |
|------|------|
| `src/constants/wiki/narrativeAiSchemas.js` | Modes, providers, system prompts, JSON schemas |
| `src/utils/buildSituationContext.js` | BFS subgraph expansion, text serialization |
| `src/utils/validateAiResponse.js` | Deterministic post-AI validation |
| `firebase/aiConfig.js` | Firebase AI Logic (Gemini) initialization |
| `firebase/services/narrativeAiService.js` | Unified API: Gemini + OpenRouter |
| `src/components/wiki/WikiAiLabPanel.jsx` | DM-only React panel |
| `src/components/wiki/NarrativeWikiOverlay.jsx` | Integrates the panel (SmartToyIcon toggle) |
| `scripts/testSituationPrompt.mjs` | CLI for pre-UI testing |
| `docs/memoria/setup-ia-testing.md` | Manual setup guide |

---

## Two Modes

### situation
- Input: anchor entity + optional intent (conflicto, misterio, social, combate, revelacion)
- Output: `{ situations: [{ title, hook, stakes, tone, involvedEntities, dramaticQuestions, dmNotes, confidence }] }`
- Validation: each `involvedEntities[].title` must resolve to an entity in the subgraph context

### narrative_impact
- Input: anchor entity + free instruction string
- Output: `{ summary, proposedRelations: [{ action, fromEntityTitle, toEntityTitle, relationType, ... }], blockedSuggestions, dmNotes }`
- Validation:
  - Entity titles must exist in context
  - `relationType` must be in `KNOWN_WIKI_RELATION_TYPE_VALUES`
  - `validateRelationCreate(fromEntity, toEntity, relationType)` must return true for add/update
  - `resolveRelationEndpoints` determines canonical direction before writing to Firestore

---

## Validation Rules (non-negotiable)

1. **Never invent entities** — all `fromEntityTitle` / `toEntityTitle` / `involvedEntities[].title`
   must resolve to an entity in the current subgraph context.
2. **Only known relation types** — validated against `KNOWN_WIKI_RELATION_TYPE_VALUES` (Set).
3. **Semantic pair validation** — `validateRelationCreate(from, to, type)` from `wikiRelationTypes.js`.
4. **DM admission** — no auto-persist; the DM clicks "Aplicar relación" for each one.
5. **Confidence field** — forced to "baja" if any entity was invented; used for UI color coding.

---

## Context Building (buildSituationContext)

BFS from anchor, sorted by relation priority:
- **Alta:** `vive_en`, `sede_en`, `controla`, `enemigo_de`, `aliado_de`
- **Media:** `miembro_confirmado_de`, `perteneciente_a`, `ocurrio_en`, `participo_en`, `desencadeno`
- **Baja:** `relacionado_con` (only if strength !== 0 or has label)
- **Skip:** `relacionado_con` with strength=0 and no label

Default limits: `maxDepth: 2`, `maxEntities: 25`, `maxRelations: 40`, `maxChars: 10000`.
Outer ring (depth = maxDepth) entities get `compact: true` (summary only, no body).

---

## Providers

| Provider | Implementation | When to use |
|----------|----------------|-------------|
| `gemini` | Firebase AI Logic (`firebase/ai`) | Default, free tier, integrated |
| `openrouter` | REST `https://openrouter.ai/api/v1/chat/completions` | Compare models, needs `VITE_OPENROUTER_API_KEY` |

Gemini models: `gemini-2.5-flash` (default), `gemini-2.5-flash-lite`
OpenRouter models: `google/gemini-2.5-flash`, `deepseek/deepseek-chat-v3-0324`, `openai/gpt-4.1-mini`

---

## Adding a New Mode

1. Add `AI_MODES.MY_MODE` constant in `narrativeAiSchemas.js`.
2. Add system prompt builder and JSON schema.
3. Add user prompt builder.
4. Add validation in `validateAiResponse.js` (new function + dispatch in unified entry point).
5. Add UI section in `WikiAiLabPanel.jsx` for the new output format.
6. Test with CLI: `node scripts/testSituationPrompt.mjs --mode=my_mode --anchor=... --generate`

---

## Debugging Tips

- **`PERMISSION_DENIED` from Gemini**: run `npx -y firebase-tools@latest init ailogic`
- **Empty OpenRouter response**: check `finish_reason` in the error, ensure model supports `json_schema`
- **Invented entities in output**: lower `maxDepth` or add anchor entity to system prompt
- **JSON parse errors**: Gemini sometimes adds markdown fences — `validateAiResponse` strips them
- **CLI `--dry` mode**: prints context without calling AI; useful to check subgraph quality

---

## References

- Architecture plan: `src/constants/wiki/plan-ia-situaciones.md`
- Bibliography + research justification: `docs/memoria/bibliografia-fuentes.md`
- Setup guide: `docs/memoria/setup-ia-testing.md`
- Relation types: `src/constants/wikiRelationTypes.js`
