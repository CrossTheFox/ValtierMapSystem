---
name: fantasy-world-building
description: "Usar cuando el usuario mencione fantasía, sistemas de magia o world-building para ambientaciones fantásticas: convenciones del género, patrones de diseño de magia y marcos de construcción de mundo"
allowed-tools: Read, Grep
---

# Guía de construcción de mundos fantásticos

## Referencia rápida

| Elemento | Principio rector | Punto clave |
|----------|------------------|-------------|
| **Sistema de magia** | Debe tener reglas claras | Las limitaciones importan más que el poder |
| **Ambientación** | Coherencia interna | Cada regla tiene una razón |
| **Razas/criaturas** | Únicas y lógicas | Evitar versiones humanas disfrazadas |
| **Profundidad histórica** | Al menos tres generaciones | El pasado influye en el presente |
| **Estructura política** | Distribución clara del poder | Los conflictos tienen raíces |

## Principios fundamentales

### Leyes de la magia de Sanderson

**Primera ley**: La satisfacción que el lector obtiene de la magia es proporcional a cuánto la entiende
- Si la magia va a resolver un problema, el lector debe entender sus reglas
- Los sistemas de magia blanda (misteriosos) sirven para atmósfera y asombro
- Los sistemas de magia dura (reglas explícitas) sirven para resolver problemas

**Segunda ley**: Las limitaciones son más interesantes que el poder
- La magia poderosa exige un coste poderoso
- Las limitaciones generan conflicto y estrategia
- Un sistema perfecto no puede crear drama

**Tercera ley**: Antes de añadir algo nuevo, expande lo que ya existe
- Profundizar lo existente vale más que añadir elementos nuevos
- Los sistemas interconectados son más fuertes que los aislados
- La complejidad debe crecer de forma orgánica

## Diseño de sistemas de magia

### Magia dura (reglas explícitas)

**Elementos necesarios**:
1. **Fuente de energía**
   - ¿De dónde viene la magia?
   - ¿Es finita o infinita?
   - ¿Se puede agotar?

2. **Reglas de uso**
   - ¿Quién puede usarla? ¿Cómo se obtiene?
   - ¿Qué condiciones se requieren?
   - ¿Qué limitaciones tiene?

3. **Coste/consecuencias**
   - ¿Cuál es el precio de usar magia?
   - ¿Qué pasa si se abusa?
   - ¿Hay efectos a largo plazo?

4. **Posible e imposible**
   - ¿Qué puede hacer la magia?
   - Dejar claro qué no puede hacer
   - ¿Dónde están los límites?

**Marco de ejemplo**:

```
Sistema de magia: control elemental
Fuente: cada persona nace con afinidad a un elemento
Reglas: solo puede controlar su elemento y debe estar presente en el entorno
Limitaciones: fatiga mental; el uso excesivo provoca contragolpe elemental
Coste: consume vitalidad al usarse; requiere descanso para recuperarse
Prohibiciones: no puede crear elementos, solo manipularlos; no puede controlar elementos dentro de seres vivos
```

### Magia blanda (misterio)

**Características**:
- Las reglas no están del todo claras para el lector
- Se usa más para atmósfera y asombro
- No debería resolver cómodamente los conflictos principales
- Mantener misterio y reverencia

**Cuándo usarla**:
- Magia antigua, parcialmente perdida
- Poder divino, más allá de la comprensión mortal
- Asombro de fondo y world-building
- Subtramas que no resuelven la trama principal

## Marco de construcción de mundo

### Geografía y entorno

**Aspectos a considerar**:
1. **Relieve**
   - ¿Cómo influyen montañas, ríos y mares en la civilización?
   - ¿Cómo moldea el clima la cultura?
   - ¿Cómo afecta la distribución de recursos a la economía?

2. **Ecosistema**
   - ¿Cómo es la cadena alimentaria?
   - ¿Cómo se adaptan las criaturas mágicas al entorno?
   - ¿Cómo sobreviven humanos y otras razas inteligentes?

3. **Impacto de la magia en la geografía**
   - ¿Cómo altera la magia la naturaleza?
   - ¿Hay hitos geográficos creados por magia?
   - ¿Qué huellas dejaron catástrofes mágicas?

### Sociedad y cultura

**Arquitectura por capas**:

**Nivel político**:
- Forma de gobierno (monarquía, democracia, teocracia, etc.)
- ¿Cómo se transmite el poder?
- ¿Cómo influye la magia en la política?
- Conflictos entre facciones

**Nivel económico**:
- ¿Qué se comercia y por qué?
- Sistema monetario
- ¿Cómo afecta la magia a la economía?
- Escasez de recursos

**Nivel social**:
- Estructura de clases
- Relaciones entre razas
- Estatus de quienes usan magia
- Educación y difusión del conocimiento

**Nivel cultural**:
- Religión y creencias
- Arte y entretenimiento
- Festividades y tradiciones
- Valores y tabúes

### Profundidad histórica

**Mínimo tres generaciones**:

**Generación actual** (cuando ocurre la historia):
- ¿Cuál es la situación?
- Conflictos y problemas principales
- Facciones y personajes clave

**Generación de los padres** (hace 30-50 años):
- ¿Qué eventos moldearon el presente?
- ¿Qué recuerda la generación anterior?
- Problemas heredados

**Generación de los abuelos** (hace 60-100 años):
- Leyendas e historias
- Conocimiento perdido
- Traumas históricos

**Antigüedad** (más lejana):
- Mitos y leyendas
- Ascenso y caída de civilizaciones
- Semillas sembradas para el presente

## Diseño de razas y criaturas

### Razas inteligentes

**Evitar el estereotipo único**:
❌ Todos los elfos son elegantes y nobles
❌ Todos los enanos son codiciosos e irascibles
❌ Todos los orcos son bárbaros y belicosos

**Crear profundidad**:
✅ Diversidad interna (culturas y valores distintos)
✅ Individualidad (personalidades variadas)
✅ Complejidad histórica (historia con luces y sombras)

**Los rasgos raciales deben tener una razón**:
- ¿Cómo ayudan los rasgos físicos a la supervivencia?
- ¿De dónde vienen los rasgos culturales?
- Historia de las relaciones con otras razas

### Criaturas mágicas

**Principios de diseño**:
1. **Nicho ecológico**
   - ¿Qué papel ocupa en el ecosistema?
   - ¿Qué come? ¿Quién la caza?
   - ¿Cómo se reproduce?

2. **Origen de la magia**
   - ¿Por qué tiene magia?
   - ¿Cómo le ayuda a sobrevivir?
   - ¿Qué coste o limitación tiene?

3. **Relación con los humanos**
   - ¿Es peligrosa o útil?
   - ¿Se puede domesticar?
   - ¿Cómo reaccionan los humanos?

## Trampas habituales

### ❌ Sobreexplicación

**Problema**: Capítulos enteros explicando el mundo en lugar de avanzar la historia

**Solución**:
- Mostrar la ambientación en acción
- Explicar solo lo que el personaje necesita saber
- Dejar que el lector reconstruya parte por sí mismo
- La información debe servir a la trama o al personaje

### ❌ Reglas inconsistentes

**Problema**: La magia o las reglas del mundo cambian por conveniencia de la trama

**Solución**:
- Establecer de antemano todas las reglas principales
- Llevar un registro de lo ya establecido
- Las excepciones requieren pistas tempranas
- Hacer que los personajes resuelvan problemas con creatividad dentro de los límites

### ❌ Europa medieval por defecto

**Problema**: Toda fantasía es una copia de la Europa medieval

**Solución**:
- Explorar otras culturas y épocas
- Mezclar elementos de varias culturas
- Crear estructuras sociales propias
- Considerar cómo la magia altera el desarrollo social

### ❌ Trampa del elegido

**Problema**: El protagonista es especial por profecía o linaje, no por sus actos

**Solución**:
- Que el protagonista se vuelva especial por sus decisiones
- Aunque haya profecía, que deba esforzarse por cumplirla
- Subvertir o deconstruir el tropo
- Centrarse en el crecimiento del personaje, no en el talento innato

## Subgéneros de fantasía

### Alta fantasía (fantasía épica)
- Mundo totalmente ficticio
- Enfrentamiento entre bien y mal
- Escala y riesgos épicos
- La magia forma parte del mundo

### Baja fantasía
- Mundo real + elementos mágicos
- Riesgos personales más acotados
- Magia rara y misteriosa
- Tono más cercano a la tierra

### Fantasía urbana
- Ciudad moderna como escenario
- Mundo mágico oculto
- Suele incluir misterio o investigación
- Choque entre dos mundos

### Fantasía oscura
- Moral gris
- Elementos de horror y violencia
- Protagonistas anti-héroes
- Consecuencias más duras

## Integración con comandos de Novel-Writer

### Al ejecutar `/specify`
- Definir elementos centrales del mundo (magia, razas, geografía)
- Identificar el subgénero de fantasía
- Listar las reglas principales que hay que establecer
- Planificar el ritmo de revelación de información

### Durante `/plan`
- Trazar cómo los elementos del mundo afectan la trama
- Planificar la presentación del sistema de magia
- Diseñar choques entre culturas distintas
- Garantizar coherencia en las reglas del mundo

### Al `/write`
- Mostrar el mundo en acción, no volcar información
- Hacer que los personajes reaccionen a los elementos del mundo
- Usar detalle sensorial para hacerlo vivo
- Mantener coherencia con las reglas ya establecidas

### Durante `/analyze`
- Comprobar coherencia de las reglas del mundo
- Verificar la lógica del sistema de magia
- Confirmar que cada elemento del mundo tiene un propósito
- Asegurar que la ambientación sirve a la historia

## Checklist de world-building

- [ ] El sistema de magia tiene reglas y limitaciones claras
- [ ] Geografía y clima influyen en cultura y trama
- [ ] Al menos tres generaciones de profundidad histórica
- [ ] Varias facciones políticas con motivaciones claras
- [ ] Economía y comercio con base lógica
- [ ] Razas/culturas con diversidad interna
- [ ] Criaturas mágicas con nicho ecológico y propósito
- [ ] Sistemas religiosos/de creencias con impacto real
- [ ] Estructura social con clases y movilidad definidas
- [ ] Todas las reglas se mantienen coherentes a lo largo de la historia

## Estrategia de revelación de información

### Principio del iceberg

**Lo creado vs. lo mostrado**:
- Crear el 100%, pero mostrar solo el 10-20%
- El lector no necesita saberlo todo
- La profundidad genera confianza y coherencia
- El autor sabe más de lo que muestra

### Cuándo revelar qué

**Primer capítulo**:
- Visión básica del mundo (no un tratado exhaustivo)
- Un elemento mágico/fantástico que enganche
- La posición del protagonista en ese mundo

**Primer 25%**:
- Reglas centrales del sistema de magia
- Razas/culturas principales
- Conflicto central y sus raíces en el mundo

**Mitad de la obra**:
- Profundizar lo ya establecido
- Complicar la política del mundo
- Revelar el peso de la historia

**Tramo final**:
- Conectar todos los hilos del mundo
- Revelar la historia profunda
- Mostrar cómo los elementos del mundo resuelven el conflicto

## Expectativas del lector

**Lo que busca el lector de fantasía**:
- Un mundo inmersivo y creíble
- Un sistema de magia coherente e interesante
- Culturas y política complejas
- Una mirada fresca a los tropes clásicos
- Sensación de que el mundo es más grande que la historia

**Lo que frustra al lector de fantasía**:
- Reglas del mundo inconsistentes
- Magia conveniente para la trama
- Copia superficial de Europa medieval
- Mundo sin profundidad
- Volcado de información en lugar de revelación orgánica

---

**Recuerda**: Un gran world-building es la base de la historia, no el fin. El mundo debe servir a los personajes y la trama, y las acciones de los personajes deben estar moldeadas y limitadas por las reglas del mundo. Equilibrar profundidad y fluidez narrativa es la clave.
