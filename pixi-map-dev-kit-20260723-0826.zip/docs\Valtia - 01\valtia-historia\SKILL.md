---
name: valtia-historia
description: >-
  Historia de Valtia-01: fundación de ciudades, linaje Margalous, Felicia/Oni,
  guerras Galathia-Mirage, Motor Zarken. Usar al escribir flashbacks, NPCs
  ancianos, intriga real o tabúes de sangre.
disable-model-invocation: true
---

# Valtia-01 — Historia y linajes

## Calendario

- **D.Z.** = **Después del Diluvio**.
- **Calendario Zarkiano**: unificado dentro de Valtia (7036 D.Z. en campaña).
- Fuera del domo hay discrepancias menores — **no relevantes** para juego actual.

## Fundadores Zarken

**Zaakhiel, Elekhias, Zerynhya, Juuhndy**: todos **muertos**. Mito activo, no NPCs walkable salvo excepción de mesa.

## Orden de fundación de ciudades

1. **Galathia** — ciudad real Zarken; capital imperial; **siempre flotante** (motor tech Zarken casi inagotable).
2. **Techia** — contrapunto al sistema imperial de Galathia; **Gabinete Central muy antiguo**.
3. **Mirage** — descontento de la **hija de Zaakhiel** con «usar a los mortales».
4. **Lorven** — alejarse de Zarkens; no depender de ellos (montañas).
5. **Arvek** — desligarse de todo; mayor territorio → hoy **mayor población**.
6. **Germa** — casi accidental: un **Rey de Valtia** abandonó el trono tras tener hijo; ciudad **hermana/hija** de Galathia, muy buena relación.

## Guerras Galathia–Mirage

- Atrocidades en conflicto pasado; Galathia **odia** a Mirage por ello.
- Se construyó el **Motor Zarken** en Galathia para destruir el torreón de Mirage — **nunca usado** (disuasión tipo bomba de hidrógeno).
- Lorven usó **Nightmares como arma** en guerras iniciales.

## Detonante reciente (~5–10 años)

**Muerte de la reina Felicia** → **depresión de Zorgun** → **inacción real** → tensiones internacionales caldeadas.

## Familia Margalous y sangre Zarken

| Linaje | Sangre Zarken | Notas |
|--------|---------------|--------|
| **Familia Principal** | ~**50 %** | Descendientes directos Zarken |
| **Familia Secundaria** | ~**25 %** | Ramas colaterales |
| **Incesto** | **ESTRICTAMENTE PROHIBIDO** | Riesgo: descendencia **100 % Zarken** = nacimiento de **Zarken puro** (catástrofe) |

### Felicia (DM only — revelar con cuidado)

- Nació en época de adolescencia de Zorgun; ~**25 años** menor que él (≈ 2–3 años en escala Margalous).
- Creía ser **familia secundaria** (prima lejana por sangre Zarken, sin parientes reales).
- En realidad: **Familia Principal** — antepasada fue **3.ª Reina de Valtia** (aventura con campesino).
- Murió cuando **Oni tenía 3–4 años**.
- **Visión:** Oni **destruiría el planeta**.
- Al descubrir linaje verdadero, tomó decisiones en consecuencia.
- **Resurrección posible** (Reakta/Reaktis) pero **nadie la intenta** — Zorgun: miedo por Oni + arrepentimiento por lo que le hizo. Ver `valtia-muerte-reaktis`.

### Oni Margalous

- **Es una Zarken** (sangre / naturaleza — canon DM).
- **Sin conceptos despertados**; enfoque **afinidad física** + espadón mágico (cortes a distancia, foco teletransporte).
- Puede explotar concepto de Zorgun (*Momentum*) o buscar el propio.

### Zorgun Margalous

- Considerado **el más fuerte y poderoso de toda Valtia**.
- Concepto **Momentum** muy explotado; techo actual por **depresión**, no por límite del concepto.
- Madre compartía concepto (proyectiles a distancia); él: **cuerpo a cuerpo**.

## Motor Zarken (Galathia)

- Usa poder de **rey/reina** para **eliminar prácticamente por completo una ciudad**.
- Creado en guerras Galathia–Mirage; **elemento disuasorio** — nunca disparado.

## Profecías

- No hay profecía Zarken formal del fin de Valtia.
- Temor recurrente: **reyes que se vuelven malos**.

## Pendiente (cuestionario sin responder)

- Objetivo del atentado **Morgyns/Leonhard** (DM retiene).
