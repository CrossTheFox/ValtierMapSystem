---
name: valtia-ciudades
description: >-
  Las seis metrópolis de Valtia: gobierno real, economía, arquitectura, odios,
  población millones, teletransporte. Usar al preparar sesiones urbanas o viajes
  interciudad en campaña Valtia-01.
disable-model-invocation: true
---

# Valtia-01 — Ciudades de Valtia

Todas bajo el **domo**. **Metrópolis** de millones; **Arvek** la más poblada (territorio); **Lorven** la menor (montañas).

## Tabla maestra

| Ciudad | Gobierno real | Población | Economía | Arquitectura | Actitud Zarken |
|--------|---------------|-----------|----------|--------------|----------------|
| **Galathia** | Reyes | Metrópoli | Diplomacia, milicia, estudios, turismo | Flotante; magia y gemas; motor Zarken | Descendientes, no devotos |
| **Techia** | Gabinete Central (electo) | Metrópoli | Militar, tech, educación | **Cyberpunk** | Neutral |
| **Mirage** | Pecados públicos; **Zero** oculto | Metrópoli | Militar, inteligencia | **Gótico / neo-noir** | **Veneración** |
| **Lorven** | Presidente (teocracia) | Metrópoli (menor) | Minería, magia | **Dieselpunk** | Neutral |
| **Germa** | Reyes + democracia (pueblo elige) | Metrópoli | Pesquera, ganadería, caza, inteligencia, algo militar | Acuática, similar Galathia | Neutral |
| **Arvek** | Feudalismo local; nadie manda global | Metrópoli (mayor) | Ganadería, magia, alcohol | **Japonesa feudal** | **Desprecio** realeza/Zarken |

## Seguridad (general)

Todos tienen mix; **Techia** → tecnología; **Galathia y Lorven** → más magia.

## Conexión interciudades

- **Teletransporte intraurbano**: común.
- **Interciudad**: Techia desarrollando; **coste crece cada ~100 m** (dispositivos especializados); frenado **político** y económico.
- También rutas convencionales, flotantes, mar interior.

## Odios y tensiones

| Ciudad | Odia / desconfía de |
|--------|---------------------|
| **Galathia** | Mirage (atrocidades de guerra) |
| **Techia** | Nadie (todos son clientes) |
| **Germa** | Nadie |
| **Arvek** | Mirage y Galathia (imperio) |
| **Lorven** | Mirage; desconfía Galathia |
| **Mirage** | No odia; **desprecio** — «falsos» subditos |

## Festividades

- **Galathia y Mirage**: «**Día de la Caída**» (muerte de Zaakhiel).
- **Mirage**: también días de muerte de cada Zarken (incl. hija de Zaakhiel) — **conmemoración**, desfiles, no fiesta alegre.

---

## Galathia

- **Siempre flotante**; sostenida por tech Zarken casi inagotable.
- Monarquía con **consejos y cortes** (no absoluta pura).
- **Zorgun**: respetado/temido en todas las ciudades; nivel varía.
- **Motor Zarken**: puede borrar una ciudad; nunca usado (disuasión).
- Relación **Germa**: ciudad hermana/hija, muy cordial.

## Techia

- **Gabinete Central**: electos; transparencia; **deben representar un grupo** de impacto (social/económico/cultural), no «porque sí».
- Origen antiguo como **contrapeso** a Galathia.
- **Intercambio Ciego**: no prohibido.
- Atentado Morgyns: **DM retiene objetivo**.

## Mirage

- Pecados gobiernan **en público**; **Zero** desconocido públicamente.
- Zero: conciencia que responde a **deseos instaurados en Zarkens**.
- Abierta pero **poco acogedora**.
- Vida diaria: «**subdito del poder superior**» — temor reverencial, valores del subdito.

## Lorven

- **Teocracia** con presidente.
- Usó **Nightmares** masivamente en guerras iniciales.

## Germa

- **Caza Nightmares**; guía rutas marítimas (no control total).
- Solo mar **dentro del domo**.

## Arvek

- **Feudalismo**: cada zona se defiende distinto; suele funcionar.

## Recursos

- **Hambre erradicada** hace mucho; magia/tech acelera agricultura.
- Fauna **comestible** (paladar permitting); pocos tabúes alimentarios.

## Escenas urbanas — checklist

1. Ciudad + barrio + quién manda de verdad.
2. Teletransporte disponible o viaje costoso.
3. Estética (cyberpunk Techia vs feudal Arvek…).
4. Equivalente visible en magia pública.
