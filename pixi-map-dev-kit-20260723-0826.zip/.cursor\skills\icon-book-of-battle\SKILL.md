---
name: icon-book-of-battle
description: >-
  ICON tactical combat fundamentals: when to enter combat, square grid, turns
  and rounds, standard move and dash, two actions per turn, interrupts, core
  stats (VIT/HP/wounds/vigor/defense/speed), boons/curses, basic resource loop.
  Use when explaining combat flow, wounds, or grid rules for the VTT.
disable-model-invocation: true
---

# ICON — Book of Battle (core tactical)

*Source: `docs/icon/ICON Book Of Battle.pdf`.*

## When to use tactical combat

Enter when **stakes cannot be resolved except through battle** (GM has final
say). Establish what each side wants first.

## Grid & scale

- **Square grid**, 1 space = one square; **height** 1–3 common for terrain/objects.
- **PC size** is typically **1**.

## Round structure

- **Alternating** turns (PC / foe). When everyone has gone → **round** advances.
- **Slow turns:** skip normal slot; go after everyone else with other slow
  characters (same PC/NPC alternation when possible).

## On your turn

- **Standard move** (free): up to **Speed**, orthogonal by default unless a
  class/feature allows diagonals.
- **Two actions** for abilities (some cost both).
- **Interrupts** can fire off-turn per their triggers.

## Movement penalties (high level)

- **Difficult terrain**, **climbing height**, **engagement** each add **+1**
  movement cost to leave (take **highest** single penalty, they do not stack
  additively in the quick rules).
- **Dash:** half speed (rounded per book), ignores **engagement** for that move.

## Core stats (tactical)

- **VIT** → max HP = **4 × VIT**; many effects use “one VIT worth” (~25% max
  HP) as a increment.
- **Bloodied:** at or under **50%** max HP.
- **Wound:** on defeat at 0 HP; fills from right of HP track; reduces max HP;
  **4 wounds = total defeat**.
- **Vigor:** temp HP over max; caps at **25% max HP** unless surge says
  otherwise; cleared end of combat.
- **Defense:** to-hit must meet or beat to hit with attacks.
- **Resolve:** fuels **Limit Breaks**.

## Boon / curse (tactical)

- Per boon: roll **+1d6**, keep **highest** with d20 total; curse subtracts
  highest of curse dice. **They cancel 1:1**.

## Link

Detailed **keywords** and edge cases → `icon-combat-glossary`. Job math and
advancement table → `icon-jobs-progression`.
