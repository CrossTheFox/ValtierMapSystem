# Valtia / Valtier - Resumen General del Mundo

> Actualizado 2026-06-08. Detalle en skills `valtia-*`.

## Premisa
Valtia es el **interior del domo** post-Diluvio: seis metrópolis, millones de habitantes, intriga política/mágica. Wernegar exterior = lore (desierto, irrelevante para juego).

**Tono mesa:** sin censura, divertirse; narrativa consistente sin over-engineering.

## Cosmología
- Diluvio = entidad cósmica; único; todos lo saben, nadie el porqué («por lo bajo, Dios»).
- D.Z. = Después del Diluvio. Calendario Zarkiano.
- Observador activo; revelaciones posibles, no eje principal.

## Magia (resumen)
- Todos tienen magia; **sin mana**; Intercambio Equivalente = ley natural.
- Física vs etérea (elegible). Conceptos 1–3 (mortales); Zarken puro ~10.
- Pecados = conceptos transferibles no heredables (7 + Zero).
- ICON: habilidades = formas del concepto.

## Muerte y resurrección
- Alma → más allá; religión: cielo, infierno, resurrección posible.
- **Reakta Techia:** legal, cara, <1 h muerto, catalizador vital; Gabinete regula.
- **Reaktis** (ritual): peligroso; ~2 % fallo = «persona incorrecta».
- **Necromancia:** tabú extremo.
- **Engel:** docenas de resurrecciones forzadas en guerra.
- **Felicia:** se *podría* revivir; Zorgun no lo hará (miedo + culpa).

## Historia reciente
- Muerte reina **Felicia** → depresión **Zorgun** → tensión Galathia/Mirage.
- **Oni** = Zarken (DM); sin concepto; espadón mágico.
- **Motor Zarken** (disuasión, nunca usado).

## Ciudades
Galathia (flotante), Techia (cyber), Mirage (gótico), Lorven (diesel/teocracia), Germa (mar), Arvek (feudal oriental, mayor población).

## Facciones
- **Mártires:** movimiento; tres futuros Zarken (Naylus, Engel→Zaim, Zero→Oni).
- **Pecados:** 7 + Zero; cargos en Mirage; Zwei = Ira; Eins espía en Techia.
- Galathia vs Mirage; atentado Morgyns (objetivo retenido).

## Estado campaña (7036-02-12)
PJs fugados de Galathia → Techia. Oni en capital. Naylus: docs falsos.

## Pendiente (cuestionario reducido)
Vida cotidiana, economía, NPCs clave, mesa, misterios. (Muerte/religión: ver `valtia-muerte-reaktis`.)
