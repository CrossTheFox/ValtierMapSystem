---
name: icon-narrative-system
description: >-
  ICON narrative mode: action rolls with 0–4 action ratings, 1–6 outcome ladder,
  boons/curses capped at ±2d, the twelve actions (Sneak Traverse Sense Study
  Charm Command Tinker Excel Smash Endure), risk and effect, chapter limits,
  XP cadence, and narrative character creation (Kin, Culture, Bond, dot spread).
  Use when roleplaying outside combat, PBTA-style rolls, or narrative advancement.
disable-model-invocation: true
---

# ICON — Narrative system & character setup

*Sources: `docs/icon/ICON Narrative Play.pdf`, `docs/icon/ICON Make Narrative Character.pdf`.*

## Default mode

Narrative play is **conversation-first**; dice only when outcome is **unclear,
dangerous, or contested**.

## Action roll

1. Player states **intent** and picks the **best-fitting action**.
2. GM sets **risk** (controlled / risky / desperate) and **effect** (weak /
   normal / powerful; sometimes none or superpowered).
3. Roll **1d6 per dot** in that action; take **highest**. **0 dots → 2d6 keep
   lowest** (no crits).
4. Read result: **1–3** fail + consequence; **4–5** success with cost; **6**
   clean success; **6+6** critical with **increased effect**.

## Boon / curse (narrative)

- **+1d / −1d** each; cancel 1:1; **hard cap ±2d** total on a roll.

## The twelve actions (names only — flavor in book)

Sneak, Traverse, Sense, Study, Charm, Command, Tinker, Excel, Smash, Endure —
players choose which verb matches their approach; GM may suggest or adjust
risk/effect.

## Character creation (narrative half)

1. Pick **Kin** then **Culture** (no stat diff by Kin — you’re a hero).
2. Pick a **Bond**; take **one bond power** and **+2 dots** in one of the Bond’s
   two highlighted actions.
3. Place **4 more dots** across actions: none above **3** at level 0; only **one**
  action may ever reach **4** later; distribute by culture / personality /
  history as the booklet describes.

## Narrative advancement (15 XP blocks)

- Every **15 XP**: clear XP, **level up** (cannot exceed current **Chapter**).
- Table in PDF lists bond powers vs action improvements per level.

## Tactical bridge

Narrative **Traverse** (etc.) still gates how you describe **world-scale**
movement outside tactical maps — tactical job mobility does not auto-supersede
bad narrative ratings.

## Related skills

- Bonds detail sheets → `icon-bonds-overview`
- Tactical combat → `icon-book-of-battle` + `icon-combat-glossary`
- Jobs/AP → `icon-jobs-progression`
