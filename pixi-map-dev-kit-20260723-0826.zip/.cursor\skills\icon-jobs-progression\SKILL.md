---
name: icon-jobs-progression
description: >-
  ICON tactical job rules: choosing a Job at level 0, class traits vs job traits,
  ability points, talents vs masteries, expedition ability limits, primary job,
  second/third job at levels 4 and 8, refocus, relic unlock cadence, chapter
  gates. Use when discussing ICON leveling, AP, multiclass jobs, or relic timing.
disable-model-invocation: false
---

# ICON — Jobs & tactical progression

*Source booklet: `docs/icon/ICON Jobs.pdf` (local only).*

## Core loop (level 0)

- Pick **one Job** and **two abilities** from that job for tactical play.
- You receive **all traits and actions** from your **class** (one of four:
  Stalwart, Vagabond, Mendicant, Wright) **plus** traits from the **job**.
- Unsure which abilities? First two listed in the job are the suggested default.

## After first session → level 1

- Unlock **Limit Break**.
- Gain **+2 AP** to spend on new abilities **or** unlocking **talents** of
  abilities you already have.

## Ongoing AP (level 1+)

- Every **7 XP** → **+1 ability point** (spend during **camp**, **interlude**, or
  end of session).
- Additional **bonus AP** at certain levels (see tactical advancement table in
  the PDF).

## Talents vs masteries

- Each ability has **two talents**; spending AP on a talent picks **either**
  talent I **or** talent II — **never both**.
- **Masteries** require **mastery points** (from leveling; more if you **skip**
  new jobs at levels 4 and 8).

## Expedition loadout

- At most **6 abilities** per expedition; swap between expeditions.
- **At least half** (rounded up) must match the **class color** of your **primary
  job** (see class skills).

## Traits & limit break

- **Traits** and **Limit Break** come only from the **primary job** (class +
  job traits for that job). Mix abilities from other jobs, but primary defines
  traits/LB.

## New jobs (levels 4 & 8)

- **Option A:** New job → **+2 AP** (broad training).
- **Option B:** Same job again → **+1 mastery point** (deep specialization).

## Refocus (level 1+)

During an **interlude**, full rebuild: refund AP & abilities & talents &
masteries & jobs, then re-pick the same number of jobs and spend normally.
Costs **8 dust** (or **4** if jobs unchanged).

## Relics (summary)

- Relics at **levels 2, 6, 9**; three ranks; **Aspect** at rank IV (12 dust or
  quest; reduced dust after a party completes that aspect quest once).
- Invoke types: **Attack**, **Gambit**, **Round** — see `icon-relics-overview`.

## Chapter

- Abilities gained must be from **current chapter or lower**; chapter‑3 jobs
  gain improved limit break (**Ultimate**) and extra trait.

## VTT note

Store **selected job ids**, **primary job**, **AP spent**, **equipped ability
ids** (max 6), and **chapter** in app state or Firestore — mirror these rules
when validating builds in code.
