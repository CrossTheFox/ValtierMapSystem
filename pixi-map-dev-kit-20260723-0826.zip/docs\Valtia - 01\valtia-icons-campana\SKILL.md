---
name: valtia-icons-campana
description: >-
  ICONs en Wernegar y gancho de campaña Valtia-01: qué es un ICON, tono de
  poder, caravana inicial y expectativas de juego. Usar al crear PJs, NPCs
  ICON, ganchos de sesión o calibrar poder narrativo en Valt6.
disable-model-invocation: true
---

# Valtia-01 — ICONs y campaña

## Qué es un ICON (en este setting)

> Eres un ICON. No por título, ni por decreto, sino porque el mundo te reconoce como tal.

El poder **supera el estándar de Wernegar** de forma innegable. Origen típico (la razón concreta **no importa** tanto como el resultado):

- Magia heredada que **alcanzó su punto máximo** contigo.
- **Artefacto Zarken** que no debería seguir funcionando.
- **Coincidencia imposible** del destino.

## Estatus social

| Reacción | Manifestación |
|----------|----------------|
| Veneración | Puertas abiertas, tributos, peticiones |
| Miedo | Insomnio colectivo, cultos clandestinos, huida |
| Respeto pragmático | Contratos tácitos: problema resuelto → no preguntas |

**Fingir ser ICON** sin serlo: en Wernegar **no suele vivirse lo suficiente** para intentarlo dos veces.

## Presente de campaña

Este skill describe el **gancho de entrada** (PDF: caravana ICON hacia el domo). La mesa **actual** juega **dentro de Valtia** — intriga entre ciudades (ver `valtia-estado-actual`, `valtia-ciudades`). Los PJs pueden seguir siendo ICON en reglas ICON; su poder es reconocido pero la trama es **política**, no wandering hero por defecto.

## Rutina ICON (Wernegar exterior / era anterior)

- Traslado entre poblados aislados.
- Resolver monstruos, disputas, plagas — o **someter** aldeas.
- Ser **parte del paisaje** de poder; lo extraordinario es **normalizado** para ellos.

## Gancho — La caravana a Valtia

Un día **sin anuncio ni presagio**:

- Aparece un **viejo ICON** de poder **inestable**.
- Habla de **caravana**, de **investigar la región**, de comprender qué hay **tras el domo**.
- Afirma necesitar **otros ICONs**; el viaje es **peligroso pero necesario**.
- Los PJs **deciden unirse** — inicio de campaña Valtia-01.

### Directrices para el ICON convocador (NPC)

- Conocimiento **parcial**; puede ocultar motivos (miedo al castigo, deuda generacional Zarken, artefacto que «llama»).
- **Inestabilidad** mecánica/narrativa: surges de poder, blackouts, visiones del Diluvio.
- No debe eclipsar a los PJs; es ** catalizador**, no protagonista único.

## Tono de juego ICON

- **ICON** usa reglas de poder de ICON TTRPG (`icon-ttrpg-index`); el setting añade **peso existencial** (castigo cósmico, legado Zarken).
- Combates contra fauna mutada: a menudo **narrativos** para ICONs; el reto es **decisión**, no TPK.
- En Valtia: elevar amenaza — aquí **sí** hay riesgo real incluso para ICONs.

## Preguntas de creación de PJ

1. ¿Cómo **Wernegar te reconoce** (mito local, terror, leyenda)?
2. ¿Qué **deuda o curiosidad** te hace aceptar Valtia pese a que otros la evitan?
3. ¿Tu poder tiene **coste** visible (artefacto, linaje, promesa)?
4. ¿Relación con **Zarkens, híbridos o tecnología** pre-Diluvio?

## Sesión cero — acuerdos

- Horror cósmico **posible**, no constante.
- Violencia imperial y exterminio son **historia** — presente puede ser gris moral (guardianes Zarken, supervivencia).
- Revelaciones del domo: pacing lento; **misterio > lore dump**.
