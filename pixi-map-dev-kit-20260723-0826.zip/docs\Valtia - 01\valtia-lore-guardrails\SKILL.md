---
name: valtia-lore-guardrails
description: >-
  Guardrails canon Valtia-01 desde cuestionario 2026-06-08. Usar al validar
  lore nuevo contra respuestas DM confirmadas.
disable-model-invocation: true
---

# Valtia-01 — Guardrails de lore

## Jerarquía de fuentes

1. **`valtia-worldbuilding-respuestas.json`** — respuestas DM (96+ confirmadas).
2. Skills `valtia-*` — elaboración.
3. PDF / resumen — cosmología base.
4. Improvisación → documentar después.

## Canon confirmado (no contradecir)

### Mundo
- Valtia = **solo interior del domo**; 6 metrópolis millones.
- Wernegar exterior = **lore fondo**, desierto, no comercio.
- D.Z. = Después del Diluvio; Calendario Zarkiano interno.
- Diluvio **único**; entidad cósmica; observador sigue pero **no eje campaña**.

### Magia
- Todos tienen magia; **sin mana**, solo pago + agotamiento.
- Equivalente = **ley natural**; pago **imposible de eludir**.
- Ciego: Naylus líder teórico; huella = **sanidad** (desplazable).
- Conceptos 1–3; Zarken puro ~10; Pecados transferibles no heredables.
- ICON abilities = expresiones de concepto.

### Muerte y resurrección
- Alma → **más allá**; religión: **cielo, infierno, resurrección/reencarnación**.
- **Reaktis** no prohibidos; **Reakta Techia** legal, cara, Gabinete; <1 h + catalizador + pago material.
- **Necromancia** = tabú extremo; sacrificios inocentes.
- Fallo ~**2 %** = entidad que no es la persona original.
- **Engel**: docenas resurrecciones forzadas (Reakta → última necromancia).
- **Felicia**: revivable, **nadie quiere** (Zorgun: miedo + culpa).
- **Nyssara/Caelum**: fuera Valtia; amnesia por Equivalente, **no Reakta**.
- PJs **no replican** resurrección; mesa: posible con **coste enorme**.

### Historia / real
- Felicia murió; Zorgun deprimido; escalada internacional.
- Oni = Zarken; visión destrucción planeta (DM).
- Incesto Margalous **prohibido**.
- Motor Zarken **nunca usado**.
- Fundadores Zarken **muertos**.
- Margalous = descendencia directa Zarken (apellido de familias elegidas).

### Facciones
- **7 Pecados + Zero**; cargo reemplazable vía pruebas dolorosas en Mirage.
- **Zwei** = Ira. **Eins** espía en Techia.
- **Mártires** = movimiento; tres filosofías (Naylus pragmático, Engel/Zaim, Zero/Oni).
- Bases: Naylus Galathia, Engel Lorven, Zero Mirage.

### Pendiente (cuestionario reducido)
- Sociedad cotidiana (parcial: muerte/religión **sí**), economía, NPCs clave, mesa, misterios.
- Atentado Morgyns (objetivo retenido).

## Tono mesa

Sin censura; divertirse; narrativo consistente **sin over-engineering** (meta Envy).

## Al añadir lore

```
- [ ] ¿Contradice valtia-worldbuilding-respuestas.json o valtia-muerte-reaktis?
- [ ] ¿Rellena hueco marcado pendiente?
- [ ] ¿Requiere actualizar skill de ciudad/magia/historia?
```
