# Fase 2 VTT — Estado

La Fase 2 del roadmap (VTT táctico) quedó **activada** en runtime (grid, tokens, chat, mapa activo, quick actions).

## Completado

1. **Mapa activo / cambio de mapas** — `switchMap`, `MapSelectorHUD`, `useActiveMapSync`
2. **Grilla configurable** — `GridLayer` (auto cellSize = map.width / columns, default 30), control DM en `MapSelectorHUD`
3. **Tokens individuales** — `TokenLayer` (imagen circular, tamaños, snap), `TokenDeployPanel` (DM)
4. **Movimiento animado + snap a grid** — GSAP + `snapToGridCenter` (también measurement)
5. **Chat** — `VttChatPanel` + `chatService` (`campaigns/{id}/messages`), IC / OOC (`/`)
6. **Quick Actions** — `QuickActionsBar` sincronizado con `activeCharacterId`

## Archivos clave

- `src/pixi/GridLayer.jsx`, `src/pixi/TokenLayer.jsx`
- `src/utils/gridMath.js`
- `src/components/vtt/MapSelectorHUD.jsx`, `TokenDeployPanel.jsx`, `VttChatPanel.jsx`, `QuickActionsBar.jsx`
- `firebase/services/chatService.js`, `gameService.js`
- Campos personaje: `tokenImageUrl`, `tokenSize` (editor en Bio del sheet)

## Completado (sync multiplayer)

- `gridConfig` por mapa en `maps/{id}` + `useMapGridSync` (columnas/snap compartidos; `visible` local)
- Movimiento de tokens: DJ todos; jugadores vía roster / `ownerPlayerId` / `controlledByPlayerIds`
- Deploy/move actualiza `tokenPositions` + `character.locationId` (pin más cercano)
- Panel de tokens disponible para jugadores (solo sus controlables)

## Pendiente futuro (fuera de este slice)

- Más metadata de tokens (condiciones, HP ring, etc.)
