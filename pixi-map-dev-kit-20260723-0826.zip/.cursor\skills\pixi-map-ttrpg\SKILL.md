---
name: pixi-map-ttrpg
description: >-
  Architecture guide, cyberpunk/synthwave UI conventions, and coding standards
  for the pixi-map TTRPG virtual tabletop. Use when adding features, Redux
  slices, Pixi layers, Firestore collections, or MUI/React UI; when building new
  components that must match the cyber HUD look; or when debugging structure,
  data model, or Firebase integration.
---

# Pixi-Map TTRPG — Project Reference

## What this is

A virtual tabletop map for **ICON TTRPG** sessions (campaign Valt6-01).
Players connect via Firebase Auth, see a shared PixiJS map, and the GM controls
locations, characters, lore, and more in real-time.

**Stack:** React 19 + Vite (rolldown-vite) · PixiJS v8 + @pixi/react · Redux
Toolkit · Firebase (Auth, Firestore, Storage) · MUI v7 · GSAP · pixi-viewport

**ICON TTRPG (rules & homebrew):** See `.cursor/skills/icon-ttrpg-index/` for
the skill router (Jobs, combat glossary, narrative, Bonds, Relics, and the four
class archetypes: Stalwart / Vagabond / Mendicant / Wright). Use those skills when
designing abilities, jobs, or lore that must stay compatible with ICON; this
skill stays focused on **this codebase**.

**Visual identity:** Dark **cyber / synthwave HUD** — neon magenta and hot pink
accents, cyan “system” highlights, near-black violet panels. Tipografía UI:
**Orbitron** (títulos vía `CyberTitle`), **Fira Sans** (cuerpo vía `CyberText`).

---

## Cyber visual design system (canonical)

Use this for **every new React/MUI component** so the app stays one coherent
“terminal / battle map console” experience.

### Source of truth

| Asset | Location |
|-------|----------|
| Color tokens | `src/constants/uiColors.js` → export `UI_COLORS` |
| Heading & body text | `src/components/customs/CustomTexts.jsx` → `CyberTitle`, `CyberText` |
| Fonts (loaded globally) | `index.html` — Orbitron, Fira Sans, Michroma, Datatype |

**Rule:** Do not introduce ad-hoc hex neons or new “brand” colors in `sx` unless
the change is meant to **extend** `UI_COLORS` for the whole app (then update the
constant and reuse it).

### Palette roles (`UI_COLORS`)

- **`backgroundPrimary` / `backgroundSecondary`:** Main shell and elevated
  panels (dialogs, drawers). Keep surfaces dark; no light gray cards.
- **`border`:** Default 1px borders, dividers, subtle frames (`1px solid`).
- **`textPrimary` / `textSecondary`:** Body and muted labels. Prefer high
  contrast on dark (white / gray).
- **`accent`:** Primary interactive emphasis — icon buttons, links, active tab
  affordances, focus rings (see Landing + `BaseTabbedDialog`).
- **`accentStrong`:** Stronger emphasis (dangerous actions, critical highlights).
- **`accentGlow`:** `box-shadow` / soft glow around focused or hovered controls
  (use sparingly).
- **`anomaly`:** Secondary “system / tech / info” accent (cyan) — use for data
  highlights, secondary CTAs, or “holographic” hints so magenta stays primary.

### Typography

- **Titles, labels, buttons, tab labels:** `CyberTitle` — **Orbitron**, uppercase,
  letter-spacing como en `CustomTexts.jsx`.
- **Paragraphs, stats, lore, form hints inside dialogs:** `CyberText` — **Fira
  Sans**; respeta `DialogFontSizeContext` bajo diálogos.
- **Avoid:** Default MUI `Typography` for user-facing cyber UI unless it is
  truly internal/debug. Plain `<Typography>` without las fuentes del HUD rompe
  la coherencia.

### MUI / `sx` patterns

- **Panels:** `bgcolor: UI_COLORS.backgroundSecondary`, 1px border in `sx` using
  `UI_COLORS.border`, optional `borderRadius: 1`–`2` (subtle; not bubbly
  consumer UI).
- **IconButton / small controls:** `color: UI_COLORS.accent`; disabled:
  `rgba(255,255,255,0.32)` or equivalent low-opacity white (see
  `BaseTabbedDialog`).
- **Hover:** `transition: "color 0.2s, box-shadow 0.2s, background-color 0.2s"`;
  optional soft glow via `accentGlow`.
- **Focus (keyboard):** visible outline or `&:focus-visible` using `accent` —
  neon UIs often fail a11y; do not rely on browser default alone on dark bg.
- **Snackbar / feedback:** keep severity colors but frame copy with `CyberText`
  where it fits the overlay.

### Motion & chrome

- Short transitions **150–300ms**; avoid long bounces on HUD widgets.
- Decorative motion (grid, scanlines) belongs in dedicated animation components
  (e.g. `CyberPattern` on landing); do not duplicate heavy effects on every
  dialog.
- Respect **`prefers-reduced-motion`** for non-essential animations when adding
  new motion.

### Cross-check with `ui-ux-pro-max`

For **large new surfaces** (new page, marketing block, dense dashboard), you may
cross-check `.cursor/skills/ui-ux-pro-max/` (e.g. design-system search for
“cyberpunk gaming dark dashboard”). Treat its palettes as **inspiration**;
**this project’s `UI_COLORS` win** over generic Pro Max purple/rose suggestions.
Use Pro Max for UX checklists (focus states, hover, breakpoints, reduced
motion) and `--stack react` for React-specific performance notes.

### Anti-patterns

- Light-mode-style white/off-white **page** backgrounds for main UI.
- MUI default **blue** primary for buttons/links without theming.
- Random neon hexes in one-off components.
- Emojis as icons (prefer MUI Icons or SVG).
- All-caps body paragraphs (reserve uppercase for titles / short labels).
- **Black / default MUI text on dark menus** (`MenuItem`, `Select`, list options).
  Always set `UI_COLORS.textPrimary` (or `cyberMenuItemSx` / `cyberMenuPaperSx`
  from `designSystem.js`). See `.cursor/rules/dark-ui-contrast.mdc`.

---

## Directory Map

```
src/
├── App.jsx                  # Auth guard + Router (/, /map, /popup)
├── layers/
│   ├── PixiRoot.jsx         # Mounts <Application>, loads world, provides ViewportContext
│   └── UIOverlay.jsx        # React UI on top of the canvas
├── pixi/                    # PixiJS-only components (must live inside <Application>)
│   ├── MapViewport.jsx      # pixi-viewport setup; exposes viewport via ViewportContext
│   ├── LocationsLayer.jsx   # Pins for each location + characters
│   ├── PartyLayer.jsx       # Real-time party token
│   ├── DistanceMeasureLayer.jsx
│   └── PixiTooltip.jsx
├── components/              # Pure React / MUI components (outside canvas)
│   ├── MapControls.jsx
│   ├── MapContextMenu.jsx
│   ├── CharactersSettingsDialog.jsx
│   ├── LoreDialog.jsx
│   └── ...
├── store/                   # Redux Toolkit slices
│   ├── index.js             # configureStore
│   ├── worldSlice.js        # map, locations, characters, lore + async thunks
│   ├── uiSlice.js           # selectedLocation, contextMenu, snackbar, measureTool
│   ├── playerSlice.js       # current player (uid, nickname, role)
│   ├── characterSlice.js    # character sheet state
│   └── gameSlice.js         # shared real-time game session (party positions)
├── pages/
│   ├── LandingPage.jsx
│   ├── MainMapPage.jsx
│   └── PopupDialogPage.jsx
├── context/
│   └── ViewportContext.js   # React context that holds the pixi-viewport instance
├── hooks/                   # Custom hooks
├── utils/                   # Pure helpers
└── constants/
firebase/
├── firebaseConfig.js        # exports: app, auth, db, storage
└── services/
    ├── assetLoader.js       # warmAsset / warmCharacterAssets / loadTexture
    └── encyclopediaService.js
```

**Character images:** `preloadWorldAssets` warms every character `tokenImageUrl`
+ `imageUrl` (browser decode + PIXI) before the HUD mounts. Read URLs with
`useAssetUrl(path)` / `getCachedUrl` — do not call `loadFirebaseAsset` per
avatar mount (causes flash). Soft-warm continues on `switchMap` and realtime
character upserts.

---

## Firestore Data Model

| Collection | Key fields | Notes |
|------------|-----------|-------|
| `campaigns` | `id`, `name` | Top-level entity |
| `maps` | `id`, `campaignId`, `imageUrl`, `widthPx`, `heightPx` | One per campaign |
| `locations` | `id`, `mapId`, `campaignId`, `name`, `x`, `y`, `description` | Pins on the map |
| `characters` | `id`, `campaignId`, `locationId`, `name`, `imageUrl`, `stats`, `bondPowers`, `bond` | Nested under locations in Redux |
| `players` | `id` (= uid), `nickname`, `role` | role: "gm" \| "player" |
| `encyclopedia` | `id`, `campaignId`, `title`, `content`, `category` | Lore entries |
| `abilities` | `id`, `campaignId` | |
| `game` | `id` (= campaignId) | Real-time session doc: party positions per map |

**Important:** Firestore `Timestamp` objects are serialized to ISO strings via
`serializeFirestore()` in `worldSlice.js` before entering Redux.

---

## Redux Store Shape

```js
store = {
  world: {
    selectedCampaignId, map, locations, lore,
    worldStatus,    // "idle" | "loading" | "succeeded" | "failed"
    assetsStatus,   // same
    error
  },
  ui: {
    selectedLocation, selectedLore,
    isSelectingPosition, isMinimized, selectedWorldPosition,
    snackbar: { open, message, severity, action },
    contextMenu: { open, screenX, screenY, worldX, worldY, type, location },
    measureTool: { pointA, pointB }   // { x, y, label }
  },
  player: { uid, nickname, role },
  characters: { /* character sheet data */ },
  game: { /* real-time session */ }
}
```

`locations` is a **keyed object** `{ [locationId]: { ...location, characters: [] } }`.
Characters are embedded inside their location in Redux (not a separate top-level map).

---

## Patterns & Conventions

### Adding a new Pixi layer

1. Create `src/pixi/MyLayer.jsx` — component must only use PixiJS React primitives.
2. Import and mount it **inside** `<MapViewportProvider>` in `PixiRoot.jsx`.
3. Access the viewport via `useContext(ViewportContext)`.

### Adding a new Redux slice

1. Create `src/store/mySlice.js` using `createSlice` + `createAsyncThunk`.
2. Register the reducer in `src/store/index.js`.
3. Serialize any Firestore Timestamps before storing.

### Adding a new Firestore collection

1. Add security rule in `firestore.rules` (pattern: `allow read, write: if request.auth != null`).
2. Add a service function in `firebase/services/`.
3. Add async thunks in the relevant Redux slice.

### UI components (non-canvas)

- Use **MUI** components — the project already imports `@mui/material` + `@emotion`.
- Follow **Cyber visual design system** above: `UI_COLORS`, `CyberTitle`,
  `CyberText`.
- Dialogs extend `BaseTabbedDialog.jsx` pattern when they have multiple tabs.
- Draggable panels use `DraggableResizablePaper.jsx`.
- Notifications go through `dispatch(showSnackbar({ message, severity }))`.

### Role guard

```js
const { role } = useSelector(state => state.player);
if (role !== "gm") return null; // GM-only feature
```

---

## Key Gotchas

- **Rolldown-vite** is used instead of standard Vite (`"vite": "npm:rolldown-vite@7.2.5"`). Behavior is the same but the binary differs.
- `@pixi/react` v8 wraps Pixi v8 — APIs differ significantly from Pixi v6/v7.
- `pixi-viewport` instance is shared via `ViewportContext`; never import it directly from a module.
- The `locations` Redux shape is a plain object (not an array) — iterate with `Object.values(state.world.locations)`.
- `.env` holds Firebase config keys — never commit new secrets; reference them via `import.meta.env.VITE_*`.
