---
name: valtia-diluvio-rojo
description: >-
  Diluvio Rojo en Valtia-01: entidad cósmica, folklore por ciudad, observador
  residual, evento único. Usar al escribir religión, miedo colectivo o Nightmares.
disable-model-invocation: true
---

# Valtia-01 — Diluvio Rojo

## Qué fue

Castigo de una **entidad cósmica** contra los Zarken. **Evento único** — no hubo mini-diluvios.

### Manifestación

- Lluvia carmesí planetaria; tierra corrompida; tech apagada; vida masacrada.
- Wernegar exterior quedó como **desierto** arrasado — lugar de escape Zarken en lore popular.

## Qué sabe la gente

- **Todos saben** que algo cósmico **pulverizó** a los Zarken.
- **Nadie sabe** quién/qué ni **por qué**.
- Pensamiento general: «**por lo bajo, fue Dios**» — tema del que **todos tienen miedo hablar**.

### Interpretaciones por cosmovisión

| Grupo | Lectura |
|-------|---------|
| **Mirage, Lorven** (apego Zarken) | **Envidia** de la deidad |
| **Resto** | «Fueron demasiado lejos demasiado rápido» / **karma** |

Los relatos **coinciden en hechos**; cambia el **matiz emocional**.

## Observador post-Diluvio

- **Algo sigue observando** — no será eje principal de campaña.
- Habrá **tintes y revelaciones** sobre qué provocó el Diluvio; no exploración directa del observador.

## Segundo Diluvio

- **Nadie** lo invoca activamente como solución.

## Nightmares (vínculo)

- Criaturas míticas con **residuos** del Diluvio — ver `valtia-magia` / sección Nightmares en geografía.
- **No** son cobradores del Intercambio Ciego.

## Profecías

- No profecía formal del fin; **temor a reyes malos**.

## Uso en mesa

- Miedo **silencioso**, no sermones constantes.
- Conmemoraciones (Día de la Caída) ≠ alegría — **desfiles**, peso histórico.
