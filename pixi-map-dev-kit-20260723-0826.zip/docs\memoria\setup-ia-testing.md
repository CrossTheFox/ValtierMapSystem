# Setup: Laboratorio IA Narrativo — pixi-map / Valtia-01

Guía paso a paso para configurar y comenzar a probar el Lab IA en el front y en el CLI.

---

## 1. Habilitar Firebase AI Logic en la consola

1. Ve a [Firebase Console](https://console.firebase.google.com) → proyecto `valtier-map-system`.
2. En el menú lateral: **Build → AI Logic** → pestaña **Todas las apps**.
3. Si ves la app `ValtierWebApp`, ya está registrada. Haz clic en **Ver las instrucciones del SDK** para confirmar que el proyecto tiene AI Logic activo.
4. Elige **Gemini Developer API** si aún no lo hiciste (tier gratuito para prototipos).

> Ya tienes plan **Blaze** activo — eso es correcto para AI Logic en producción.

---

## 2. Provisioning con CLI (obligatorio, una sola vez)

Abre una terminal en la raíz del proyecto y ejecuta estos tres comandos en orden:

```bash
npx -y firebase-tools@latest login
npx -y firebase-tools@latest use valtier-map-system
npx -y firebase-tools@latest init ailogic
```

El comando `init ailogic` añade la sección `"ailogic": {}` en `firebase.json` y provisiona el servicio en el proyecto. Sin este paso, las llamadas desde el front fallan con `PERMISSION_DENIED`.

---

## 3. API Key de Gemini (para el script CLI)

El panel de front usa Firebase AI Logic directamente (sin clave explícita en el browser). El script Node sí necesita una clave de la Gemini Developer API:

1. Ve a [Google AI Studio](https://aistudio.google.com/apikey) → **Create API key** → selecciona el proyecto `valtier-map-system`.
2. Copia la clave (formato `AIza…`).
3. Añádela al archivo `.env` en la raíz del proyecto:

```
GEMINI_API_KEY=AIzaSy...
```

---

## 4. OpenRouter (opcional, para comparar modelos)

1. Crea cuenta en [openrouter.ai](https://openrouter.ai).
2. Ve a **API Keys** → **Create key**.
3. Añade créditos prepago mínimos (~$5) para modelos de pago.
4. Añade al `.env`:

```
VITE_OPENROUTER_API_KEY=sk-or-...
```

El panel de lab deshabilitará automáticamente el proveedor OpenRouter si esta variable no está presente.

---

## 5. Cargar datos wiki en tu campaña

Si aún no tienes entidades en la campaña real:

```bash
npm run seed-valtia-wiki -- --campaignId=RfY23gcG7No5HcGddo1j
```

Necesitas el service account JSON en la raíz:
`valtier-map-system-firebase-admins.json` (o `serviceAccount.json`).

---

## 6. Primer test con el script CLI

```bash
# Solo ver contexto del subgrafo (sin llamar a la IA, usa seed local)
node scripts/testSituationPrompt.mjs --anchor=galathia --dry --local

# Generar situación con Gemini (necesita GEMINI_API_KEY en .env)
node scripts/testSituationPrompt.mjs --anchor=galathia --mode=situation --intent=conflicto --generate --local

# Impacto narrativo con instrucción libre
node scripts/testSituationPrompt.mjs --anchor=engel --mode=impact --instruction="haz que muera" --generate --local

# Comparar con DeepSeek vía OpenRouter
node scripts/testSituationPrompt.mjs --anchor=mirage --provider=openrouter --model=deepseek/deepseek-chat-v3-0324 --generate --local
```

---

## 7. Usar el panel Lab IA en el front

1. `npm run dev` y abre el mapa como DJ.
2. Abre el overlay wiki (ícono de libro).
3. En la barra superior, haz clic en el ícono de robot 🤖 (solo visible para DJ).
4. Selecciona una entidad en el listado como ancla.
5. Elige modo (Situación / Impacto narrativo), proveedor y modelo.
6. Haz clic en **Generar**.
7. En modo impacto: cada relación válida tiene botón **Aplicar relación** con confirmación.

---

## 8. App Check (pre-producción, Fase 4)

Firebase te avisa en consola que registres App Check. Para desarrollo local puedes omitirlo. Para producción, configura reCAPTCHA v3 o Play Integrity.

---

## Troubleshooting

| Error | Solución |
|-------|----------|
| `PERMISSION_DENIED` en front | Ejecutar `npx -y firebase-tools@latest init ailogic` |
| `prepayment credits are depleted` (429) | Créditos del proyecto Firebase agotados. Añade `VITE_GEMINI_API_KEY` (misma que `GEMINI_API_KEY`), reinicia dev server y usa proveedor **Gemini API (local)**. O recarga en [ai.studio/projects](https://ai.studio/projects) |
| `GEMINI_API_KEY no encontrada` | Añadir clave en `.env` para CLI |
| OpenRouter deshabilitado en UI | Añadir `VITE_OPENROUTER_API_KEY` en `.env` y reiniciar `npm run dev` |
| Subgrafo con 0 relaciones | Ejecutar seed wiki en campaña o usar `--local` con seed corregido |
| Entidades inventadas en respuesta | Revisar ancla; probar con `galathia`, `engel` o `mirage` |
