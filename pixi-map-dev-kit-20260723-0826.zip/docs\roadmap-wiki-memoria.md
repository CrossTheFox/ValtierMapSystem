# Roadmap — Wiki narrativa y propagación dinámica (memoria Cap. 1)

**Última actualización:** mayo 2026  
**Referencias:** [`investigacion-worldanvil-funciones.md`](./investigacion-worldanvil-funciones.md), [`memoria-capitulo1-alcance/decisiones-diseno.md`](./memoria-capitulo1-alcance/decisiones-diseno.md), [`memoria-capitulo1-alcance/modelo-datos-entidades.md`](./memoria-capitulo1-alcance/modelo-datos-entidades.md)

Este roadmap organiza el trabajo en **fases secuenciales**. Cada fase tiene entregables, criterios de “hecho” y dependencias. El **diferenciador del proyecto** (frente a World Anvil) es la **Fase 4**: integración LLM para propagar consecuencias de sesión con sugerencias revisables por el DM.

---

## Estado actual (línea base)

| Área | Hecho | Pendiente |
|------|-------|-----------|
| **VTT** | Mapas, ubicaciones, personajes en mapa, Lore (`encyclopedia`), asignación PJ ↔ ubicación | Puente formal con wiki |
| **Wiki** | CRUD `wikiEntities`, relaciones `entityRelations`, 8 tipos v1, visibilidad `dm_only` en cliente, UI básica (`NarrativeWikiPage`) | Menciones, plantillas, búsqueda, reglas Firestore |
| **IA** | Decisión técnica (Firebase AI Logic + Gemini, español) | Sin implementación |

---

## Vista general de fases

```mermaid
flowchart LR
    F0[F0 Fundamentos] --> F1[F1 Wiki en mesa]
    F1 --> F2[F2 Contenido rico]
    F2 --> F3[F3 Eventos de sesión]
    F3 --> F4[F4 LLM propagación]
    F4 --> F5[F5 Visualización]
    F5 --> F6[F6 Evaluación memoria]
    F6 --> F7[F7 Post-memoria]
```

| Fase | Nombre | Objetivo | Depende de |
|------|--------|----------|------------|
| **0** | Fundamentos | MVP wiki + VTT coexistiendo | — |
| **1** | Wiki en mesa | Archivo usable durante partida | F0 |
| **2** | Contenido rico | Tipos, plantillas, organización | F1 |
| **3** | Eventos de sesión (manual) | Modelo de resumen sin IA | F2 |
| **4** | **LLM — propagación dinámica** | Sugerencias → revisión → aplicación | F3 |
| **5** | Visualización avanzada | Timeline, genealogía, diplomacia | F2, F4 |
| **6** | Evaluación memoria | Métricas y encuestas | F4 |
| **7** | Post-memoria | Fuera de alcance Cap. 1 | F6 |

---

## Fase 0 — Fundamentos *(en gran parte hecho)*

**Objetivo:** Base técnica compartida VTT + wiki sin migración masiva.

### Entregables

- [x] Colecciones Firestore: `wikiEntities`, `entityRelations` bajo `campaigns/{campaignId}`
- [x] Constantes `wikiEntityTypes`, `wikiRelationTypes`
- [x] Página wiki: listado, detalle, editor, panel de relaciones
- [x] Permisos DM / dueño de campaña (reutilizar criterio VTT)
- [ ] Reglas Firestore: lectura filtrada por rol/campaña (hoy filtro solo en cliente)

### Criterio de hecho

El DM puede crear, editar y borrar fichas y relaciones en una campaña seleccionada.

### Referencia

[`modelo-datos-entidades.md`](./memoria-capitulo1-alcance/modelo-datos-entidades.md)

---

## Fase 1 — Wiki usable en mesa

**Objetivo:** Que el DM encuentre y enlace lore durante la sesión, con puente al VTT.

### Entregables

1. **Búsqueda global** por campaña (título, tags, tipo, fragmento de `body`)
2. **Puente VTT ↔ wiki**
   - Vincular `linkedVttLocationId` / `linkedVttCharacterId` desde UI
   - Desde ubicación en mapa: abrir o crear ficha `locacion` wiki
   - Desde personaje VTT: abrir o crear ficha `personaje` wiki
3. **Menciones en texto** (`@` o `/tipo/slug`)
   - Autocompletado al escribir
   - Enlaces clicables en vista lectura
   - Lista “mencionado en” / backlinks en detalle
4. **Visibilidad coherente** (`players` vs `dm_only`) en wiki + revisión de Lore drawer
5. **Unificación Lore (VTT) ↔ wiki** (estrategia elegida: migración gradual o “abrir en wiki” desde entrada legacy)

### Criterio de hecho

El DM puede escribir una descripción de ciudad con `@` a personajes y organizaciones, buscar cualquier ficha en &lt; 3 clics y saltar desde el mapa a la ficha wiki.

### Fuera de esta fase

- IA, timelines, mapas en capas

---

## Fase 2 — Contenido rico y tipos ampliados

**Objetivo:** Cubrir facciones, religiones, mitos y artículos genéricos con organización clara.

### Entregables

1. **Ampliación de tipos** (actualizar `decisiones-diseno.md` + `wikiEntityTypes.js` + validadores)
   - Opción recomendada: `religion`, `mito_leyenda`, `documento`, `articulo` (catch-all)
   - `organizacion` en UI como “Organización / gremio / casa” (revisar etiqueta «facción»)
2. **Plantillas ligeras por tipo** (`customFields` o secciones fijas en editor)
3. **Categorías / carpetas** por campaña (jerarquía + filtro en listado)
4. **Tags** mejorados (autocompletado, filtros combinados)
5. **Slugs** estables para menciones `/tipo/slug`
6. **Relaciones ampliadas** (`sede_en`, `miembro_de`, `controla`, `adora`, `origen_de`, `ocurrió_en`, etc.)
7. **Imagen de portada** por entidad (Storage + campo en entidad)
8. **Vista jugador** dedicada (solo `visibility: players`)

### Criterio de hecho

El DM puede mantener religiones, mitos y organizaciones como fichas distintas, agrupadas por categoría, con relaciones tipadas visibles en la ficha.

### Referencia WA

Artículos + plantillas, categorías, tags — ver [`investigacion-worldanvil-funciones.md`](./investigacion-worldanvil-funciones.md) §2–3.

---

## Fase 3 — Eventos de sesión *(manual, sin LLM)*

**Objetivo:** Modelar el **resumen de sesión** y los **impactos** como datos, antes de automatizar con IA.

### Entregables

1. **Nuevo tipo o colección: evento de sesión**
   - Distinto de `evento_historico` (pasado del mundo)
   - Campos sugeridos: `sessionDate`, `title`, `summary` (texto del DM), `campaignId`, `visibility`, `status`
2. **Colección `sessionImpacts`** (o subcolección) — impactos **manuales** o **pendientes de IA**
   - `sessionId`, `impactType` (`create_entity` | `update_entity` | `create_relation` | `update_field` | `add_tag` | …)
   - `targetEntityId`, `payload`, `status` (`draft` | `proposed` | `accepted` | `rejected` | `applied`)
   - `proposedBy` (`dm` | `llm`), `reviewedBy`, timestamps
3. **UI: crear resumen de sesión** y añadir impactos a mano (crear relación, editar resumen de entidad)
4. **Flujo manual:** aplicar impactos aceptados → actualizar `wikiEntities` / `entityRelations`
5. **Historial / auditoría** ligera (`appliedAt`, diff resumido)

### Criterio de hecho

Tras una partida, el DM guarda un resumen, registra al menos un cambio manual (ej. nueva relación “aliado de”) y lo aplica al archivo sin usar IA.

### Dependencia para Fase 4

El esquema de `sessionImpacts` y estados es el **contrato** que consumirá el LLM.

---

## Fase 4 — Integración LLM: propagación dinámica

**Objetivo:** El DM escribe el resumen de sesión → el modelo propone impactos estructurados → el DM **edita, acepta o rechaza** cada uno → el sistema **aplica** y deja **trazabilidad**.

Esta fase es el **corazón de la memoria** (Capítulo 1).

### 4.1 Infraestructura y modelo

| Tarea | Detalle |
|-------|---------|
| Habilitar **Firebase AI Logic** | Consola Firebase, proveedor Gemini Developer API |
| SDK en cliente | Según [`decisiones-diseno.md`](./memoria-capitulo1-alcance/decisiones-diseno.md) §8–9 |
| **App Check** (recomendado) | Reducir abuso del endpoint |
| Límites de coste | Presupuesto ~20 USD/mes; logging de tokens por sesión |
| Idioma | Prompts y salida en **español** |

**Evolución opcional (post-MVP Fase 4):** mover inferencia a **Cloud Functions** si seguridad o tamaño de contexto lo exigen.

### 4.2 Contrato de salida (JSON estructurado)

Documento: `memoria-capitulo1-alcance/contrato-json-impactos.md` (pendiente).

El modelo debe devolver un array de impactos alineados a `sessionImpacts`, por ejemplo:

```json
{
  "sessionSummary": "string",
  "impacts": [
    {
      "impactType": "create_relation",
      "fromEntityTitle": "Kael",
      "toEntityTitle": "Gremio del Yunque",
      "relationType": "miembro_de",
      "confidence": 0.85,
      "rationale": "En la sesión Kael juró lealtad al gremio."
    }
  ]
}
```

Incluir: resolución de títulos → IDs de entidades existentes, flag `needs_new_entity`, sugerencia de `entityType` para altas nuevas.

### 4.3 Construcción de contexto (RAG ligero)

Antes de llamar al modelo:

1. Cargar entidades relevantes de la campaña (por menciones en el resumen, tags, o top-N por tipo)
2. Incluir relaciones existentes entre entidades mencionadas
3. Respetar límite de tokens (resumir `body` largos; priorizar `title`, `summary`, `entityType`)
4. **No** enviar contenido `dm_only` a jugadores; el prompt del DM sí puede incluir secretos si el resumen es solo para DM

### 4.4 Pipeline de propagación

```mermaid
sequenceDiagram
    participant DM
    participant UI
    participant LLM
    participant DB

    DM->>UI: Escribe resumen de sesión
    UI->>LLM: Resumen + contexto wiki
    LLM-->>UI: JSON impactos propuestos
    UI->>DM: Lista sugerencias (editar / aceptar / rechazar)
    DM->>UI: Confirma selección
    UI->>DB: Aplica impactos accepted
    DB-->>UI: Entidades/relaciones actualizadas
    UI->>DM: Vista resultado + historial
```

| Paso | Descripción |
|------|-------------|
| **1. Generar** | Botón “Analizar sesión” → llamada AI Logic → parseo JSON validado |
| **2. Proponer** | Cada impacto en estado `proposed`; mostrar `rationale` y entidades afectadas |
| **3. Editar** | DM corrige texto, relación, entidad objetivo o tipo antes de aceptar |
| **4. Aceptar / Rechazar** | Por ítem o en lote |
| **5. Aplicar** | Transacción o batch: writes a `wikiEntities` / `entityRelations`; `status: applied` |
| **6. Resultado** | Pantalla “Sesión aplicada”: diff legible + enlace al `sessionId` |

### 4.5 Entregables de producto

- [ ] Servicio `wikiSessionService` + `wikiImpactService` (Firestore)
- [ ] Servicio `wikiAiPropagationService` (AI Logic + validación Zod/JSON schema)
- [ ] UI: `WikiSessionEditor` (resumen)
- [ ] UI: `WikiImpactReviewPanel` (tabla/cards con aceptar, rechazar, editar inline)
- [ ] UI: `WikiSessionResultView` (post-aplicación)
- [ ] Manejo de errores: JSON inválido, entidad no encontrada, reintento, fallback manual
- [ ] Registro: `proposedBy: llm`, modelo usado, versión de prompt (para memoria académica)

### 4.6 Criterios de hecho (Fase 4)

1. DM escribe resumen en español → recibe ≥ 1 sugerencia coherente sin escribir JSON a mano  
2. DM puede **rechazar** una sugerencia y **aceptar** otra sin aplicar el lote completo  
3. DM puede **editar** una sugerencia antes de aplicar  
4. Tras aplicar, las fichas/relaciones reflejan los cambios y el evento de sesión queda en historial  
5. Jugadores **no** ven borradores ni propuestas LLM, solo contenido ya `players` si aplica  

### Riesgos y mitigaciones

| Riesgo | Mitigación |
|--------|------------|
| Alucinaciones / entidades inventadas | Validación contra IDs; flag `needs_new_entity` con confirmación DM |
| Coste API | Límite de contexto, resúmenes, caché de entidades |
| Pérdida de control narrativo | **Nunca** auto-aplicar; siempre revisión DM |
| Seguridad API key | AI Logic proxy + App Check; Functions si hace falta |

---

## Fase 5 — Visualización avanzada

**Objetivo:** Herramientas de lectura del mundo inspiradas en World Anvil, sin duplicar el VTT táctico.

### Entregables

1. **Línea temporal simple** (`evento_historico` + fechas/eras ficticias)
2. **Árbol genealógico** derivado de relaciones entre `personaje`
3. **Red de diplomacia** entre `organizacion` (aliado / enemigo / vasallo)
4. **Secretos embebidos** (bloques `dm_only` en `body` o entidad reutilizable)
5. **Mapa → wiki** (pin abre ficha; opcional capas mundo/región/ciudad en iteración posterior)

### Criterio de hecho

El DM visualiza al menos una cronología y un grafo de relaciones organizacionales para la campaña piloto.

### Dependencias

Fase 2 (tipos y relaciones); Fase 4 recomendada para enriquecer eventos históricos desde sesiones aplicadas.

---

## Fase 6 — Evaluación memoria (Capítulo 1)

**Objetivo:** Evidencia para la memoria académica: propagación dinámica vs wiki estático.

### Entregables

1. **KPIs cuantitativos:** tiempo para registrar sesión, nº impactos aceptados/rechazados, entidades actualizadas por campaña
2. **Encuestas** DM y jugadores (plantilla en español)
3. **Criterios cualitativos:** usabilidad vs World Anvil (benchmark en [`investigacion-worldanvil-funciones.md`](./investigacion-worldanvil-funciones.md))
4. **Export backup** de campaña (JSON/Markdown)
5. Informe interno / capturas para memoria

### Criterio de hecho

Al menos una campaña piloto con ≥ 3 sesiones registradas vía Fase 4 y datos de evaluación recogidos.

---

## Fase 7 — Post-memoria (explícitamente fuera de Cap. 1)

No planificar como bloqueante de la memoria. Referencia para backlog futuro:

- Chatbot de personajes para jugadores  
- Manuscritos / novela integrada  
- Statblocks y hojas RPG completas en wiki  
- Integración Foundry / API pública  
- Sitio público / monetización tipo World Anvil Guild  
- Timelines multi-rama, calendarios ficticios completos  
- Inferencia IA siempre en servidor (Vertex, Functions)  

---

## Resumen ejecutivo por prioridad

| Prioridad | Fase | Qué obtienes |
|-----------|------|----------------|
| P0 | 0 | Wiki + relaciones en Firestore |
| P1 | 1 | Enlaces `@`, búsqueda, puente mapa/PJ |
| P2 | 2 | Religiones, mitos, categorías, plantillas |
| P3 | 3 | Resumen de sesión manual + modelo de impactos |
| **P4** | **4** | **LLM: sugerencias → edición → aceptación → aplicación** |
| P5 | 5 | Timeline, genealogía, diplomacia |
| P6 | 6 | Métricas y encuestas para la memoria |

---

## Documentos a crear o actualizar por fase

| Fase | Documento / código |
|------|-------------------|
| 2 | Actualizar `decisiones-diseno.md` §B (nuevos `entityType`) |
| 3 | `modelo-datos-entidades.md` — `sessionEvents`, `sessionImpacts` |
| 4 | `contrato-json-impactos.md`, prompts versionados, servicios AI |
| 6 | Plantilla encuesta, hoja KPIs |

---

*Roadmap vivo: al cerrar cada fase, marcar entregables en este archivo y enlazar PRs o commits relevantes.*
