---
name: icon-class-mendicants
description: >-
  ICON Mendicant class (green jobs): Chanter, Harvester, Seer; Diaga, Bless,
  extended Rescue; Blessing tokens; Sealed/Pacified; Cure, Aura, Combo, Mark
  heavy kits. Use when designing support abilities, cleanses, buff stacking, or
  green-class audits.
disable-model-invocation: false
---

# ICON — Mendicant class & jobs (green)

*Source: `docs/icon/ICON Book Mendicants.pdf`.*

## Class fantasy

Itinerant **healers / exorcists / ritualists** — **cure**, **vigor**, **status
cleanses**, **marks**, **auras**, **combos**; mid-line complexity.

## Class traits (pattern)

- **Diaga (1 action):** **Cure** at range **4** (see glossary for Cure).
- **Bless (1 action):** grant **Blessing** token in range **4**.
- **Succor:** **Rescue** range **4** instead of adjacent baseline.
- **Blessing tokens:** spend default +1 boon to saves; each job adds **extra
  outlets**; all blessings **discard end of combat**; not uniquely owned.

## Class stats template

**VIT 10 / HP 40 / Def 8 / Speed 4 (Dash 2) / Fray 3 / D6 / Range 5**.

## Status focus

- **Sealed** stops foes applying statuses.
- **Pacified** halves foe damage until they take foe damage.

## Structural tools

- **Auras** for positional buff/debuff zones.
- **Combo** sequencing (base vs combo line).
- **Marks** that pay off over time.

## Jobs

| Job | Pitch |
|-----|--------|
| **Chanter** | Great Chant liturgy; combos, flight, pits, charge synergy |
| **Harvester** | (read PDF) soul / bounty themes |
| **Seer** | (read PDF) prescience & wards |

## Homebrew guardrails

- Respect **Blessing** economy — don’t outclass **Diaga** free cleanse cadence
  without costs.
- **Sealed/Pacified** are strong — pair with **break conditions**.

## Links

`icon-combat-glossary` · `icon-jobs-progression` · `icon-ttrpg-index`
