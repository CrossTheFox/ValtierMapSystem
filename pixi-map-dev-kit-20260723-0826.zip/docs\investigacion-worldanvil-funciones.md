# Investigación: funciones principales de World Anvil

**Fecha:** mayo 2026  
**Fuentes:** [worldanvil.com](https://www.worldanvil.com/), [List of Features by Guild Level](https://www.worldanvil.com/learn/account/list-features), [Pricing](https://www.worldanvil.com/pricing), documentación oficial en `/learn/`.

World Anvil es una plataforma SaaS de *worldbuilding* (construcción de mundos ficticios) orientada a escritores, *game masters* (GMs), jugadores y creadores. Combina wiki, mapas interactivos, líneas temporales, gestión de campañas RPG, escritura de novelas y herramientas de publicación/colaboración. Este documento resume **todas las funciones principales**, cómo funcionan a grandes rasgos y qué está disponible en el plan gratuito frente a los de pago (*Guild*).

---

## 1. Modelo de cuentas (gratis vs pago)

| Nivel | Público | Límites destacados |
|-------|---------|-------------------|
| **Freeman** (gratis) | Probar la plataforma | 2 mundos, 2 campañas, 42 artículos publicados + 5 borradores, 15 categorías, 2 mapas, 2 timelines, 20 statblocks, 100 MB imágenes, exportación básica |
| **Epic Hero** | Jugadores RPG | Todo Freeman + personajes privados, URL/CSS de personaje, sin anuncios para ti |
| **Master** | Worldbuilders principiantes | 10 mundos/campañas, artículos/mapas/timelines/manuscritos ilimitados, 2 GB, 4 coautores, 10 suscriptores, privacidad, árboles genealógicos, diplomacia, manuscritos, etc. |
| **Grandmaster** | Uso semi-profesional | Mundos ilimitados, 5 GB, 9 coautores, 100 suscriptores, mapas avanzados, plantillas custom, content trees, SEO |
| **Sage** | Autores, estudios, streamers | Campañas/mundos ilimitados, 15 GB, 20 coautores, 1000 suscriptores, dominio propio, white label, artículos con contraseña |

> **Nota:** El tier **Journeyman** está deprecado; quien lo tenga conserva beneficios legacy. Los precios concretos cambian; consultar la [página de pricing](https://www.worldanvil.com/pricing).

---

## 2. Conceptos base de la plataforma

### 2.1 Mundos (*Worlds*)

Un **mundo** es el contenedor principal del setting: puede ser una ciudad, un continente o un multiverso. Todo (artículos, mapas, campañas) cuelga de un mundo.

**Cómo se usa (a grandes rasgos):**
1. Crear cuenta y elegir perfil (GM, escritor, jugador, etc.).
2. Desde el *world switcher* → **New World**.
3. Configurar nombre, sistema RPG (opcional), tema visual y visibilidad (público/privado según tier).
4. Personalizar homepage, navegación lateral, pie de copyright (Guild), dominio custom (Sage).

**Gratis:** hasta 2 mundos. **Pago:** más mundos; exportación avanzada, estadísticas, RSS, webhooks Discord, dominio propio (Sage).

---

### 2.2 Artículos (*Articles*) — núcleo del wiki

Los artículos son entradas tipo Wikipedia sobre elementos del mundo: personajes, lugares, organizaciones, hechizos, etc.

**En qué consisten:**
- Más de **25 plantillas** con campos estructurados y prompts (edificios, personajes, países, idiomas, religiones, vehículos, mitos, etc.).
- Editor con **BBCode** (formato propio similar a Markdown/foros).
- Enlaces cruzados (*mentions*), etiquetas, categorías anidadas, imágenes, audio, PDFs embebidos (Guild).
- Modo lectura inmersiva; vista previa en la misma página (Master+).

**Cómo se realizan:**
1. Botón verde **Create** → elegir plantilla.
2. Título + contenido en campos de plantilla y cuerpo libre.
3. Enlazar con `@` o autolinker a otros artículos (incluso artículos aún no creados → van al *To-Do*).
4. Organizar en categorías; publicar o guardar como borrador.

**Gratis:** límite de artículos publicados (42) y borradores (5). **Pago:** ilimitados; focus mode, panel “Referenced in”, transferencia entre mundos, plantillas custom (Grandmaster+).

---

### 2.3 Categorías y organización

**En qué consisten:** Jerarquía de carpetas/categorías para agrupar artículos; widgets de tabla de contenidos y estilo “libro” en la portada del mundo.

**Cómo se realizan:** Crear categorías padre/hijo; arrastrar artículos; anidar artículos bajo artículos; mostrar portadas tipo libro en la homepage.

**Gratis:** 15 categorías. **Pago:** ilimitadas; redirección categoría→artículo, widgets avanzados (Master+).

---

### 2.4 Sistema de enlaces y menciones

**En qué consiste:** Red de referencias entre entidades del mundo (como un wiki interconectado).

**Cómo se realiza:** Al escribir, mencionar otro artículo; crear enlaces a artículos inexistentes (quedan pendientes); autolinker en tier gratuito.

**Gratis:** autolinker básico. **Pago:** sistema de menciones extendido, backlinks “Referenced in” (Journeyman legacy / Master+).

---

### 2.5 Búsqueda y etiquetas

**En qué consiste:** Buscar en todo el mundo con pocas letras; filtrar por tags durante sesión o escritura.

**Cómo se realiza:** Barra de búsqueda global; asignar tags a artículos; resultados respetan árbol de categorías (actualización 2025).

**Disponibilidad:** Incluido en todos los tiers (con límites de contenido en gratis).

---

## 3. Herramientas visuales y cronológicas

### 3.1 Mapas interactivos

**En qué consisten:** Imágenes de mapa con **marcadores** enlazados a artículos; capas jerárquicas (mundo → región → ciudad → mazmorra).

**Cómo se realizan:**
1. Subir imagen de mapa.
2. Colocar pins que abren artículos al hacer clic.
3. Añadir capas (*layers*) para distintos niveles geográficos.
4. (Guild) Grupos de marcadores, etiquetas, líneas, brújula, marcadores invisibles; (Grandmaster+) polígonos, círculos, HTML, arrastrar marcadores, mapa como fondo global del mundo.

**Gratis:** 2 mapas. **Pago:** ilimitados + funciones avanzadas según tier.

---

### 3.2 Timelines (líneas temporales)

**En qué consisten:** Cronologías de eventos históricos con eras, timelines paralelos (por país o personaje) y visualización especializada.

**Cómo se realizan:** Crear timeline → añadir eventos con fechas → organizar en eras y ramas paralelas → embeber en artículos.

**Gratis:** 2 timelines. **Pago:** ilimitados + eventos históricos ilimitados.

---

### 3.3 Calendarios

**En qué consisten:** Calendarios ficticios (días/meses personalizados, festivales, fases celestes). Distintos de timelines: representan **ciclos**, no secuencias lineales.

**Cómo se realizan:** Definir estructura del calendario → eventos y objetos celestes → previsualizar años → exportar/importar.

**Disponibilidad:** Módulo **Guild** (Master+); Journeyman legacy.

---

### 3.4 Árboles genealógicos (*Family trees*)

**En qué consisten:** Diagramas de parentesco y linajes dinásticos vinculados a personajes.

**Cómo se realizan:** Desde plantilla de personaje u herramienta dedicada → añadir nodos y relaciones → compartir con lectores/jugadores.

**Disponibilidad:** **Master+** (no en Freeman).

---

### 3.5 Redes de diplomacia (*Diplomacy webs*)

**En qué consisten:** Gráficos de relaciones entre naciones, facciones o megacorporaciones (alianzas, guerras, tensiones).

**Cómo se realizan:** Crear entidades y enlazar relaciones con etiquetas visuales.

**Disponibilidad:** **Master+**.

---

### 3.6 Content trees (organogramas)

**En qué consisten:** Árboles/organigramas interactivos o estáticos (jerarquías mágicas, gremios, taxonomías).

**Cómo se realizan:** Añadir nodos, arrastrar para reordenar, embeber como gráfico estático, lista o interactivo en artículos.

**Disponibilidad:** **Grandmaster+**.

---

### 3.7 Tablas interactivas y generadores aleatorios

**En qué consisten:**
- **Tablas rolables:** clima, loot, encuentros; tablas encadenadas para generación multi-paso.
- **Random generators:** contenido aleatorio reutilizable en campaña.

**Cómo se realizan:** Definir filas/resultados → enlace entre tablas → insertar en artículos o usar en sesión.

**Disponibilidad:** Tablas en **Master+**; generadores aleatorios en **Grandmaster+**. La web pública también ofrece [generadores gratuitos](https://www.worldanvil.com/random-generators) sin cuenta.

---

## 4. Módulos de escritura y productividad

### 4.1 Manuscritos (*Manuscripts*)

**En qué consisten:** Software de escritura de novelas integrado con el lore del mundo (capítulos, escenas, exportación).

**Cómo se realizan:** Crear manuscrito dentro del mundo → escribir por capítulos → vincular referencias a artículos del worldbuilding.

**Disponibilidad:** **Master+** (ilimitados en tiers superiores).

---

### 4.2 Cuadernos (*Notebook*)

**En qué consisten:** Notas rápidas con búsqueda, filtros, etiquetas y favoritos (meta-notas, ideas sueltas).

**Cómo se realizan:** Entrada en barra lateral → notas independientes de artículos formales.

**Disponibilidad:** **Master+** (y Journeyman legacy).

---

### 4.3 Lista de tareas (*To-Do list*)

**En qué consisten:** Seguimiento de artículos pendientes (incluidos los creados por enlaces a artículos inexistentes).

**Cómo se realizan:** Se llena automáticamente con menciones sin artículo; el autor marca completado al crear el contenido.

**Disponibilidad:** **Master+**.

---

### 4.4 Pizarras (*Whiteboards*)

**En qué consisten:** Lienzos visuales para brainstorming, diagramas libres y planificación.

**Cómo se realizan:** Herramienta en el *toolbox* lateral → dibujar/organizar elementos.

**Disponibilidad:** **Master+**.

---

### 4.5 Variables

**En qué consisten:** Fragmentos de texto reutilizables referenciados por nombre (`[var:prefijo-clave]`) en múltiples artículos; cambio centralizado.

**Cómo se realizan:** Crear colección de variables → insertar en BBCode → editar una vez, actualizar en todos los sitios.

**Disponibilidad:** **Master+**.

---

### 4.6 Secretos (*Secrets*)

**En qué consisten:** Bloques de información oculta embebibles en varios artículos; revelables al lector/jugador; notas de GM privadas.

**Cómo se realizan:** Crear secreto → embeber con BBCode → controlar visibilidad por suscriptor o estado de campaña.

**Disponibilidad:** Privacidad básica en **Journeyman legacy / Master+**; contenedores por suscriptor en Grandmaster+.

---

### 4.7 Crónicas (*Chronicles*)

**En qué consisten:** Registro narrativo estructurado de acontecimientos de campaña o historia (complemento a timelines y session reports).

**Cómo se realizan:** Entradas cronológicas vinculadas al mundo/campaña.

**Disponibilidad:** **Master+**.

---

### 4.8 Worldbuilding Meta

**En qué consiste:** Ficha del “ADN” del setting: temas, conflicto central, inspiración, tono — no necesariamente visible para jugadores.

**Cómo se realiza:** Icono de engranaje en el mundo → pestañas de preguntas guía → guardar en bullets.

**Disponibilidad:** **Todos los tiers** (incluido Freeman).

---

## 5. Funciones RPG

### 5.1 Gestor de campañas (*Campaign Manager*)

**En qué consiste:** Espacio para organizar una campaña: tramas, sesiones, PNJs, misiones, equipo, grupo de jugadores.

**Cómo se realiza (flujo GM típico):**
1. Crear mundo → **Campaign Manager** → nueva campaña.
2. Invitar jugadores (enlace o email).
3. Planificar sesión (notas, statblocks, tablas).
4. **Ejecutar sesión:** pantalla tipo “GM screen” online (notas, dados, referencias, hojas de PJ).
5. Crear **session report** tras la partida.

**Gratis:** 2 campañas. **Master:** 10. **Grandmaster:** 20. **Sage:** ilimitadas.

---

### 5.2 Statblocks

**En qué consisten:** Fichas de criaturas/NPC compatibles con muchos sistemas (D&D 5e, Pathfinder, etc.).

**Cómo se realizan:** Plantilla de statblock → rellenar campos → usar en artículos, campaña o exportar a VTT.

**Gratis:** 20 statblocks. **Pago:** ilimitados; plantillas custom (Grandmaster+).

---

### 5.3 Gestor de personajes (*Character Manager*)

**En qué consisten:** Hojas de PJ para jugadores; unión a campañas; edición por GM.

**Cómo se realizan:** Jugador crea personaje → se une a campaña con invitación → GM ve/edita en pestaña *Protagonists*.

**Gratis:** personajes **ilimitados** (Freeman). **Epic Hero:** personajes privados y personalización URL/CSS.

---

### 5.4 Integración Foundry VTT

**En qué consiste:** Módulo oficial para importar artículos y statblocks a diarios de Foundry.

**Cómo se realiza:** Token API en World Anvil → instalar módulo en Foundry → pegar token → importar contenido.

**Disponibilidad:** **Master+** (API user token); solicitud de API application key en Grandmaster+.

---

### 5.5 Roll20 y otros VTT

**En qué consiste:** No hay sincronización automática nativa como con Foundry; enfoques manuales (World Anvil como wiki + Roll20 para mapas/tokens) o copia de statblocks.

---

### 5.6 Tableros de discusión (*Discussion boards*)

**En qué consisten:** Foros dentro del mundo; útiles para *play-by-post*.

**Cómo se realizan:** Tableros por categoría e hilos → permisos de lectura/escritura/moderación → publicar como usuario o personaje.

**Disponibilidad:** **Master+**.

---

## 6. Imágenes, medios y presentación

### 6.1 Biblioteca de imágenes

**En qué consiste:** Almacenamiento, carpetas, inserción en artículos, carruseles (Guild).

**Cómo se realiza:** Subir → organizar en carpetas → insertar desde el editor; edición masiva (Sage).

**Gratis:** 100 MB. **Master:** 2 GB. **Grandmaster:** 5 GB. **Sage:** 15 GB.

---

### 6.2 Temas visuales y CSS

**En qué consisten:** Skins del mundo, CSS global, CSS por artículo, contenedores BBCode custom (Grandmaster).

**Cómo se realizan:** Panel de estilos del mundo → editar CSS o elegir tema Guild → previsualizar.

**Gratis:** temas básicos con marca World Anvil. **Master+:** temas Guild, sin anuncios. **Sage:** white label (sin branding WA).

---

### 6.3 BBCode y widgets

**En qué consisten:** Formato enriquecido, tooltips, menciones, embeds (mapas, diccionarios de idiomas, PDFs, secretos, tablas).

**Cómo se realizan:** Etiquetas BBCode en el editor; documentación en [BBCode tutorials](https://www.worldanvil.com/learn/bbcode-tutorials).

**Disponibilidad:** Base en todos; funciones avanzadas según tier (PDF, comentarios invisibles, iconos masivos en Grandmaster+).

---

## 7. Colaboración, acceso y monetización

### 7.1 Coautores

**En qué consisten:** Otros usuarios con permisos de edición en el mundo.

**Gratis:** no (o muy limitado). **Master:** 4. **Grandmaster:** 9. **Sage:** 20.

---

### 7.2 Suscriptores

**En qué consisten:** Lectores/jugadores con acceso a contenido privado o por grupos (beta readers, Patreon, mesa west marches).

**Cómo se realizan:** Invitar o importar (Sage: Patreon/Ko-fi) → asignar grupos → ocultar bloques con *subscriber containers* (Grandmaster+).

**Gratis:** 0 suscriptores. **Master:** 10. **Grandmaster:** 100. **Sage:** 1000 + códigos de acceso.

---

### 7.3 Privacidad y control de visibilidad

| Función | Freeman | Guild |
|---------|---------|-------|
| Mundos/artículos públicos | Sí | Sí |
| Mundos/artículos privados | No | Master+ |
| Secretos y spoilers | Limitado | Master+ |
| Contenedores solo suscriptores | No | Grandmaster+ |
| Enlaces asegurados (*secured links*) | No | Grandmaster+ |
| Artículos con contraseña | No | Sage |
| Ocultar del índice / redes sociales | Parcial | Master+ |

---

### 7.4 Monetización

**En qué consiste:** Publicar mundo con contenido exclusivo para clientes/Patreon; enlaces privados de pago; gestión masiva de suscriptores (Sage).

**Cómo se realiza:** Mundo público + secciones restringidas por grupo de suscriptor; integración con plataformas externas vía importación de suscriptores.

**Disponibilidad:** Funcionalidad principal en **Grandmaster/Sage**.

---

## 8. Exportación, API y profesional

### 8.1 Exportación de mundos

**En qué consiste:** Descargar copia del worldbuilding (respaldo, migración).

**Disponibilidad:** **Freeman** (exportación básica); **Master+** exportación avanzada.

---

### 8.2 API

- **User API tokens** (Master+): integración personal (p. ej. Foundry).
- **API application key** (Grandmaster+): aplicaciones de terceros.

---

### 8.3 Funciones profesionales (Sage / Grandmaster)

- SEO metadata (Grandmaster+)
- Google Analytics (Sage)
- Dominio web custom y slugs URL (Sage)
- Talleres mensuales y programa de freelancers (Sage)
- Paquetes enterprise bajo contacto

---

## 9. Comunidad y ecosistema

| Recurso | Descripción | Coste |
|---------|-------------|-------|
| **Comunidad / feed global** | Publicaciones, votación de features (Guild) | Gratis con cuenta |
| **Discord** | Canales por tier (no es perk contractual estricto) | Gratis |
| **Worldbuilding Academy** | Guías, tips de DM y escritura | Gratis (contenido web) |
| **Cursos** (p. ej. Worldbuilding 101) | Onboarding estructurado | Gratis |
| **Prompts y generadores web** | Inspiración | Gratis en sitio |
| **Coins diarias** | Moneda interna por login (50/80/100 según tier) | Con cuenta |

---

## 10. Interfaz y experiencia (actualizaciones recientes)

Según comunicados de 2025:

- **Dashboard** renovado: contenido editado recientemente, estadísticas, prompts.
- **Articles & World Manager** a pantalla completa con árbol categoría/artículo persistente en búsqueda.
- **Carpetas** unificadas para mapas, timelines, manuscritos, eventos, imágenes.
- Edición de **homepage** integrada en el gestor.

Estas mejoras afectan sobre todo a la **usabilidad**, no cambian el modelo freemium de fondo.

---

## 11. Resumen: funciones más importantes por prioridad

| # | Función | Para quién | Gratis | Pago (desde) |
|---|---------|------------|--------|--------------|
| 1 | Artículos + plantillas | Todos | Límite 42 | Master: ∞ |
| 2 | Enlaces / wiki interno | Todos | Sí | Menciones avanzadas |
| 3 | Mapas interactivos | GM, escritores | 2 | Master: ∞ + capas |
| 4 | Timelines | Lore, historia | 2 | Master: ∞ |
| 5 | Campaign Manager | GMs | 2 campañas | Master: 10+ |
| 6 | Statblocks + PJ | GMs, jugadores | 20 / PJ ∞ | Master: ∞ statblocks |
| 7 | Categorías / búsqueda | Todos | 15 cat. | Master: ∞ |
| 8 | Privacidad / secretos | GMs, autores | No | Master |
| 9 | Manuscritos | Escritores | No | Master |
| 10 | Familias + diplomacia | Lore profundo | No | Master |
| 11 | Suscriptores / monetizar | Creadores pro | No | Grandmaster/Sage |
| 12 | Content trees + CSS custom | Power users | No | Grandmaster |
| 13 | Foundry + API | VTT | No | Master |
| 14 | Dominio + white label | Profesional | No | Sage |

---

## 12. Cómo encaja con este proyecto (pixi-map)

Referencia interna: el módulo **Narrative Wiki** en pixi-map (`NarrativeWikiPage`, entidades, relaciones en Firestore) cubre un subconjunto similar al núcleo de World Anvil (entidades tipadas, relaciones, campaña/mundo). World Anvil añade mapas avanzados, manuscritos, VTT, monetización de suscriptores y un ecosistema maduro de plantillas — útil como **benchmark funcional**, no como dependencia técnica.

---

## 13. Referencias

- [World Anvil — Home](https://www.worldanvil.com/)
- [List of Features by Guild Level](https://www.worldanvil.com/learn/account/list-features)
- [Guild Membership Pricing](https://www.worldanvil.com/pricing)
- [Campaign Manager guide](https://www.worldanvil.com/learn/rpg/campaign-manager)
- [GM Workflow](https://www.worldanvil.com/learn/workflows/gm-workflow)
- [Writer Workflow](https://www.worldanvil.com/learn/workflows/writer-workflow)
- [Foundry integration](https://www.worldanvil.com/learn/rpg/foundry-integration)
- [Blog — Features 2025](https://blog.worldanvil.com/worldanvil/dev-news/world-anvil-new-features-2025/)

---

*Documento elaborado para apoyo de diseño del wiki narrativo en pixi-map. Los límites exactos del plan Freeman pueden ajustarse por World Anvil; verificar siempre la documentación oficial antes de tomar decisiones de producto.*
